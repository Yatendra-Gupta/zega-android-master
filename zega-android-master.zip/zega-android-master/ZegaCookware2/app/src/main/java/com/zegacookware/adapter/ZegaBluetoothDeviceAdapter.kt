package com.zegacookware.adapter

import android.bluetooth.BluetoothDevice
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.zegacookware.R
import com.zegacookware.interfaces.SetOnItemClickListener
import kotlinx.android.synthetic.main.item_device_list.view.*

class ZegaBluetoothDeviceAdapter(
    var mContext: Context,
    var userDeviceList: List<BluetoothDevice>,
    var setOnItemClickListener: SetOnItemClickListener
) :
    RecyclerView.Adapter<ZegaBluetoothDeviceAdapter.RecipesViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecipesViewHolder {
        val view =
            LayoutInflater.from(mContext).inflate(R.layout.item_bluetooth_device_list, parent, false)
        return RecipesViewHolder(view)
    }

    override fun getItemCount(): Int {
        return userDeviceList.size
    }

    override fun onBindViewHolder(holder: RecipesViewHolder, position: Int) {
       // holder.itemView.deviceName.text = userDeviceList[position].name
        holder.itemView.tvDeviceId.text = userDeviceList[position].address
        holder.itemView.setOnClickListener {
            setOnItemClickListener.onItemClick(position)
        }

    }

    class RecipesViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    }
}