package com.zegacookware.model.user

data class LoginRequest (
    var name:String="",
    var last_name:String="",
    var user_email:String="",
    var password:String="",
    var device_token:String="",
    var device_type:String=""
)


//change-password
//
//$user_id = $request->user_id;
//$oldPass = $request->old_pass;
//$newPass = $request->new_pass;