package com.zegacookware.activity

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.zegacookware.R
import com.zegacookware.adapter.RecipesTitleAdapter
import com.zegacookware.fragment.PopupWindowFilter
import com.zegacookware.interfaces.ClickOnFavouritePopup
import com.zegacookware.interfaces.SetOnItemClickListener
import com.zegacookware.model.recipes.*
import com.zegacookware.model.user.UserResult
import com.zegacookware.network.Constant
import com.zegacookware.util.CommonUtility
import kotlinx.android.synthetic.main.activity_single_category_recipes.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SingleCategoryRecipesActivity : BaseActivity(), View.OnClickListener {

    private lateinit var adapter1: RecipesTitleAdapter
    private lateinit var userData: UserResult
    private lateinit var mContext: Context
    private val recipesList: ArrayList<RecepieTitle> = ArrayList()
    private val recipesListTemp: ArrayList<RecepieTitle> = ArrayList()

    private val getFoodTypeLst: ArrayList<GetFoodTypeData> = ArrayList()
    private var isNotShowListIcon: Boolean = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_single_category_recipes)
        mContext = this@SingleCategoryRecipesActivity
        userData = CommonUtility.getUserData(Constant.userInfo, this@SingleCategoryRecipesActivity)

        ivBack.setOnClickListener { finish() }
        btnFilter.setOnClickListener(this)
        btnGridList.setOnClickListener(this)
        getFoodTypeList()
        rvRecipesTitle.layoutManager = LinearLayoutManager(mContext)
        adapter1 = RecipesTitleAdapter(
            mContext,
            recipesList,
            object : SetOnItemClickListener {
                override fun onItemClick(position: Int) {
                    startActivity(
                        Intent(
                            this@SingleCategoryRecipesActivity,
                            RecipesDetailsActivity::class.java
                        )
                            .putExtra("id", recipesList[position].recepieId)
                    )
                }
            }, true
        )
        rvRecipesTitle.adapter = adapter1

        Constant.service.getRecipesByCategoryID(
            RecipesDetailRequest(
                category_id = "" + intent.getIntExtra(
                    "id",
                    0
                )
            )
        ).apply {
            enqueue(object : Callback<GetRecipesByCategoryId> {
                override fun onFailure(call: Call<GetRecipesByCategoryId>, t: Throwable) {
                }

                override fun onResponse(
                    call: Call<GetRecipesByCategoryId>,
                    response: Response<GetRecipesByCategoryId>
                ) {
                    recipesList.clear()
                    if (response.isSuccessful && response.body()?.status == 1) {
                        tvRecipesTitle.visibility = View.VISIBLE
                        recipesListTemp.clear()
                        recipesList += response.body()?.recipesTitle!!
                        recipesListTemp.addAll(recipesList)
                        adapter1.notifyDataSetChanged()
                    } else if (response.isSuccessful && response.body()?.status == 0) {
                        tvRecipesTitle.visibility = View.GONE
                    }
                }

            })

            tvRecipesTitle.text = intent.getStringExtra("title")
        }
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btnFilter -> {
                if (getFoodTypeLst.isNotEmpty()) {
                    openDialog(mContext)
                }
            }
            R.id.btnGridList -> {
                if (!isNotShowListIcon) {
                    isNotShowListIcon = true
                    val adapter1 = RecipesTitleAdapter(
                        mContext,
                        recipesList,
                        object : SetOnItemClickListener {
                            override fun onItemClick(position: Int) {
                                startActivity(
                                    Intent(
                                        this@SingleCategoryRecipesActivity,
                                        RecipesDetailsActivity::class.java
                                    ).putExtra("id", recipesList[position].recepieId)
                                )
                            }
                        }, false
                    )
                    rvRecipesTitle.adapter = adapter1

                    btnGridList.setImageDrawable(
                        ContextCompat.getDrawable(
                            mContext,
                            R.drawable.ic_grid_icon
                        )
                    )
                } else {
                    isNotShowListIcon = false
                    btnGridList.setImageDrawable(
                        ContextCompat.getDrawable(
                            mContext,
                            R.drawable.ic_list_recipes
                        )
                    )
                    val adapter1 = RecipesTitleAdapter(
                        mContext,
                        recipesList,
                        object : SetOnItemClickListener {
                            override fun onItemClick(position: Int) {
                                startActivity(
                                    Intent(
                                        this@SingleCategoryRecipesActivity,
                                        RecipesDetailsActivity::class.java
                                    ).putExtra("id", recipesList[position].recepieId)
                                )
                            }
                        }, true
                    )
                    rvRecipesTitle.adapter = adapter1
                }
            }
        }

    }

    private fun getFoodTypeList() {
        CommonUtility.showProgressDialog(mContext)
        Constant.service.getFoodType().apply {
            enqueue(object : Callback<GetFoodType> {
                override fun onFailure(call: Call<GetFoodType>, t: Throwable) {
                    CommonUtility.hideProgressBar()
                }

                override fun onResponse(
                    call: Call<GetFoodType>,
                    response: Response<GetFoodType>
                ) {
                    CommonUtility.hideProgressBar()
                    if (response.isSuccessful && response.body()?.status == 1) {
                        getFoodTypeLst += response.body()?.foodTypeResult!!
                    }
                }

            })
        }
    }

    private fun openDialog(mContext: Context) {
        PopupWindowFilter.Builder<PopupWindowFilter>(
            mContext as Activity, getFoodTypeLst, object :
                ClickOnFavouritePopup {
                override fun onItemClick(position: Int, cusineType: String) {
                    if (cusineType.equals("close", true)) {
                        recipesList.clear()
                        recipesList.addAll(recipesListTemp)

                        if (recipesList.isEmpty()) {
                            tvNoRecipeFound.visibility = View.VISIBLE
                            rvRecipesTitle.visibility = View.GONE
                            tvRecipesTitle.visibility = View.GONE
                        } else {
                            adapter1.notifyDataSetChanged()
                            tvNoRecipeFound.visibility = View.GONE
                            rvRecipesTitle.visibility = View.VISIBLE
                            tvRecipesTitle.visibility = View.VISIBLE
                        }

                    } else {
                        callFilterMethod()
                    }
                }
            }
        ).setContentView(R.layout.dialog_favorite)
            .setGravity(Gravity.CENTER)
            .setScaleRatio(0.1f)
            .setBlurRadius(Constant.blurRadius)
            .build()
            .show()
    }

    fun callFilterMethod() {
        Constant.service.filterByCategoryIdMethod(
            FilterRequest(
                my_favourite = RecipesActivity.myFavourite,
                food_type = RecipesActivity.foodType.joinToString(),
                cusine_type = RecipesActivity.cusineList.joinToString(),
                user_id = "" + userData.userId,
                recepie_category_id = "" + intent.getIntExtra(
                    "id",
                    0
                )
            )
        ).apply {
            enqueue(object : Callback<GetRecipesByCategoryId> {
                override fun onFailure(call: Call<GetRecipesByCategoryId>, t: Throwable) {
                }

                override fun onResponse(
                    call: Call<GetRecipesByCategoryId>,
                    response: Response<GetRecipesByCategoryId>
                ) {
                    recipesList.clear()
                    if (response.isSuccessful && response.body()?.status == 1) {
                        recipesList += response.body()?.recipesTitle!!
                        adapter1.notifyDataSetChanged()
                    }
                    if (recipesList.isEmpty()) {
                        tvNoRecipeFound.visibility = View.VISIBLE
                        rvRecipesTitle.visibility = View.GONE
                        tvRecipesTitle.visibility = View.GONE
                    } else {
                        tvNoRecipeFound.visibility = View.GONE
                        rvRecipesTitle.visibility = View.VISIBLE
                        tvRecipesTitle.visibility = View.VISIBLE
                    }
                }

            })
        }
    }
}
