package com.zegacookware.model.faq

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class FaqResult {
    @SerializedName("faq_category_id")
    @Expose
    var faqCategoryId: Int? = null
    @SerializedName("faq_category_name")
    @Expose
    var faqCategoryName: String? = null
    @SerializedName("faq_data")
    @Expose
    var faqData: List<FaqDatum>? = null

}
