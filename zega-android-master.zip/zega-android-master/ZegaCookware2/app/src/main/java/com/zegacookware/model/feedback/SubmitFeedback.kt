package com.zegacookware.model.feedback

data class SubmitFeedback(
    var feedback_id: String = "",
    var user_id: String = ""
)