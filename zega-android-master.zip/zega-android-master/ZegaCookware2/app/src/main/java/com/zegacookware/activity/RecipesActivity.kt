package com.zegacookware.activity

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.zegacookware.R
import com.zegacookware.adapter.RecipesCategoryAdapter
import com.zegacookware.adapter.SearchRecipesAdapter
import com.zegacookware.fragment.PopupWindowFilter
import com.zegacookware.interfaces.ClickOnFavouritePopup
import com.zegacookware.interfaces.SetOnItemClickListener
import com.zegacookware.model.recipes.*
import com.zegacookware.network.Constant
import com.zegacookware.util.CommonUtility
import kotlinx.android.synthetic.main.activity_recipes.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class RecipesActivity : BaseActivity() {

    private lateinit var mContext: Context
    private val recipesList: ArrayList<CategoryResult> = ArrayList()
    private val recipesSearchList: ArrayList<RecipesResult> = ArrayList()

    private lateinit var adapter: RecipesCategoryAdapter
    private lateinit var adapterSearch: SearchRecipesAdapter
    private var edittextLength = 0
    private val getFoodTypeLst: ArrayList<GetFoodTypeData> = ArrayList()

    companion object {
        var cusineList: ArrayList<String> = ArrayList()
        var foodType: ArrayList<String> = ArrayList()
        var myFavourite: String = ""
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recipes)
        mContext = this
        hideKeyboard()
        ivBack.setOnClickListener { finish() }
        getFoodTypeList()
        btnShowAll.setOnClickListener {
            myFavourite = ""
            cusineList.clear()
            foodType.clear()
            startActivity(
                Intent(this@RecipesActivity, ShowAllRecipesActivity::class.java).putExtra(
                    "isFromFilter",
                    false
                )
            )
        }

        getCategoryList()

        etSearch.setOnClickListener {
            etSearch.isActivated = true
            etSearch.isCursorVisible = true
            etSearch.isFocusable = true
        }
        etSearch.onChange {
            edittextLength = it.length
            if (it.length > 1) {
                getRecipesList(it)
            } else {
                getUpdateBlankView(it)
            }
        }
        btnFilter.setOnClickListener { openDialog(mContext) }
    }

    private fun getUpdateBlankView(it: String) {
        lytRecipesList.visibility = View.VISIBLE
        rvRecipes.visibility = View.GONE
        tvNoFound.visibility = View.GONE
        if (it.isEmpty()) {
            hideKeyboard()
            etSearch.isCursorVisible = false
        }
    }

    private fun openDialog(mContext: Context) {
        PopupWindowFilter.Builder<PopupWindowFilter>(
            mContext as Activity, getFoodTypeLst, object :
                ClickOnFavouritePopup {
                override fun onItemClick(position: Int, cusineType: String) {
                    startActivity(
                        Intent(
                            this@RecipesActivity,
                            ShowAllRecipesActivity::class.java
                        ).putExtra("isFromFilter", true)
                    )
                }
            }
        ).setContentView(R.layout.dialog_favorite)
            .setGravity(Gravity.CENTER)
            .setScaleRatio(0.1f)
            .setBlurRadius(Constant.blurRadius)
            .setDismissOnClickBack(false)
            .setDismissOnTouchBackground(false)
            .build()
            .show()
    }

    private fun getFoodTypeList() {
        Constant.service.getFoodType().apply {
            enqueue(object : Callback<GetFoodType> {
                override fun onFailure(call: Call<GetFoodType>, t: Throwable) {

                }

                override fun onResponse(
                    call: Call<GetFoodType>,
                    response: Response<GetFoodType>
                ) {
                    getFoodTypeLst.clear()
                    if (response.isSuccessful && response.body()?.status == 1) {
                        getFoodTypeLst += response.body()?.foodTypeResult!!
                    }
                }

            })
        }
    }

    private fun getCategoryList() {
        CommonUtility.showProgressDialog(mContext)
        rvRecipesCategory.layoutManager =
            LinearLayoutManager(mContext)
        adapter = RecipesCategoryAdapter(mContext, recipesList, object :
            SetOnItemClickListener {
            override fun onItemClick(position: Int) {
                myFavourite = ""
                cusineList.clear()
                foodType.clear()
                startActivity(
                    Intent(this@RecipesActivity, SingleCategoryRecipesActivity::class.java)
                        .putExtra("id", recipesList[position].recepieCategoryId)
                        .putExtra("title", recipesList[position].recepieCategoryName)
                )
            }
        })
        rvRecipesCategory.adapter = adapter
        Constant.service.getRecipeCategoryMethod().apply {
            enqueue(object : Callback<RecipesCategory> {
                override fun onFailure(call: Call<RecipesCategory>, t: Throwable) {
                    CommonUtility.hideProgressBar()
                }

                override fun onResponse(
                    call: Call<RecipesCategory>,
                    response: Response<RecipesCategory>
                ) {
                    CommonUtility.hideProgressBar()
                    if (response.isSuccessful && response.body()?.status == 1) {
                        recipesList += response.body()?.categoryResult!!
                        adapter.notifyDataSetChanged()
                    }
                }

            })
        }

    }

    private fun getRecipesList(strSearch: String) {
        rvRecipes.layoutManager = LinearLayoutManager(mContext)
        adapterSearch =
            SearchRecipesAdapter(mContext, recipesSearchList, object :
                SetOnItemClickListener {
                override fun onItemClick(position: Int) {
                    startActivity(
                        Intent(this@RecipesActivity, RecipesDetailsActivity::class.java)
                            .putExtra("id", recipesSearchList[position].recepieId)
                    )
                }
            })
        rvRecipes.adapter = adapterSearch
        Constant.service.searchRecipe(RecipesDetailRequest(recepie_keyword = strSearch)).apply {
            enqueue(object : Callback<SearchRecipes> {
                override fun onFailure(call: Call<SearchRecipes>, t: Throwable) {
                }

                override fun onResponse(
                    call: Call<SearchRecipes>,
                    response: Response<SearchRecipes>
                ) {
                    recipesSearchList.clear()
                    tvNoFound.visibility = View.GONE
                    if (response.isSuccessful && response.body()?.status == 1) {
                        rvRecipes.visibility = View.VISIBLE
                        recipesSearchList += response.body()?.recipesResult!!
                        lytRecipesList.visibility = View.GONE
                        adapterSearch.notifyDataSetChanged()
                    } else if (response.isSuccessful && response.body()?.status == 0) {
                        lytRecipesList.visibility = View.GONE
                        rvRecipes.visibility = View.GONE
                        tvNoFound.visibility = View.VISIBLE
//                        adapterSearch.notifyDataSetChanged()
                    }
                    if (edittextLength == 0) {
                        getUpdateBlankView("")
                    }
                }

            })
        }
    }


    private fun EditText.onChange(cb: (String) -> Unit) {
        this.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                if (s.toString().isEmpty()) {
                    getUpdateBlankView(s.toString())
                }

                Thread.sleep(150)
                cb(s.toString())
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private fun AppCompatActivity.hideKeyboard() {
        val view = this.currentFocus
        if (view != null) {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(view.windowToken, 0)
        }
        // else {
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        // }
    }

}
