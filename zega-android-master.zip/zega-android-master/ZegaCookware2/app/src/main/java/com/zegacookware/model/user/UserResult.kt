package com.zegacookware.model.user

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class UserResult {
    @SerializedName("user_id")
    @Expose
    var userId: Int? = null
    @SerializedName("name")
    @Expose
    var name: String? = null
    @SerializedName("last_name")
    @Expose
    var lastName: String? = null
    @SerializedName("email")
    @Expose
    var email: String? = null
    @SerializedName("status")
    @Expose
    var status: String? = null
    @SerializedName("device_type")
    @Expose
    var deviceType: String? = null
    @SerializedName("device_token")
    @Expose
    var deviceToken: String? = null
    @SerializedName("enable_notification")
    @Expose
    var enableNotification: String? = null
}
