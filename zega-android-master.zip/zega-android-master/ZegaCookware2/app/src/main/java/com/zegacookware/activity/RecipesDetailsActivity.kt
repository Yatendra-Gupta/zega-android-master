package com.zegacookware.activity

import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.viewpager.widget.ViewPager
import com.bumptech.glide.Glide
import com.zegacookware.R
import com.zegacookware.fragment.MyPagerAdapter
import com.zegacookware.model.recipes.RecipesDetailRequest
import com.zegacookware.model.recipes.recipesdetail.FavouriteResponse
import com.zegacookware.model.recipes.recipesdetail.RecipesDetails
import com.zegacookware.model.user.UserResult
import com.zegacookware.network.Constant
import com.zegacookware.util.CommonUtility
import kotlinx.android.synthetic.main.activity_recipes_details.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import kotlin.math.abs


class RecipesDetailsActivity : BaseActivity() {

    private lateinit var dots: Array<TextView?>
    private lateinit var userData: UserResult
    private lateinit var mContext: Context

    companion object {
        var recipesDetails: RecipesDetails? = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recipes_details)
        mContext = this
        userData = CommonUtility.getUserData(Constant.userInfo, this@RecipesDetailsActivity)
        getRecipesDetails("" + intent.getIntExtra("id", 0))

        btnInGre.setOnClickListener {
            viewPagerDetails.currentItem = 0
            val typeface = ResourcesCompat.getFont(this, R.font.poppins_semibold)
            btnInGre.typeface = typeface

            val typeface1 = ResourcesCompat.getFont(this, R.font.poppins_extralight)
            btnInstruction.typeface = typeface1
        }
        btnInstruction.setOnClickListener {
            viewPagerDetails.currentItem = 1
            val typeface = ResourcesCompat.getFont(this, R.font.poppins_semibold)
            btnInstruction.typeface = typeface

            val typeface1 = ResourcesCompat.getFont(this, R.font.poppins_extralight)
            btnInGre.typeface = typeface1
        }
        btnBack.setOnClickListener {
            finish()
        }
        btnStartCooking.setOnClickListener {
            if (CommonUtility.getBooleanPreference("isDeviceAvailable", mContext)) {
                if (CommonUtility.getBooleanPreference(Constant.cookingIsRunning, mContext)) {
                    CommonUtility.openDialogForCookingRunning(mContext)
                    return@setOnClickListener
                }
                if (enableBluetooth()) {
                    startActivity(
                        Intent(this, StartCookingSliderActivity::class.java).putExtra(
                            "id",
                            "" + intent.getIntExtra("id", 0)
                        )
                    )
                }
            } else {
                CommonUtility.openDialogForNotConnectedDevice(
                    "NO ZEGA DEVICE IS\nCURRENTLY\nCONNECTED TO THE APP.",
                    "MANAGE DEVICES",
                    ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
                    mContext
                )
            }
        }
        btnUnFavourite.setOnClickListener {
            if (recipesDetails != null) {
                btnFavourite.visibility = View.VISIBLE
                btnUnFavourite.visibility = View.GONE
                favoriteMethod("1")
            }
        }
        btnFavourite.setOnClickListener {
            if (recipesDetails != null) {
                btnFavourite.visibility = View.GONE
                btnUnFavourite.visibility = View.VISIBLE
                favoriteMethod("0")
            }
        }
    }

    private fun enableBluetooth(): Boolean {
        if (CommonUtility.getBooleanPreference(
                Constant.isDigital,
                this@RecipesDetailsActivity
            )
        ) {
            val mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
            return if (!mBluetoothAdapter!!.isEnabled) {
                val enableBTIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                startActivity(enableBTIntent)
                false
            } else {
                true
            }
        }
        return true
    }

    private fun favoriteMethod(isFavorite: String) {
        Constant.service.favouriteMethod(
            RecipesDetailRequest(
                recepie_id = "" + recipesDetails?.recepieResult?.recepieId,
                user_id = "" + userData.userId,
                favourite_status = isFavorite
            )
        ).apply {
            enqueue(object : Callback<FavouriteResponse> {
                override fun onFailure(call: Call<FavouriteResponse>, t: Throwable) {
                }

                override fun onResponse(
                    call: Call<FavouriteResponse>,
                    response: Response<FavouriteResponse>
                ) {
                    if (response.isSuccessful && response.body()?.status == 1) {
                        val toast = Toast.makeText(
                            mContext,
                            "" + response.body()?.msg?.toUpperCase(),
                            Toast.LENGTH_SHORT
                        )
                        toast.setGravity(Gravity.CENTER, 0, -255)
                        toast.show()

                    }

                }
            })
        }
    }

    private fun addBottomDots() {
        if (dotsLayout == null)
            return

        val dotSize = 2
        dotsLayout.removeAllViews()

        dots = arrayOfNulls<TextView>(dotSize)
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.setMargins(10, 10, 10, 10)
        for (i in dots.indices) {
            dots[i] = TextView(this)
            dots[i]?.height = 16
            dots[i]?.width = 16
            dots[i]?.layoutParams = params
            dots[i]?.setBackgroundResource(R.drawable.selected_dot_gray)
            dotsLayout.addView(dots[i])
        }
    }

    private fun updateBottomDots(curPosition: Int) {
        if (dots == null)
            return

        for (i in dots.indices) {
            if (curPosition == i) {
                dots[i]?.setBackgroundResource(R.drawable.unselected_dot_gray)
            } else {
                dots[i]?.setBackgroundResource(R.drawable.selected_dot_gray)
            }

        }
    }

    private fun getRecipesDetails(recipesId: String) {
        CommonUtility.showProgressDialog(this@RecipesDetailsActivity)
        Constant.service.getRecipeDetails(
            RecipesDetailRequest(
                recepie_id = recipesId,
                user_id = "" + userData.userId
            )
        ).apply {
            enqueue(object : Callback<RecipesDetails> {
                override fun onFailure(call: Call<RecipesDetails>, t: Throwable) {
                    CommonUtility.hideProgressBar()
                }

                override fun onResponse(
                    call: Call<RecipesDetails>,
                    response: Response<RecipesDetails>
                ) {
                    CommonUtility.hideProgressBar()
                    if (response.isSuccessful && response.body()?.status == 1) {
                        recipesDetails = response.body() as RecipesDetails
                        Glide.with(this@RecipesDetailsActivity)
                            .load(Constant.recipesImageBaseUrl + recipesDetails?.recepieResult?.recepieImage)
                            .centerCrop()
                            .into(ivRecipesPic)
                        tvRecipesName.text = recipesDetails?.recepieResult?.recepieTitle

                        CommonUtility.setStringPreference(
                            recipesDetails?.recepieResult?.recepieTime.toString(),
                            "recipesTime",
                            this@RecipesDetailsActivity
                        )
                        CommonUtility.setStringPreference(
                            recipesDetails?.recepieResult?.recepieTemperature.toString(),
                            "recipesTemp",
                            this@RecipesDetailsActivity
                        )

                        if (recipesDetails?.favouriteResult?.isNotEmpty()!!) {
                            val status1 = recipesDetails?.favouriteResult?.get(0)!!.favouriteStatus
                            if (status1 == "1") {
                                btnFavourite.visibility = View.VISIBLE
                                btnUnFavourite.visibility = View.GONE
                            }
                        }
                        init()
                    }
                }

            })
        }
    }

    private fun init() {
        addBottomDots()
        updateBottomDots(0)
        scrollView.isFillViewport = true
        val adapterView = MyPagerAdapter(supportFragmentManager)

        viewPagerDetails.adapter = adapterView
        viewPagerDetails.offscreenPageLimit = 2
        viewPagerDetails.currentItem = 0


        viewPagerDetails.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrollStateChanged(state: Int) {
            }

            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {
            }

            override fun onPageSelected(position: Int) {
                updateBottomDots(position)
                return when (position) {
                    0 -> {
                        val typeface = ResourcesCompat.getFont(
                            this@RecipesDetailsActivity,
                            R.font.poppins_semibold
                        )
                        btnInGre.typeface = typeface

                        val typeface1 = ResourcesCompat.getFont(
                            this@RecipesDetailsActivity,
                            R.font.poppins_extralight
                        )
                        btnInstruction.typeface = typeface1
                    }
                    else -> {
                        viewPagerDetails.currentItem = 1
                        val typeface = ResourcesCompat.getFont(
                            this@RecipesDetailsActivity,
                            R.font.poppins_semibold
                        )
                        btnInstruction.typeface = typeface

                        val typeface1 = ResourcesCompat.getFont(
                            this@RecipesDetailsActivity,
                            R.font.poppins_extralight
                        )
                        btnInGre.typeface = typeface1
                    }
                }

            }

        })
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val dragthreshold = 30

        var downX = 0
        var downY = 0

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX.toInt()
                downY = event.rawY.toInt()
            }

            MotionEvent.ACTION_MOVE -> {
                if (recipesDetails != null) {
                    val distanceX = abs(event.rawX.toInt() - downX)

                    val distanceY = abs(event.rawY.toInt() - downY)

                    if (distanceY > distanceX && distanceY > dragthreshold) {
                        viewPagerDetails.parent.requestDisallowInterceptTouchEvent(false)

                        scrollView.parent.requestDisallowInterceptTouchEvent(true)
                    } else if (distanceX > distanceY && distanceX > dragthreshold) {
                        viewPagerDetails.parent.requestDisallowInterceptTouchEvent(true)

                        scrollView.parent.requestDisallowInterceptTouchEvent(false)
                    }
                }
            }
            MotionEvent.ACTION_UP -> {
                if (recipesDetails != null) {
                    scrollView.parent.requestDisallowInterceptTouchEvent(false)

                    viewPagerDetails.parent.requestDisallowInterceptTouchEvent(false)
                }
            }
        }
        return false

    }

}
