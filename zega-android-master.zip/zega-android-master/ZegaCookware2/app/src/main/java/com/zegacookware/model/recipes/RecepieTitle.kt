package com.zegacookware.model.recipes

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class RecepieTitle {

    @SerializedName("recepie_id")
    @Expose
    var recepieId: Int? = null
    @SerializedName("recepie_title")
    @Expose
    var recepieTitle: String? = null
    @SerializedName("recepie_image")
    @Expose
    var recepieImage: String? = null

}
