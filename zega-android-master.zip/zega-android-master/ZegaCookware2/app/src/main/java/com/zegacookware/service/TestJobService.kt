package com.zegacookware.service

import android.app.job.JobParameters
import android.app.job.JobService
import android.content.Intent
import android.os.Build
import androidx.annotation.RequiresApi
import com.zegacookware.util.CommonUtility


class TestJobService : JobService() {
    private val TAG = "SyncService"

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onStartJob(params: JobParameters?): Boolean {
        val service = Intent(applicationContext, DigitalTimerService::class.java)
        applicationContext.startService(service)
        CommonUtility.scheduleJob(applicationContext) // reschedule the job
        return true
    }

    override fun onStopJob(params: JobParameters?): Boolean {
        return true
    }
}