package com.zegacookware.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.zegacookware.R
import com.zegacookware.interfaces.SetOnItemClickListener
import com.zegacookware.model.recipes.RecepieTitle
import com.zegacookware.network.Constant
import kotlinx.android.synthetic.main.item_recipes_title.view.*

class RecipesTitleAdapter(
    var mContext: Context,
    var categoryList: List<RecepieTitle>,
    var setOnItemClickListener: SetOnItemClickListener,
    var isGrid:Boolean
) :
    RecyclerView.Adapter<RecipesTitleAdapter.RecipesViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecipesViewHolder {
        val view =
            LayoutInflater.from(mContext).inflate(R.layout.item_recipes_title, parent, false)
        return RecipesViewHolder(view)
    }

    override fun getItemCount(): Int {
        return categoryList.size
    }

    override fun onBindViewHolder(holder: RecipesViewHolder, position: Int) {

        if (isGrid){
            holder.itemView.lytWithText.visibility=View.GONE
            holder.itemView.lytWithImage.visibility=View.VISIBLE
            holder.itemView.divider.visibility=View.GONE
        }else{
            holder.itemView.lytWithText.visibility=View.VISIBLE
            holder.itemView.lytWithImage.visibility=View.GONE
            holder.itemView.divider.visibility=View.VISIBLE
        }
        holder.itemView.tvRecipesImage.text = categoryList[position].recepieTitle
        Glide.with(mContext)
            .load(Constant.recipesImageBaseUrl+categoryList[position].recepieImage)
            .centerCrop()
            .into(holder.itemView.ivRecipes1)

        holder.itemView.tvRecipesTitle.text = categoryList[position].recepieTitle
        holder.itemView.setOnClickListener { setOnItemClickListener.onItemClick(position) }
        if (position==categoryList.size-1){
            holder.itemView.divider.visibility=View.GONE
        }
    }

    class RecipesViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    }
}