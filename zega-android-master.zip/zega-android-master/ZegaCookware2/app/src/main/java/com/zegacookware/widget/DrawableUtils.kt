package com.zegacookware.widget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.StateListDrawable

import androidx.annotation.ColorRes
import androidx.annotation.DrawableRes
import androidx.annotation.IntRange
import androidx.core.content.ContextCompat


object DrawableUtils {
    fun getStateListDrawable(
        context: Context,
        @DrawableRes imageResource: Int,
        @ColorRes desiredColor: Int,
        @IntRange(from = 0, to = 255) disableAlpha: Int
    ): StateListDrawable {
        // Create the colorized image (pressed state)
        val one = BitmapFactory.decodeResource(context.resources, imageResource)

        val oneCopy = Bitmap.createBitmap(one.width, one.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(oneCopy)
        val p = Paint()
        val color = ContextCompat.getColor(context, desiredColor)
        p.colorFilter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
        c.drawBitmap(one, 0f, 0f, p)
        // Create the disabled bitmap for the disabled state
        val disabled = BitmapFactory.decodeResource(context.resources, imageResource)
        val disabledCopy =
            Bitmap.createBitmap(disabled.width, disabled.height, Bitmap.Config.ARGB_8888)
        val disabledCanvas = Canvas(disabledCopy)
        val alphaPaint = Paint()
        alphaPaint.alpha = disableAlpha
        disabledCanvas.drawBitmap(disabled, 0f, 0f, alphaPaint)

        val stateListDrawable = StateListDrawable()
        // Pressed State
        stateListDrawable.addState(
            intArrayOf(android.R.attr.state_pressed),
            BitmapDrawable(context.resources, oneCopy)
        )
        // Disabled State
        stateListDrawable.addState(
            intArrayOf(-android.R.attr.state_enabled),
            BitmapDrawable(context.resources, disabledCopy)
        )
        // - symbol means opposite, in this case "disabled"
        // Default State
        stateListDrawable.addState(intArrayOf(), ContextCompat.getDrawable(context, imageResource))
        return stateListDrawable
    }
}