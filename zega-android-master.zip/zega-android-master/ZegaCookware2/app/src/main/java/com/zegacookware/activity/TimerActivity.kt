package com.zegacookware.activity

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.content.ContextCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.zegacookware.R
import com.zegacookware.interfaces.PopupWindowClick
import com.zegacookware.network.Constant
import com.zegacookware.service.AnalogueButtonService
import com.zegacookware.util.CommonUtility
import com.zegacookware.util.blurBackground.PopupWindowRemoveDevice
import kotlinx.android.synthetic.main.activity_timer.*


class TimerActivity : BaseActivity() {

    var count = 0
    private lateinit var mContext: Context
    private val CODE_DRAW_OVER_OTHER_APP_PERMISSION = 2084
    private var timeTemp: Long = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_timer)

        overridePendingTransition(0, 0)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        mContext = this
        CommonUtility.setBooleanPreference(true, Constant.cookingIsRunning, mContext)

        btnClose.setOnClickListener {
            if (CommonUtility.getBooleanPreference(Constant.cookingIsRunning, mContext)) {
                openCancelDialog()
            } else {
                startActivity(
                    Intent(
                        applicationContext,
                        MainActivity::class.java
                    ).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                finish()
            }
        }


        if (intent.getBooleanExtra("isFromService", false)) {
            count = CommonUtility.getStringPreference("count", mContext).toInt()

            temperatureView.visibility = View.GONE
            lytTimerTime.visibility = View.VISIBLE

            tvAlertTime.text =
                "READY AT " + CommonUtility.getStringPreference("clockTime", mContext)
            updateImage()
            LocalBroadcastManager.getInstance(mContext)
                .sendBroadcast(Intent("AppIsBackground").putExtra("isBackground", true))
        } else {
            showHideTempAndTimer()
            startService(Intent(this, AnalogueButtonService::class.java))
        }

    }

    private fun showHideTempAndTimer() {
        temperatureView.visibility = View.GONE
        lytTimerTime.visibility = View.VISIBLE
        tvBelowTextMsg.text = "SELF COOKING\nLEAVE ZEGA\nTO STAND"
        timeTemp = CommonUtility.getStringPreference("recipesTime", mContext).toLong()
        CommonUtility.setStringPreference(
            CommonUtility.getUpdateTime(timeTemp.toInt()),
            "clockTime",
            mContext
        )
        tvAlertTime.text = "READY AT " + CommonUtility.getUpdateTime(timeTemp.toInt())
        updateImage()
    }

    private var countDownRegister = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            runOnUiThread {
                tvTimer.text = intent?.getStringExtra("countTime")
            }
        }
    }
    private var segmentCountRegister = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            count = intent!!.getIntExtra("count", 0)
            updateImage()
        }
    }

    private fun updateImage() {
        if (count == 0) {
            timer_1.alpha = 0f
            CommonUtility.setStringPreference(count.toString(), "count", mContext)
            timer_2.alpha = 0f
            timer_3.alpha = 0f
            timer_4.alpha = 0f
            timer_5.alpha = 0f
            timer_6.alpha = 0f
            timer_7.alpha = 0f
            timer_8.alpha = 0f
            timer_9.alpha = 0f
            timer_10.alpha = 0f
            timer_11.alpha = 0f
            timer_12.alpha = 0f
        }
        if (count == 1) {
            timer_1.alpha = 1f
//            CommonUtility.setStringPreference(count.toString(), "count", mContext)
            timer_2.alpha = 0f
            timer_3.alpha = 0f
            timer_4.alpha = 0f
            timer_5.alpha = 0f
            timer_6.alpha = 0f
            timer_7.alpha = 0f
            timer_8.alpha = 0f
            timer_9.alpha = 0f
            timer_10.alpha = 0f
            timer_11.alpha = 0f
            timer_12.alpha = 0f
        }
        if (count == 2) {
            timer_1.alpha = 1f
            timer_2.alpha = 1f
            timer_3.alpha = 0f
            timer_4.alpha = 0f
            timer_5.alpha = 0f
            timer_6.alpha = 0f
            timer_7.alpha = 0f
            timer_8.alpha = 0f
            timer_9.alpha = 0f
            timer_10.alpha = 0f
            timer_11.alpha = 0f
            timer_12.alpha = 0f
        }
        if (count == 3) {
            timer_1.alpha = 1f
            timer_2.alpha = 1f
            timer_3.alpha = 1f
            timer_4.alpha = 0f
            timer_5.alpha = 0f
            timer_6.alpha = 0f
            timer_7.alpha = 0f
            timer_8.alpha = 0f
            timer_9.alpha = 0f
            timer_10.alpha = 0f
            timer_11.alpha = 0f
            timer_12.alpha = 0f
        }
        if (count == 4) {
            timer_1.alpha = 1f
            timer_2.alpha = 1f
            timer_3.alpha = 1f
            timer_4.alpha = 1f
            timer_5.alpha = 0f
            timer_6.alpha = 0f
            timer_7.alpha = 0f
            timer_8.alpha = 0f
            timer_9.alpha = 0f
            timer_10.alpha = 0f
            timer_11.alpha = 0f
            timer_12.alpha = 0f
        }
        if (count == 5) {
            timer_1.alpha = 1f
            timer_2.alpha = 1f
            timer_3.alpha = 1f
            timer_4.alpha = 1f
            timer_5.alpha = 1f
            timer_6.alpha = 0f
            timer_7.alpha = 0f
            timer_8.alpha = 0f
            timer_9.alpha = 0f
            timer_10.alpha = 0f
            timer_11.alpha = 0f
            timer_12.alpha = 0f
        }
        if (count == 6) {
            timer_1.alpha = 1f
            timer_2.alpha = 1f
            timer_3.alpha = 1f
            timer_4.alpha = 1f
            timer_5.alpha = 1f
            timer_6.alpha = 1f
            timer_7.alpha = 0f
            timer_8.alpha = 0f
            timer_9.alpha = 0f
            timer_10.alpha = 0f
            timer_11.alpha = 0f
            timer_12.alpha = 0f
        }
        if (count == 7) {
            timer_1.alpha = 1f
            timer_2.alpha = 1f
            timer_3.alpha = 1f
            timer_4.alpha = 1f
            timer_5.alpha = 1f
            timer_6.alpha = 1f
            timer_7.alpha = 1f
            timer_8.alpha = 0f
            timer_9.alpha = 0f
            timer_10.alpha = 0f
            timer_11.alpha = 0f
            timer_12.alpha = 0f
        }
        if (count == 8) {
            timer_1.alpha = 1f
            timer_2.alpha = 1f
            timer_3.alpha = 1f
            timer_4.alpha = 1f
            timer_5.alpha = 1f
            timer_6.alpha = 1f
            timer_7.alpha = 1f
            timer_8.alpha = 1f
            timer_9.alpha = 0f
            timer_10.alpha = 0f
            timer_11.alpha = 0f
            timer_12.alpha = 0f
        }
        if (count == 9) {
            timer_1.alpha = 1f
            timer_2.alpha = 1f
            timer_3.alpha = 1f
            timer_4.alpha = 1f
            timer_5.alpha = 1f
            timer_6.alpha = 1f
            timer_7.alpha = 1f
            timer_8.alpha = 1f
            timer_9.alpha = 1f
            timer_10.alpha = 0f
            timer_11.alpha = 0f
            timer_12.alpha = 0f
        }
        if (count == 10) {
            timer_1.alpha = 1f
            timer_2.alpha = 1f
            timer_3.alpha = 1f
            timer_4.alpha = 1f
            timer_5.alpha = 1f
            timer_6.alpha = 1f
            timer_7.alpha = 1f
            timer_8.alpha = 1f
            timer_9.alpha = 1f
            timer_10.alpha = 1f
            timer_11.alpha = 0f
            timer_12.alpha = 0f
        }
        if (count == 11) {
            timer_1.alpha = 1f
            timer_2.alpha = 1f
            timer_3.alpha = 1f
            timer_4.alpha = 1f
            timer_5.alpha = 1f
            timer_6.alpha = 1f
            timer_7.alpha = 1f
            timer_8.alpha = 1f
            timer_9.alpha = 1f
            timer_10.alpha = 1f
            timer_11.alpha = 1f
            timer_12.alpha = 0f
        }
        if (count == 12) {
            timer_1.alpha = 1f
            timer_2.alpha = 1f
            timer_3.alpha = 1f
            timer_4.alpha = 1f
            timer_5.alpha = 1f
            timer_6.alpha = 1f
            timer_7.alpha = 1f
            timer_8.alpha = 1f
            timer_9.alpha = 1f
            timer_10.alpha = 1f
            timer_11.alpha = 1f
            timer_12.alpha = 1f
        }
    }

    private fun createHomeButton() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, CODE_DRAW_OVER_OTHER_APP_PERMISSION)
        }
    }

    /**
     * Set and initialize the view elements.
     */
    /**
     * Set and initialize the view elements.
     */
    private fun startServiceForCooking() {
        CommonUtility.setBooleanPreference(
            true,
            Constant.cookingIsRunning,
            mContext
        )
        startActivity(
            Intent(
                mContext,
                MainActivity::class.java
            ).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == CODE_DRAW_OVER_OTHER_APP_PERMISSION) {
            //Check if the permission is granted or not.
            // Settings activity never returns proper value so instead check with following method
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Settings.canDrawOverlays(this)) {
                    startServiceForCooking()
                } else { //Permission is not available
                    createHomeButton()
                }
            } else {
                startServiceForCooking()
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    private fun openCancelDialog() {
        PopupWindowRemoveDevice.Builder<PopupWindowRemoveDevice>(
            mContext as Activity,
            "BROWSE", "CANCEL",
            "WOULD YOU LIKE\nTO CANCEL COOKING\nOR BROWSE THE APP\nWHILE COOKING \nCONTINUES?",
            ContextCompat.getDrawable(this, R.drawable.ic_right)!!,
            object : PopupWindowClick {
                override fun onButton1Click() {

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (Settings.canDrawOverlays(mContext)) {
                            startServiceForCooking()
                        } else {
                            createHomeButton()
                        }
                    } else {
                        startServiceForCooking()
                    }

                }

                override fun onButton2Click() {
                    CommonUtility.setBooleanPreference(
                        false,
                        Constant.cookingIsRunning,
                        mContext
                    )
                    LocalBroadcastManager.getInstance(mContext).sendBroadcast(
                        Intent("isFromServiceForTimer11").putExtra(
                            "isFromServiceForTimer",
                            false
                        )
                    )
                }
            }
        ).setContentView(R.layout.dialog_remove_device)
            .setGravity(Gravity.BOTTOM)
            .setScaleRatio(0.1f)
            .setBlurRadius(Constant.blurRadius)
            .setDismissOnClickBack(false)
            .setDismissOnTouchBackground(false)
            .build()
            .show()
    }

    private fun initializeBroadcast() {

        LocalBroadcastManager.getInstance(mContext).unregisterReceiver(countDownRegister)
        LocalBroadcastManager.getInstance(mContext).unregisterReceiver(segmentCountRegister)
        LocalBroadcastManager.getInstance(mContext).registerReceiver(
            countDownRegister,
            IntentFilter("countDown")
        )
        LocalBroadcastManager.getInstance(mContext).registerReceiver(
            segmentCountRegister,
            IntentFilter("segmentCountRegister")
        )
    }


    override fun onStart() {
        super.onStart()
        Handler().postDelayed({
            LocalBroadcastManager.getInstance(mContext)
                .sendBroadcast(Intent("AppIsBackground").putExtra("isBackground", true))
        }, 200)
        initializeBroadcast()
        if (CommonUtility.getBooleanPreference(Constant.cookingIsRunning, mContext)) {
            count = CommonUtility.getStringPreference("count", mContext).toInt()
            updateImage()
        }
    }

    override fun onBackPressed() {
        if (CommonUtility.getBooleanPreference(Constant.cookingIsRunning, mContext)) {
            openCancelDialog()
        } else {
            startActivity(
                Intent(
                    applicationContext,
                    MainActivity::class.java
                ).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            )
            finish()
        }
        //super.onBackPressed()
    }
}
