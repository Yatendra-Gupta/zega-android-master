package com.zegacookware.widget.item

/**
 * Created by svetlin on 9.12.17.
 */
enum class ItemType {
    SIMPLE_TEXT,
    STICKY
}