package com.zegacookware.activity

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK
import android.content.Intent.FLAG_ACTIVITY_NEW_TASK
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.InputFilter
import android.text.SpannableStringBuilder
import android.text.TextPaint
import android.text.method.HideReturnsTransformationMethod
import android.text.method.LinkMovementMethod
import android.text.method.PasswordTransformationMethod
import android.text.style.ClickableSpan
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.iid.FirebaseInstanceId
import com.zegacookware.R
import com.zegacookware.activity.manage_device.DeviceSelectActivity
import com.zegacookware.activity.setting.WebViewActivity
import com.zegacookware.interfaces.ClickOnFavouritePopup
import com.zegacookware.model.user.LoginRequest
import com.zegacookware.model.user.SignupResponse
import com.zegacookware.model.user.UserModel
import com.zegacookware.network.Constant
import com.zegacookware.util.CommonUtility
import com.zegacookware.util.blurBackground.BlurPopupWindowTemp
import kotlinx.android.synthetic.main.activity_sign_up.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class SignUpActivity : AppCompatActivity() {
    private var isAgreeToterms: Boolean = false
    private var deviceToken: String = ""
    private lateinit var mContext: Context
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)
        mContext = this@SignUpActivity

        hideKeyboard()
        etEmail.filters = etEmail.filters + InputFilter.AllCaps()

        ivBack.setOnClickListener {
            finish()
        }
        btnSignUp.setOnClickListener {
            postSignup()
        }
        cbTermCondition.setOnCheckedChangeListener(object : CompoundButton.OnCheckedChangeListener {
            override fun onCheckedChanged(buttonView: CompoundButton?, isChecked: Boolean) {
                isAgreeToterms = isChecked
            }
        })

        btnShowPass.setOnClickListener {
            if (ContextCompat.getDrawable(
                    mContext,
                    R.drawable.eye_show
                )!!.constantState == btnShowPass.drawable.constantState
            ) {
                etPassword.transformationMethod = PasswordTransformationMethod.getInstance()
                btnShowPass.setImageDrawable(
                    ContextCompat.getDrawable(
                        mContext,
                        R.drawable.eye_hide
                    )
                )
            } else {
                etPassword.transformationMethod = HideReturnsTransformationMethod.getInstance()
                btnShowPass.setImageDrawable(
                    ContextCompat.getDrawable(
                        mContext,
                        R.drawable.eye_show
                    )
                )
            }
            etPassword.placeCursorToEnd()
        }
        btnShowConfPass.setOnClickListener {
            if (ContextCompat.getDrawable(
                    mContext,
                    R.drawable.eye_show
                )!!.constantState == btnShowConfPass.drawable.constantState
            ) {
                etConfirmPassword.transformationMethod = PasswordTransformationMethod.getInstance()
                btnShowConfPass.setImageDrawable(
                    ContextCompat.getDrawable(
                        mContext,
                        R.drawable.eye_hide
                    )
                )

            } else {
                etConfirmPassword.transformationMethod =
                    HideReturnsTransformationMethod.getInstance()
                btnShowConfPass.setImageDrawable(
                    ContextCompat.getDrawable(
                        mContext,
                        R.drawable.eye_show
                    )
                )
            }
            etConfirmPassword.placeCursorToEnd()
        }
        FirebaseInstanceId.getInstance().instanceId
            .addOnCompleteListener(OnCompleteListener { task ->
                if (!task.isSuccessful) {
                    return@OnCompleteListener
                }
                // Get new Instance ID token
                deviceToken = task.result?.token!!
            })

        singleTextView(tvTerms, "TERMS OF SERVICE", "PRIVACY POLICY")
    }

    private fun postSignup() {
        if (etFirstName.text.toString().isEmpty()) {
            CommonUtility.openDialog(
                "PLEASE ENTER FIRST NAME",
                "OK",
                ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
                mContext
            )
            return
        }
        if (etLastName.text.toString().isEmpty()) {
            CommonUtility.openDialog(
                "PLEASE ENTER LAST NAME",
                "OK",
                ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
                mContext
            )
            return
        }
        if (etEmail.text.toString().isEmpty()) {
            CommonUtility.openDialog(
                "PLEASE ENTER EMAIL",
                "OK",
                ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
                mContext
            )
            return
        }
        if (!CommonUtility.isEmailValid(etEmail.text.toString())) {
            CommonUtility.openDialog(
                "PLEASE ENTER VALID EMAIL",
                "OK",
                ContextCompat.getDrawable(this, R.drawable.ic_alert)!!,
                this
            )
            return
        }
        if (etPassword.text.toString().isEmpty()) {
            CommonUtility.openDialog(
                "PLEASE ENTER PASSWORD",
                "OK",
                ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
                mContext
            )
            return
        }
        if (etPassword.text.toString().length < 8) {
            CommonUtility.openDialog(
                "PLEASE ENTER ATLEAST 8 CHARACTER PASSWORD",
                "OK",
                ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
                mContext
            )
            return
        }
        if (etConfirmPassword.text.toString().isEmpty()) {
            CommonUtility.openDialog(
                "PLEASE ENTER PASSWORD AGAIN TO CONFIRM",
                "OK",
                ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
                mContext
            )
            return
        }
        if (!etPassword.text.toString().equals(etConfirmPassword.text.toString(), false)) {
            etPassword.setText("")
            etConfirmPassword.setText("")
            CommonUtility.openDialog(
                "PASSWORDS DO NOT MATCH, PLEASE RE-ENTER",
                "OK",
                ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
                mContext
            )
            return
        }
        if (!isAgreeToterms) {
            CommonUtility.openDialog(
                "PLEASE ACCEPT TERMS OF SERVICE & PRIVACY POLICY.",
                "OK",
                ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
                mContext
            )
            return
        }
        CommonUtility.showProgressDialog(mContext)

        Constant.service.signUpMethod(
            LoginRequest(
                name = etFirstName.text.toString(),
                last_name = etLastName.text.toString(),
                user_email = etEmail.text.toString().trim(),
                password = etPassword.text.toString().trim(),
                device_token = deviceToken,
                device_type = "Android"
            )
        ).apply {
            enqueue(object : Callback<SignupResponse> {
                override fun onFailure(call: Call<SignupResponse>, t: Throwable) {
                    CommonUtility.hideProgressBar()

                    CommonUtility.openDialog(
                        "SOMETHING WENT WRONG",
                        "OK",
                        ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
                        mContext
                    )
//                        progressBar.stop()
//                        progressBar.visibility = View.VISIBLE
                }

                override fun onResponse(
                    call: Call<SignupResponse>,
                    response: Response<SignupResponse>
                ) {
                    CommonUtility.hideProgressBar()
                    if (response.isSuccessful && response.body()?.status == 1) {

                        UserModel.userInfo = response.body()?.userResult!!
                        CommonUtility.setUserData(
                            response.body()?.userResult!!,
                            Constant.userInfo,
                            this@SignUpActivity
                        )
                        CommonUtility.setBooleanPreference(
                            true,
                            Constant.isLoggedIn,
                            this@SignUpActivity
                        )
                        openSuccessDialog(
                            response.body()?.msg!!,
                            "Done",
                            ContextCompat.getDrawable(mContext, R.drawable.ic_right)!!,
                            this@SignUpActivity
                        )

                        CommonUtility.setStringPreference(
                            etEmail.text.toString(),
                            "email",
                            this@SignUpActivity
                        )
                        CommonUtility.setStringPreference(
                            etPassword.text.toString(),
                            "password",
                            this@SignUpActivity
                        )
                    } else if (response.isSuccessful && response.body()?.status == 0) {
                        CommonUtility.openDialog(
                            response.body()?.msg!!,
                            "OK",
                            ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
                            mContext
                        )
                    } else {
                        CommonUtility.openDialog(
                            "SOMETHING WENT WRONG",
                            "OK",
                            ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
                            mContext
                        )
                    }
                }
            })
        }
    }

    fun openSuccessDialog(msgString: String, buttonText: String, ids: Drawable, mContext: Context) {
        BlurPopupWindowTemp.Builder<BlurPopupWindowTemp>(
            mContext as Activity,
            msgString,
            buttonText,
            "Success!",
            ids, object : ClickOnFavouritePopup {
                override fun onItemClick(position: Int, cusineType: String) {
                    startActivity(
                        Intent(
                            this@SignUpActivity,
                            DeviceSelectActivity::class.java
                        ).putExtra("isFromSignUp", true)
                            .setFlags(FLAG_ACTIVITY_NEW_TASK or FLAG_ACTIVITY_CLEAR_TASK)
                    )
                    finish()
                }
            }
        ).setContentView(R.layout.dialog_success_message)
            .setGravity(Gravity.CENTER)
            .setScaleRatio(0.1f)
            .setBlurRadius(Constant.blurRadius)
            .setDismissOnClickBack(false)
            .setDismissOnTouchBackground(false)
            .build()
            .show()
    }

    private fun EditText.placeCursorToEnd() {
        this.setSelection(this.text.length)
    }

    private fun AppCompatActivity.hideKeyboard() {
        val view = this.currentFocus
        if (view != null) {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(view.windowToken, 0)
        }
        // else {
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        // }
    }

    private fun singleTextView(
        textView: TextView,
        terms: String,
        privacy: String
    ) {

        val spanText = SpannableStringBuilder()
        spanText.append("By signing up, I agree to the ")
        spanText.append(terms)
        spanText.setSpan(object : ClickableSpan() {
            override fun onClick(widget: View) {
                startActivity(
                    Intent(this@SignUpActivity, WebViewActivity::class.java)
                        .putExtra("header", "TERMS OF SERVICE")
                        .putExtra("url", Constant.termsWebUrl)
                )
            }

            override fun updateDrawState(textPaint: TextPaint) {
                textPaint.color = ContextCompat.getColor(
                    this@SignUpActivity,
                    R.color.colorAccent
                )    // you can use custom color
                textPaint.isUnderlineText = false    // this remove the underline
            }
        }, spanText.length - terms.length, spanText.length, 0)
        spanText.append(" & ")
        spanText.append(privacy)
        spanText.setSpan(object : ClickableSpan() {
            override fun onClick(widget: View) {
                startActivity(
                    Intent(this@SignUpActivity, WebViewActivity::class.java)
                        .putExtra("header", "PRIVACY POLICY")
                        .putExtra("url", Constant.privacyPolicyUrl)
                )
            }

            override fun updateDrawState(textPaint: TextPaint) {
                textPaint.color = ContextCompat.getColor(
                    this@SignUpActivity,
                    R.color.colorAccent
                )    // you can use custom color
                textPaint.isUnderlineText = false    // this remove the underline
            }
        }, spanText.length - privacy.length, spanText.length, 0)

        textView.movementMethod = LinkMovementMethod.getInstance()
        textView.setText(spanText, TextView.BufferType.SPANNABLE)
    }

}
