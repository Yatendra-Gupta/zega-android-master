package com.zegacookware.util

import android.bluetooth.BluetoothGattCharacteristic

object BluetoothUtility {

//    private fun bluetoothCharacteristic(mBluetoothGatt: BluetoothGatt): BluetoothGattCharacteristic {
//        val mCustomService =
//            mBluetoothGatt.getService(UUID.fromString("0000FFF0-0000-1000-8000-00805F9B34FB"))
//
////        if (mCustomService == null) {
////            Log.w("Test", "Custom BLE Service not found on write")
////            return null
////        }
//        /*get the read characteristic from the service*/
//        return mCustomService.getCharacteristic(UUID.fromString("0000FFF5-0000-1000-8000-00805F9B34FB"))
//    }

    fun readRecipeTime(mWriteCharacteristic: BluetoothGattCharacteristic) {
//        val mWriteCharacteristic = bluetoothCharacteristic(mBluetoothGatt)
        val byte = ByteArray(6)
        byte[0] = 0x08
        byte[1] = 0x25
        byte[2] = 0x00
        byte[3] = 0x00
        byte[4] = 0x00
        byte[5] = 0x00
        mWriteCharacteristic.value = byte

//        if (!mBluetoothGatt.writeCharacteristic(mWriteCharacteristic)) {
//            Log.w("Test", "Failed to write characteristic")
//        }

    }

    fun setTimeAndTemp(mWriteCharacteristic: BluetoothGattCharacteristic) {
        val byte = ByteArray(6)
        byte[0] = 0x01
        byte[1] = 30//temp
        byte[2] = (10 and 0xFF)//time
        byte[3] = ((10 shr 8) and 0xFF)

        mWriteCharacteristic.value = byte
    }

    fun confirmAlarm(mWriteCharacteristic: BluetoothGattCharacteristic) {
//        val mWriteCharacteristic = bluetoothCharacteristic(mBluetoothGatt)
        val byte = ByteArray(5)
        byte[0] = 0x04
        mWriteCharacteristic.value = byte
    }

    fun activateRealTimeDataNotify(mWriteCharacteristic: BluetoothGattCharacteristic, isON: Boolean) {

        val byte = ByteArray(6)
        byte[0] = 0x0B
        if (isON) {
            byte[1] = 0x01
        } else {
            byte[1] = 0x00
        }
        byte[2] = 0x00
        byte[3] = 0x00
        byte[4] = 0x00
        byte[5] = 0x00
        mWriteCharacteristic.value = byte
    }

    fun doneAlarm(mWriteCharacteristic: BluetoothGattCharacteristic) {
//        val mWriteCharacteristic = bluetoothCharacteristic(mBluetoothGatt)

        val byte = ByteArray(5)
        byte[0] = 0x03
        mWriteCharacteristic.value = byte
    }

    fun readFireWare(mWriteCharacteristic: BluetoothGattCharacteristic) {
//        val mWriteCharacteristic = bluetoothCharacteristic(mBluetoothGatt)

        val byte = ByteArray(6)
        byte[0] = 0x08
        byte[1] = 0x23
        mWriteCharacteristic.value = byte
    }
}