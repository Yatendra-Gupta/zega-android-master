package com.zegacookware.activity.bl

import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.zegacookware.R
import com.zegacookware.activity.BaseActivity
import com.zegacookware.activity.MainActivity
import com.zegacookware.interfaces.PopupWindowClick
import com.zegacookware.model.user.UserModel
import com.zegacookware.network.Constant
import com.zegacookware.service.DigitalTimerService
import com.zegacookware.util.CommonUtility
import com.zegacookware.util.blurBackground.PopupWindowRemoveDevice
import kotlinx.android.synthetic.main.activity_digital_timer.*

class DigitalTimerActivity : BaseActivity() {

    private var sameCount: Int = -1
    private var isConnect: Boolean = false
    var count = 0
    private lateinit var mContext: Context
    private val CODE_DRAW_OVER_OTHER_APP_PERMISSION = 2084
    private lateinit var mDeviceAddress: String
    private var recipesTime: Long = 0
    private var tag: String = "DigitalTimerActivity"
    private var isShowManageDevice: Boolean = false
//    private var countDown: CountDownTimer? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_digital_timer)

        overridePendingTransition(0, 0)
//        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        mContext = this

        Handler().postDelayed({
            if (!CommonUtility.getBooleanPreference(Constant.cookingIsRunning, mContext)) {
                enableBluetooth()
            }
            initializationServiceData()
        }, 100)

        btnClose.setOnClickListener {
            if (CommonUtility.getBooleanPreference(Constant.cookingIsRunning, mContext)) {
                openCancelDialog()
            } else {
                mContext.startActivity(
                    Intent(
                        mContext,
                        MainActivity::class.java
                    ).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                finish()
            }
        }
        Log.d("Activity =====>>>>", "DigitalTimerActivity")

    }

    private fun enableBluetooth() {
        val mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        if (!mBluetoothAdapter!!.isEnabled) {
            val enableBTIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivity(enableBTIntent)
        }
    }

    @SuppressLint("SetTextI18n")
    private fun initializationServiceData() {
        recipesTime =
            CommonUtility.getStringPreference("recipesTime", applicationContext).toLong()
        mDeviceAddress = CommonUtility.getStringPreference(
            "deviceId",
            mContext
        )

        if (!intent.getBooleanExtra(
                "isFromService",
                false
            ) && !intent.getBooleanExtra("isFromServiceForTimer", false)
        ) {
            startServiceForTemp()
        } else if (intent.getBooleanExtra(
                "isFromService",
                false
            ) && !intent.getBooleanExtra("isFromServiceForTimer", false)
        ) {
            Glide.with(this).asGif().load(R.raw.heating_temp).apply(
                RequestOptions.diskCacheStrategyOf(
                    DiskCacheStrategy.NONE
                )
            ).into(ivTempImage)
            tvBelowTextMsg.text = "PLEASE WAIT FOR\nZEGA TO HEAT UP\nTO TEMPERATURE"
            CommonUtility.setBooleanPreference(true, Constant.isShowTemperatureView, mContext)
            temperatureView.visibility = View.VISIBLE
            lytTimerTime.visibility = View.GONE
            isConnect = false
            count = CommonUtility.getStringPreference("count", mContext).toInt()
            updateImage()
        } else if (intent.getBooleanExtra(
                "isFromService",
                false
            ) && intent.getBooleanExtra("isFromServiceForTimer", false)
        ) {
            CommonUtility.setBooleanPreference(true, Constant.cookingIsRunning, mContext)
            tvBelowTextMsg.text = "SELF COOKING\nLEAVE ZEGA\nTO STAND"
            count = CommonUtility.getStringPreference("count", mContext).toInt()
            temperatureView.visibility = View.GONE
            lytTimerTime.visibility = View.VISIBLE
            hideAllImages()
            tvAlertTime.text =
                "READY AT " + CommonUtility.getStringPreference("clockTime", mContext)
            updateImage()
        }
    }

    private fun startServiceForTemp() {
//        UserModel.isShowFirstTime = true
        CommonUtility.setBooleanPreference(true, Constant.isShowTemperatureView, mContext)
        CommonUtility.showProgressDialogTemp(mContext)
        val mIntent =
            Intent(this, DigitalTimerService::class.java)
        startService(mIntent)
        tvBelowTextMsg.text = "PLEASE WAIT FOR\nZEGA TO HEAT UP\nTO TEMPERATURE"

        // tvCountDown.visibility = View.VISIBLE

        Handler().postDelayed({
            CommonUtility.hideProgressBar()
            if (!CommonUtility.getBooleanPreference(Constant.cookingIsRunning, mContext)) {
                isShowManageDevice = true
                stopService(Intent(mContext, DigitalTimerService::class.java))
                CommonUtility.openDialogForNotConnectedDevice(
                    "NO ZEGA DEVICE IS\nCURRENTLY\nCONNECTED TO THE APP.",
                    "MANAGE DEVICES",
                    ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
                    mContext
                )
            }
        }, 15000)

//        countDown = object : CountDownTimer(15000, 1000) {
//            override fun onFinish() {
//                if (countDown != null) {
//                    countDown?.cancel()
//                    countDown = null
//                    tvCountDown.visibility = View.GONE
//                }
//            }
//
//            override fun onTick(millisUntilFinished: Long) {
//                if (!CommonUtility.getBooleanPreference(Constant.cookingIsRunning, mContext)) {
//                    val seconds = (millisUntilFinished / 1000 % 60).toString()
//                    tvCountDown.text = "$seconds sec"
//                } else {
//                    if (countDown != null) {
//                        countDown?.cancel()
//                        countDown = null
//                        tvCountDown.visibility = View.GONE
//                    }
//                }
//            }
//        }.start()
    }

    private var countDownRegister = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            runOnUiThread {
                tvTimer.text = intent?.getStringExtra("countTime")
            }
        }
    }
    //

    private var segmentCountRegister = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            count = intent!!.getIntExtra("count", 0)
            runOnUiThread {
                if (count != sameCount) {
                    sameCount = count
                    updateImage()
                }
            }
        }
    }

    private var startSelfCooking = object : BroadcastReceiver() {

        override fun onReceive(context: Context?, intent: Intent?) {
            CommonUtility.setBooleanPreference(true, Constant.cookingIsRunning, mContext)
            tvBelowTextMsg.text = "SELF COOKING\nLEAVE ZEGA\nTO STAND"
            count = CommonUtility.getStringPreference("count", mContext).toInt()
            temperatureView.visibility = View.GONE
            lytTimerTime.visibility = View.VISIBLE
            hideAllImages()
            tvAlertTime.text =
                "READY AT " + CommonUtility.getStringPreference("clockTime", mContext)
            updateImage()

            CommonUtility.setBooleanPreference(
                false,
                Constant.isShowTemperatureView,
                mContext
            )
        }

    }

    private fun updateImage() {
        if (count == 0 && !isConnect) {
            Thread.sleep(100)
            if (CommonUtility.getBooleanPreference(Constant.isShowTemperatureView, mContext)) {
                Glide.with(applicationContext).asGif().load(R.raw.heating_temp).apply(
                    RequestOptions.diskCacheStrategyOf(
                        DiskCacheStrategy.NONE
                    )
                ).into(ivTempImage)
                isConnect = true
                val mp = MediaPlayer.create(mContext, R.raw.double_beep)
                if (mp != null && !mp.isPlaying) {
                    try {
                        mp.start()
                    } catch (e: Exception) {
                        mp.release()
                    }
                }
            }
            timer_1.alpha = 0f
            timer_2.alpha = 0f
            timer_3.alpha = 0f
            timer_4.alpha = 0f
            timer_5.alpha = 0f
            timer_6.alpha = 0f
            timer_7.alpha = 0f
            timer_8.alpha = 0f
            timer_9.alpha = 0f
            timer_10.alpha = 0f
            timer_11.alpha = 0f
            timer_12.alpha = 0f
        }

        if (count == 1) {

//            if (UserModel.isShowFirstTime) {
//                UserModel.isShowFirstTime = false
//                showAllSegment()
//            }

//            if (CommonUtility.getBooleanPreference(Constant.isShowTemperatureView, mContext)) {
//                Glide.with(this).asGif().load(R.raw.heating_temp).apply(
//                    RequestOptions.diskCacheStrategyOf(
//                        DiskCacheStrategy.RESOURCE
//                    )
//                ).into(ivTempImage)
//                isConnect = true
//                val mp = MediaPlayer.create(mContext, R.raw.double_beep)
//                if (mp != null && !mp.isPlaying) {
//                    try {
//                        mp.start()
//                    } catch (e: Exception) {
//                        mp.release()
//                    }
//                }
//            }
            timer_1.alpha = 1f
            timer_2.alpha = 0f
            timer_3.alpha = 0f
            timer_4.alpha = 0f
            timer_5.alpha = 0f
            timer_6.alpha = 0f
            timer_7.alpha = 0f
            timer_8.alpha = 0f
            timer_9.alpha = 0f
            timer_10.alpha = 0f
            timer_11.alpha = 0f
            timer_12.alpha = 0f
        }
        if (count == 2) {
            timer_1!!.alpha = 1f
            timer_2.alpha = 1f
            timer_3.alpha = 0f
            timer_4.alpha = 0f
            timer_5.alpha = 0f
            timer_6.alpha = 0f
            timer_7.alpha = 0f
            timer_8.alpha = 0f
            timer_9.alpha = 0f
            timer_10.alpha = 0f
            timer_11.alpha = 0f
            timer_12.alpha = 0f
        }
        if (count == 3) {
            timer_1!!.alpha = 1f
            timer_2!!.alpha = 1f
            timer_3.alpha = 1f
            timer_4.alpha = 0f
            timer_5.alpha = 0f
            timer_6.alpha = 0f
            timer_7.alpha = 0f
            timer_8.alpha = 0f
            timer_9.alpha = 0f
            timer_10.alpha = 0f
            timer_11.alpha = 0f
            timer_12.alpha = 0f
        }
        if (count == 4) {
            timer_1.alpha = 1f
            timer_2.alpha = 1f
            timer_3.alpha = 1f
            timer_4.alpha = 1f
            timer_5.alpha = 0f
            timer_6.alpha = 0f
            timer_7.alpha = 0f
            timer_8.alpha = 0f
            timer_9.alpha = 0f
            timer_10.alpha = 0f
            timer_11.alpha = 0f
            timer_12.alpha = 0f
        }
        if (count == 5) {
            timer_1.alpha = 1f
            timer_2.alpha = 1f
            timer_3.alpha = 1f
            timer_4.alpha = 1f
            timer_5.alpha = 1f
            timer_6.alpha = 0f
            timer_7.alpha = 0f
            timer_8.alpha = 0f
            timer_9.alpha = 0f
            timer_10.alpha = 0f
            timer_11.alpha = 0f
            timer_12.alpha = 0f
        }
        if (count == 6) {
            timer_1.alpha = 1f
            timer_2.alpha = 1f
            timer_3.alpha = 1f
            timer_4.alpha = 1f
            timer_5.alpha = 1f
            timer_6.alpha = 1f
            timer_7.alpha = 0f
            timer_8.alpha = 0f
            timer_9.alpha = 0f
            timer_10.alpha = 0f
            timer_11.alpha = 0f
            timer_12.alpha = 0f
        }
        if (count == 7) {
            timer_1.alpha = 1f
            timer_2.alpha = 1f
            timer_3.alpha = 1f
            timer_4.alpha = 1f
            timer_5.alpha = 1f
            timer_6.alpha = 1f
            timer_7.alpha = 1f
            timer_8.alpha = 0f
            timer_9.alpha = 0f
            timer_10.alpha = 0f
            timer_11.alpha = 0f
            timer_12.alpha = 0f
        }
        if (count == 8) {
            timer_1.alpha = 1f
            timer_2.alpha = 1f
            timer_3.alpha = 1f
            timer_4.alpha = 1f
            timer_5.alpha = 1f
            timer_6.alpha = 1f
            timer_7.alpha = 1f
            timer_8.alpha = 1f
            timer_9.alpha = 0f
            timer_10.alpha = 0f
            timer_11.alpha = 0f
            timer_12.alpha = 0f
        }
        if (count == 9) {
            timer_1.alpha = 1f
            timer_2.alpha = 1f
            timer_3.alpha = 1f
            timer_4.alpha = 1f
            timer_5.alpha = 1f
            timer_6.alpha = 1f
            timer_7.alpha = 1f
            timer_8.alpha = 1f
            timer_9.alpha = 1f
            timer_10.alpha = 0f
            timer_11.alpha = 0f
            timer_12.alpha = 0f
        }
        if (count == 10) {
            timer_1.alpha = 1f
            timer_2.alpha = 1f
            timer_3.alpha = 1f
            timer_4.alpha = 1f
            timer_5.alpha = 1f
            timer_6.alpha = 1f
            timer_7.alpha = 1f
            timer_8.alpha = 1f
            timer_9.alpha = 1f
            timer_10.alpha = 1f
            timer_11.alpha = 0f
            timer_12.alpha = 0f
        }
        if (count == 11) {
            timer_1.alpha = 1f
            timer_2.alpha = 1f
            timer_3.alpha = 1f
            timer_4.alpha = 1f
            timer_5.alpha = 1f
            timer_6.alpha = 1f
            timer_7.alpha = 1f
            timer_8.alpha = 1f
            timer_9.alpha = 1f
            timer_10.alpha = 1f
            timer_11.alpha = 1f
            timer_12.alpha = 0f
        }
        if (count == 12) {
            isConnect = false
            timer_1.alpha = 1f
            timer_2.alpha = 1f
            timer_3.alpha = 1f
            timer_4.alpha = 1f
            timer_5.alpha = 1f
            timer_6.alpha = 1f
            timer_7.alpha = 1f
            timer_8.alpha = 1f
            timer_9.alpha = 1f
            timer_10.alpha = 1f
            timer_11.alpha = 1f
            timer_12.alpha = 1f
        }
    }

    private fun hideAllImages() {
        timer_1.alpha = 0.1f
        timer_2.alpha = 0f
        timer_3.alpha = 0f
        timer_4.alpha = 0f
        timer_5.alpha = 0f
        timer_6.alpha = 0f
        timer_7.alpha = 0f
        timer_8.alpha = 0f
        timer_9.alpha = 0f
        timer_10.alpha = 0f
        timer_11.alpha = 0f
        timer_12.alpha = 0f
    }

    private fun createHomeButton() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, CODE_DRAW_OVER_OTHER_APP_PERMISSION)
        }
    }

    private fun openCancelDialog() {
        PopupWindowRemoveDevice.Builder<PopupWindowRemoveDevice>(
            mContext as Activity,
            "BROWSE", "CANCEL",
            "WOULD YOU LIKE\nTO CANCEL COOKING\nOR BROWSE THE APP\nWHILE COOKING \nCONTINUES?",
            ContextCompat.getDrawable(this, R.drawable.ic_right)!!,
            object : PopupWindowClick {
                override fun onButton1Click() {
//                    startServiceForCooking()
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (Settings.canDrawOverlays(mContext)) {
                            startServiceForCooking()
                        } else {
                            createHomeButton()
                        }
                    } else {
                        startServiceForCooking()
                    }

                }

                override fun onButton2Click() {
                    if (UserModel.mBluetoothGattChar != null) {
                        DigitalTimerService.cancelRecipes(UserModel.mBluetoothGattChar!!)
                    }
                    CommonUtility.setBooleanPreference(
                        false,
                        Constant.cookingIsRunning,
                        mContext
                    )
                    LocalBroadcastManager.getInstance(mContext).sendBroadcast(
                        Intent("isFromServiceForTimer11").putExtra(
                            "isFromServiceForTimer",
                            false
                        )
                    )
                }
            }
        ).setContentView(R.layout.dialog_remove_device)
            .setGravity(Gravity.BOTTOM)
            .setScaleRatio(0.1f)
            .setBlurRadius(Constant.blurRadius)
            .setDismissOnClickBack(false)
            .setDismissOnTouchBackground(false)
            .build()
            .show()
    }

    /**
     * Set and initialize the view elements.
     */
    private fun startServiceForCooking() {
        CommonUtility.setBooleanPreference(
            true,
            Constant.cookingIsRunning,
            mContext
        )
        mContext.startActivity(
            Intent(
                mContext,
                MainActivity::class.java
            ).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        isConnect = false
        finish()
    }


    override fun onStart() {
        super.onStart()
        Handler().postDelayed({
            LocalBroadcastManager.getInstance(mContext)
                .sendBroadcast(Intent("AppIsBackground").putExtra("isBackground", true))
        }, 200)

        initializeBroadCast()
        if (CommonUtility.getBooleanPreference(Constant.cookingIsRunning, mContext)) {
            count = CommonUtility.getStringPreference("count", mContext).toInt()
            updateImage()
        }
        if (isShowManageDevice && CommonUtility.getBooleanPreference(
                Constant.isDigital,
                mContext
            )
        ) {
            isShowManageDevice = false
            startServiceForTemp()
        } else if (isShowManageDevice) {
            Toast.makeText(mContext, "This not digital device", Toast.LENGTH_SHORT).show()
        }
    }

    private fun initializeBroadCast() {
        LocalBroadcastManager.getInstance(mContext).unregisterReceiver(countDownRegister)
        LocalBroadcastManager.getInstance(mContext).unregisterReceiver(segmentCountRegister)
//        LocalBroadcastManager.getInstance(mContext).unregisterReceiver(startSelfCooking)


        LocalBroadcastManager.getInstance(mContext).registerReceiver(
            startSelfCooking,
            IntentFilter("startSelfCooking")
        )

        LocalBroadcastManager.getInstance(mContext).registerReceiver(
            countDownRegister,
            IntentFilter("countDown")
        )
        LocalBroadcastManager.getInstance(mContext).registerReceiver(
            segmentCountRegister,
            IntentFilter("segmentCountRegister")
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        LocalBroadcastManager.getInstance(mContext).unregisterReceiver(countDownRegister)
        LocalBroadcastManager.getInstance(mContext).unregisterReceiver(segmentCountRegister)
        LocalBroadcastManager.getInstance(mContext).unregisterReceiver(startSelfCooking)
    }

    override fun onBackPressed() {
        if (CommonUtility.getBooleanPreference(Constant.cookingIsRunning, mContext)) {
            openCancelDialog()
        } else {
            mContext.startActivity(
                Intent(
                    mContext,
                    MainActivity::class.java
                ).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            )
        }

    }
}
