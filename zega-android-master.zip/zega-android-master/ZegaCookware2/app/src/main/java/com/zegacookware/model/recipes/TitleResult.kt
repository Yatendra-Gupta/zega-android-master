package com.zegacookware.model.recipes

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class TitleResult {

    @SerializedName("recepie_category_id")
    @Expose
    var recepieCategoryId: Int? = null
    @SerializedName("recepie_category_name")
    @Expose
    var recepieCategoryName: String? = null
    @SerializedName("recepie_title")
    @Expose
    var recepieTitle: List<RecepieTitle>? = null

}
