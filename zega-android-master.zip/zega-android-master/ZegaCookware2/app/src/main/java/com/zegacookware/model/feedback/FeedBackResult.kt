package com.zegacookware.model.feedback

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class FeedBackResult {
    @SerializedName("master_result")
    @Expose
    var feedbackData: ArrayList<FeedbackData>? = null
    @SerializedName("status")
    @Expose
    var status: Int? = null
}
