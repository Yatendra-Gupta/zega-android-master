package com.zegacookware.model.faq

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class FAQs {
    @SerializedName("faq_result")
    @Expose
    var faqResult: List<FaqResult>? = null
    @SerializedName("status")
    @Expose
    var status: Int? = null

}
