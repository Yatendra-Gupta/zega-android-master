package com.zegacookware.activity.manage_device

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.Gravity
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.zegacookware.R
import com.zegacookware.activity.BaseActivity
import com.zegacookware.activity.MainActivity
import com.zegacookware.activity.setting.WebViewActivity
import com.zegacookware.adapter.ZegaBluetoothDeviceAdapter
import com.zegacookware.interfaces.ClickOnFavouritePopup
import com.zegacookware.interfaces.PopupWindowClick
import com.zegacookware.interfaces.SetOnItemClickListener
import com.zegacookware.model.AddDeviceRequest
import com.zegacookware.model.recipes.recipesdetail.FavouriteResponse
import com.zegacookware.model.user.UserModel
import com.zegacookware.model.user.UserResult
import com.zegacookware.network.Constant
import com.zegacookware.util.CommonUtility
import com.zegacookware.util.blurBackground.BlurPopupWindowTemp
import com.zegacookware.util.blurBackground.PopupWindowNoDeviceFound
import kotlinx.android.synthetic.main.activity_connect_bluetooth.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*


class ConnectBluetoothActivity : AppCompatActivity() {

    private var isRegister: Boolean? = false
    private lateinit var userData: UserResult
    var mBTDevices = ArrayList<BluetoothDevice>()
    private lateinit var mContext: Context
    private var mDeviceListAdapter: ZegaBluetoothDeviceAdapter? = null
    private var mBluetoothAdapter: BluetoothAdapter? = null
    private var selectedDevice = 0
    private var TAG: String = "ConnectBluetoothActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_connect_bluetooth)
        mContext = this
        userData = CommonUtility.getUserData(Constant.userInfo, this@ConnectBluetoothActivity)

        ivBack.setOnClickListener { finish() }
        rvZegaDevice.layoutManager = LinearLayoutManager(mContext)
        rvZegaDevice.setHasFixedSize(true)

        enableBluetooth()

        btnConnect.setOnClickListener {
            lytLoading.visibility = View.VISIBLE
            lytMain.visibility = View.GONE
            Handler().postDelayed({
                if (mBluetoothAdapter!!.isEnabled) {
                    btnDiscover()
                }
            }, 100)
        }

    }

    private fun enableBluetooth() {
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        if (!mBluetoothAdapter!!.isEnabled) {
            Log.d(TAG, "enableDisableBT: enabling BT.")
            val enableBTIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivity(enableBTIntent)
        }
    }


    private fun addDevice(address: String, name: String) {
        CommonUtility.showProgressDialog(this@ConnectBluetoothActivity)
        Constant.service.addDevices(
            AddDeviceRequest(
                user_id = "" + userData.userId,
                device_id = address,
                device_name = intent.getStringExtra("device_name"),
                mac_id = address
            )
        ).apply {
            enqueue(object : Callback<FavouriteResponse> {
                override fun onFailure(call: Call<FavouriteResponse>, t: Throwable) {
                    CommonUtility.hideProgressBar()
                }

                override fun onResponse(
                    call: Call<FavouriteResponse>,
                    response: Response<FavouriteResponse>
                ) {
                    CommonUtility.hideProgressBar()
                    CommonUtility.setStringPreference(
                        address,
                        "deviceId",
                        this@ConnectBluetoothActivity
                    )
                    CommonUtility.setBooleanPreference(
                        true,
                        Constant.isDigital,
                        this@ConnectBluetoothActivity
                    )
//                    val mIntent =
//                        Intent(this@ConnectBluetoothActivity, TempConnectHardware::class.java)
//                    startService(mIntent)

                    BaseActivity.connectHardware()
                    openConnectDialog(
                        "CONGRATULATIONS\n" +
                                "YOU HAVE ADDED\n" +
                                "‘" + userData.name + "’S ZEGA’",
                        "OK",
                        ContextCompat.getDrawable(
                            this@ConnectBluetoothActivity,
                            R.drawable.ic_right
                        )!!,
                        this@ConnectBluetoothActivity
                    )
                }

            })
        }
    }

    fun openConnectDialog(msgString: String, buttonText: String, ids: Drawable, mContext: Context) {
        BlurPopupWindowTemp.Builder<BlurPopupWindowTemp>(
            mContext as Activity,
            msgString,
            buttonText,
            "",
            ids, object : ClickOnFavouritePopup {
                override fun onItemClick(position: Int, cusineType: String) {
                    UserModel.isFromConnectScreen = true
                    if (intent.getBooleanExtra("isFromSignUp", false)) {
                        startActivity(
                            Intent(
                                this@ConnectBluetoothActivity,
                                MainActivity::class.java
                            ).putExtra("isFromTimer", false)
                                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                        )
                    }
                    finish()
                }
            }
        ).setContentView(R.layout.dialog_add_device_done)
            .setGravity(Gravity.CENTER)
            .setScaleRatio(0.1f)
            .setBlurRadius(Constant.blurRadius)
            .setDismissOnClickBack(false)
            .setDismissOnTouchBackground(false)
            .build()
            .show()
    }


    private fun btnDiscover() {
        Log.d(TAG, "btnDiscover: Looking for unpaired devices.")
        Handler().postDelayed({
            if (mBTDevices.size < 1) {
                mBluetoothAdapter!!.cancelDiscovery()
                CommonUtility.hideProgressBar()
                openNoDeviceFoundDialog()
            }
        }, 20000)
//        CommonUtility.showProgressDialog(mContext)
        if (mBluetoothAdapter!!.isDiscovering) {
            mBluetoothAdapter!!.cancelDiscovery()
            Log.d(TAG, "btnDiscover: Canceling discovery.")
            //check BT permissions in manifest
            checkBTPermissions()

            mBluetoothAdapter!!.startDiscovery()
            val discoverDevicesIntent = IntentFilter(BluetoothDevice.ACTION_FOUND)
            registerReceiver(mBroadcastReceiver3, discoverDevicesIntent)
        }
        if (!mBluetoothAdapter!!.isDiscovering) {

            //check BT permissions in manifest
            checkBTPermissions()

            mBluetoothAdapter!!.startDiscovery()
            val discoverDevicesIntent = IntentFilter(BluetoothDevice.ACTION_FOUND)
            registerReceiver(mBroadcastReceiver3, discoverDevicesIntent)
        }
        isRegister = true
    }

    private fun checkBTPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            var permissionCheck =
                this.checkSelfPermission("Manifest.permission.ACCESS_FINE_LOCATION")
            permissionCheck += this.checkSelfPermission("Manifest.permission.ACCESS_COARSE_LOCATION")
            if (permissionCheck != 0) {

                this.requestPermissions(
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    ), 1001
                ) //Any number
            }
        } else {
            Log.d(TAG, "checkBTPermissions: No need to check permissions. SDK version < LOLLIPOP.")
        }
    }

    /**
     * Broadcast Receiver for listing devices that are not yet paired
     * -Executed by btnDiscover() method.
     */
    private val mBroadcastReceiver3 = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val action = intent.action
            Log.d(TAG, "onReceive: ACTION FOUND.")

            if (action == BluetoothDevice.ACTION_FOUND) {
                val device =
                    intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                if (device.name.equals("Zega", true)) {
                    CommonUtility.hideProgressBar()
                    if (!mBTDevices.contains(device)) {
                        mBTDevices.add(device)
                    }
                    if (mBTDevices.size > 0) {
                        lytLoading.visibility = View.GONE
                        rvZegaDevice.visibility = View.VISIBLE
                    } else {
                        lytLoading.visibility = View.VISIBLE
                        rvZegaDevice.visibility = View.GONE
                    }
                    Log.d(TAG, "onReceive: " + device.name + ": " + device.address)
                    mDeviceListAdapter =
                        ZegaBluetoothDeviceAdapter(
                            mContext!!,
                            mBTDevices,
                            object : SetOnItemClickListener {
                                override fun onItemClick(position: Int) {
                                    selectedDevice = position
                                    lytMain.visibility = View.GONE
                                    rvZegaDevice.visibility = View.GONE
                                    addDevice(
                                        mBTDevices[selectedDevice].address,
                                        mBTDevices[selectedDevice].name
                                    )

                                }
                            })
                    rvZegaDevice.adapter = mDeviceListAdapter
                }
            }
        }
    }


    private fun openNoDeviceFoundDialog() {
        PopupWindowNoDeviceFound.Builder<PopupWindowNoDeviceFound>(
            mContext as Activity, object : PopupWindowClick {
                override fun onButton1Click() {
                    startActivity(
                        Intent(this@ConnectBluetoothActivity, WebViewActivity::class.java)
                            .putExtra("header", "HELP")
                            .putExtra("url", Constant.bluetoothUrl)
                    )
                }

                override fun onButton2Click() {
                    btnDiscover()
                }

            }
        ).setContentView(R.layout.dialog_no_devices)
            .setGravity(Gravity.CENTER)
            .setScaleRatio(0.1f)
            .setBlurRadius(Constant.blurRadius)
            .setDismissOnClickBack(false)
            .setDismissOnTouchBackground(false)
            .build()
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isRegister!!) {
            isRegister = false
            unregisterReceiver(mBroadcastReceiver3)
        }
    }
}

