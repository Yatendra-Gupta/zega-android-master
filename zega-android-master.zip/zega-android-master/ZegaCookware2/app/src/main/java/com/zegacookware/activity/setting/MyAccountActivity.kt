package com.zegacookware.activity.setting

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.zegacookware.R
import com.zegacookware.activity.IntroActivity
import com.zegacookware.interfaces.PopupWindowClick
import com.zegacookware.model.recipes.RecipesDetailRequest
import com.zegacookware.model.recipes.recipesdetail.FavouriteResponse
import com.zegacookware.model.user.UserResult
import com.zegacookware.network.Constant
import com.zegacookware.util.CommonUtility
import com.zegacookware.util.blurBackground.BlurPopupWindowSignout
import kotlinx.android.synthetic.main.activity_my_account.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MyAccountActivity : AppCompatActivity(), View.OnClickListener {


    private lateinit var userData: UserResult
    private lateinit var mContext: Context

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_account)
        mContext = this
        userData = CommonUtility.getUserData(Constant.userInfo, this@MyAccountActivity)
        lytChangeDetails.setOnClickListener(this)
        lytChangePassword.setOnClickListener(this)
        lytSignOut.setOnClickListener(this)
        btnBackSetting.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.lytChangeDetails -> {
                startActivity(Intent(this@MyAccountActivity, MyProfileActivity::class.java))
            }
            R.id.lytChangePassword -> {
                if (CommonUtility.getConnectivityStatus(this@MyAccountActivity)) {
                    startActivity(
                        Intent(
                            this@MyAccountActivity,
                            ChangePasswordActivity::class.java
                        )
                    )
                }
            }
            R.id.lytSignOut -> {
                if (CommonUtility.getBooleanPreference(Constant.cookingIsRunning, mContext)) {
                    CommonUtility.openDialogForCookingRunning(mContext)
                    return
                }
                if (CommonUtility.getConnectivityStatus(this@MyAccountActivity)) {
                    openSignOutDialog()
                }
            }
            R.id.btnBackSetting -> {
                finish()
            }
        }

    }

    private fun openSignOutDialog() {
        BlurPopupWindowSignout.Builder<BlurPopupWindowSignout>(
            mContext as Activity, "YES", "NO", "Are you sure you want to sign out?", "sign out",
            ContextCompat.getDrawable(mContext, R.drawable.ic_alert),
            object : PopupWindowClick {
                override fun onButton1Click() {
                    logoutMethod()
                }

                override fun onButton2Click() {

                }

            }
        ).setContentView(R.layout.dialog_logout)
            .setGravity(Gravity.CENTER)
            .setScaleRatio(0.1f)
            .setBlurRadius(Constant.blurRadius)
            .setDismissOnClickBack(false)
            .setDismissOnTouchBackground(false)
            .build()
            .show()
    }

    private fun logoutMethod() {
        Constant.service.userDestroySession(
            RecipesDetailRequest(
                user_id = "" + userData.userId
            )
        ).apply {
            enqueue(object : Callback<FavouriteResponse> {
                override fun onFailure(call: Call<FavouriteResponse>, t: Throwable) {
                }

                override fun onResponse(
                    call: Call<FavouriteResponse>,
                    response: Response<FavouriteResponse>
                ) {
                    if (response.isSuccessful && response.body()?.status == 1) {
                        CommonUtility.setBooleanPreference(
                            false,
                            Constant.isLoggedIn,
                            mContext
                        )
                        startActivity(Intent(mContext, IntroActivity::class.java))
                        finishAffinity()
                    }

                }
            })
        }
    }
}
