package com.zegacookware.network
import com.zegacookware.model.user.UserModel
import okhttp3.Interceptor
import okhttp3.Response
import java.io.IOException

class TokenInjectInterceptor : Interceptor {

    companion object {

        private const val NO_TOKEN_HEADER = "X-No-Token"
        const val DONT_ADD_AUTH_TOKEN = NO_TOKEN_HEADER + ": true"

        private const val AUTHORIZATION = "Authorization"
        private const val TOKEN_HEADER = "Token token="
    }

    @Throws(IOException::class)
    override fun intercept(chain: Interceptor.Chain): Response {
        val original = chain.request()

        val noToken = original.header(NO_TOKEN_HEADER) != null

        val request = if (!noToken) {
            val headers = original.headers().newBuilder()
                .removeAll(NO_TOKEN_HEADER)
                .set(
                    AUTHORIZATION,
                    UserModel.token
                )
                .build()

            original.newBuilder().headers(headers).build()
        } else {
            original
        }

        return chain.proceed(request)
    }
}
