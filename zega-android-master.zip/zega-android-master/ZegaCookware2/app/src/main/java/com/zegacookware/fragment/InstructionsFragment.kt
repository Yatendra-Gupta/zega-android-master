package com.zegacookware.fragment

import android.os.Build
import android.os.Bundle
import android.text.Html
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.BulletSpan
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.zegacookware.R
import com.zegacookware.activity.RecipesDetailsActivity
import com.zegacookware.widget.ImprovedBulletSpan
import com.zegacookware.widget.LiTagHandler
import kotlinx.android.synthetic.main.fragment_instruction.*

/**
 * A simple [Fragment] subclass.
 * Activities that contain this fragment must implement the
 * [InstructionsFragment.OnFragmentInteractionListener] interface
 * to handle interaction events.
 * Use the [InstructionsFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class InstructionsFragment : Fragment() {

    private var instruction1: String = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_instruction, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
//            tvInstruction.text = Html.fromHtml( RecipesDetailsActivity.recipesDetails?.recepieResult?.recepieInstructions, Html.FROM_HTML_MODE_LEGACY)
//        } else {
//            tvInstruction.text = Html.fromHtml( RecipesDetailsActivity.recipesDetails?.recepieResult?.recepieInstructions)
//        }

        @Suppress("DEPRECATION")
        val htmlSpannable = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Html.fromHtml(RecipesDetailsActivity.recipesDetails?.recepieResult?.recepieInstructions, Html.FROM_HTML_MODE_LEGACY)
        } else {
            Html.fromHtml(RecipesDetailsActivity.recipesDetails?.recepieResult?.recepieInstructions, null, LiTagHandler())
        }
        val spannableBuilder = SpannableStringBuilder(htmlSpannable)
        val bulletSpans = spannableBuilder.getSpans(0, spannableBuilder.length, BulletSpan::class.java)
        bulletSpans.forEach {
            val start = spannableBuilder.getSpanStart(it)
            val end = spannableBuilder.getSpanEnd(it)
            spannableBuilder.removeSpan(it)
            spannableBuilder.setSpan(
                ImprovedBulletSpan(bulletRadius = dip(3), gapWidth = dip(8)),
                start,
                end,
                Spanned.SPAN_INCLUSIVE_EXCLUSIVE
            )
        }
        tvInstruction.text = spannableBuilder

    }
    private fun dip(dp: Int): Int {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), resources.displayMetrics).toInt()
    }
}
