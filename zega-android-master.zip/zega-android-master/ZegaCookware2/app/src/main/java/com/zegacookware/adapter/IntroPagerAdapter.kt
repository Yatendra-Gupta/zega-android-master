package com.zegacookware.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.AppCompatButton
import androidx.viewpager.widget.PagerAdapter
import com.zegacookware.R
import com.zegacookware.activity.LoginActivity
import com.zegacookware.activity.SignUpActivity
import com.zegacookware.model.IntroSliderModel

class IntroPagerAdapter(var mContext: Context) : PagerAdapter() {
    override fun instantiateItem(collection: ViewGroup, position: Int): Any {
        val modelObject = IntroSliderModel.values()[position]
        val inflater = LayoutInflater.from(mContext)
        val layout = inflater.inflate(modelObject.layoutResId, collection, false) as ViewGroup
        if (modelObject.layoutResId == R.layout.layout_four) {
            val btnLogin = layout.findViewById<AppCompatButton>(R.id.btnLogin)
            val btnSignup = layout.findViewById<AppCompatButton>(R.id.btnSignUp)
            btnLogin.setOnClickListener {
                mContext.startActivity(
                    Intent(
                        mContext,
                        LoginActivity::class.java
                    )
                )
            }
            btnSignup.setOnClickListener {
                mContext.startActivity(
                    Intent(
                        mContext,
                        SignUpActivity::class.java
                    )
                )
            }
        }
        collection.addView(layout)

        return layout
    }

    override fun destroyItem(collection: ViewGroup, position: Int, view: Any) {
        collection.removeView(view as View)
    }

    override fun getCount(): Int {
        return IntroSliderModel.values().size
    }

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view === `object`
    }

//    override fun getPageTitle(position: Int): CharSequence {
//        val customPagerEnum = IntroSliderModel.values()[position]
//        return mContext.getString(customPagerEnum.titleResId)
//    }
}