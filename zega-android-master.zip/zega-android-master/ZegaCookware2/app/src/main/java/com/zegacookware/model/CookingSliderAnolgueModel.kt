package com.zegacookware.model

import com.zegacookware.R

enum class CookingSliderAnalogueModel private constructor(val layoutResId: Int) {
    RED(R.layout.layout_start_cooking1),
    BLUE(R.layout.layout_start_cooking2),
    YELLOW(R.layout.layout_start_cooking3),
    GREEN(R.layout.layout_start_cooking4),
}