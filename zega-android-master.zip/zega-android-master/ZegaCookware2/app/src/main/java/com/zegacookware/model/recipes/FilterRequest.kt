package com.zegacookware.model.recipes

data class FilterRequest(
    var my_favourite: String = "",
    var food_type: String = "",
    var cusine_type: String = "",
    var user_id: String = "",
    var filter_type: String = "",
    var recepie_category_id: String = ""
)
