package com.zegacookware.network

import com.zegacookware.model.AddDeviceRequest
import com.zegacookware.model.UserDevices
import com.zegacookware.model.faq.FAQs
import com.zegacookware.model.feedback.FeedBackResult
import com.zegacookware.model.feedback.SubmitFeedback
import com.zegacookware.model.quickcook.QuickCook
import com.zegacookware.model.recipes.*
import com.zegacookware.model.recipes.recipesdetail.FavouriteResponse
import com.zegacookware.model.recipes.recipesdetail.RecipesDetails
import com.zegacookware.model.user.*
import com.zegacookware.network.TokenInjectInterceptor.Companion.DONT_ADD_AUTH_TOKEN
import retrofit2.Call
import retrofit2.http.*

interface ServiceApi {

    @Headers(DONT_ADD_AUTH_TOKEN)
    @POST("user-login")
    fun loginMethod(@Body loginRequest: LoginRequest): Call<UserInfo>

    @Headers(DONT_ADD_AUTH_TOKEN)
    @POST("user-registration")
    fun signUpMethod(@Body loginRequest: LoginRequest): Call<SignupResponse>

    @Headers(DONT_ADD_AUTH_TOKEN)
    @POST("forgot-password")
    fun forgotPasswordMethod(@Body loginRequest: LoginRequest): Call<Forgot>

    @Headers(DONT_ADD_AUTH_TOKEN)
    @GET("get-recepie-categories")
    fun getRecipeCategoryMethod(): Call<RecipesCategory>

    @Headers(DONT_ADD_AUTH_TOKEN)
    @GET("quick-cook")
    fun getQuickCook(): Call<QuickCook>

    @Headers(DONT_ADD_AUTH_TOKEN)
    @GET("get-recepie-title-acc-to-category")
    fun getRecipeTitleWithCategoryMethod(): Call<AllRecipes>

    @Headers(DONT_ADD_AUTH_TOKEN)
    @POST("get-recepie-details")
    fun getRecipeDetails(@Body recipesDetailRequest: RecipesDetailRequest): Call<RecipesDetails>

    @Headers(DONT_ADD_AUTH_TOKEN)
    @POST("search-recepie")
    fun searchRecipe(@Body recipesDetailRequest: RecipesDetailRequest): Call<SearchRecipes>

    @Headers(DONT_ADD_AUTH_TOKEN)
    @POST("get-recepies")
    fun getRecipesByCategoryID(@Body recipesDetailRequest: RecipesDetailRequest): Call<GetRecipesByCategoryId>

    @Headers(DONT_ADD_AUTH_TOKEN)
    @GET("get-food-type")
    fun getFoodType(): Call<GetFoodType>

    @Headers(DONT_ADD_AUTH_TOKEN)
    @POST("favourite-recepie")
    fun favouriteMethod(@Body recipesDetailRequest: RecipesDetailRequest): Call<FavouriteResponse>

    @Headers(DONT_ADD_AUTH_TOKEN)
    @POST("user-destroy-session")
    fun userDestroySession(@Body recipesDetailRequest: RecipesDetailRequest): Call<FavouriteResponse>

    @Headers(DONT_ADD_AUTH_TOKEN)
    @POST("enable-notification")
    fun enableNotification(@Body recipesDetailRequest: RecipesDetailRequest): Call<FavouriteResponse>

    @Headers(DONT_ADD_AUTH_TOKEN)
    @POST("apply-filter")
    fun filterMethod(@Body filterRequest: FilterRequest): Call<AllRecipes>

    @Headers(DONT_ADD_AUTH_TOKEN)
    @POST("apply-filter")
    fun filterByCategoryIdMethod(@Body filterRequest: FilterRequest): Call<GetRecipesByCategoryId>

    @Headers(DONT_ADD_AUTH_TOKEN)
    @POST("change-password")
    fun changePassword(@Body changePasswordRequest: ChangePasswordRequest): Call<FavouriteResponse>

    @Headers(DONT_ADD_AUTH_TOKEN)
    @POST("change-details")
    fun changeDetails(@Body changePasswordRequest: ChangePasswordRequest): Call<FavouriteResponse>

    @Headers(DONT_ADD_AUTH_TOKEN)
    @POST("get-profile")
    fun getUserInfo(@Body changePasswordRequest: ChangePasswordRequest): Call<UpdateUserInfo>

    @Headers(DONT_ADD_AUTH_TOKEN)
    @GET("get-master-feedback")
    fun getMasterFeedback(): Call<FeedBackResult>

    @Headers(DONT_ADD_AUTH_TOKEN)
    @POST("user-positive-feedback")
    fun userPositiveFeedback(@Body changePasswordRequest: ChangePasswordRequest): Call<FavouriteResponse>

    @Headers(DONT_ADD_AUTH_TOKEN)
    @POST("submit-feedback")
    fun submitFeedback(@Body submitFeedback: SubmitFeedback): Call<FavouriteResponse>

    @Headers(DONT_ADD_AUTH_TOKEN)
    @GET("get-faq-list")
    fun getFaqList(): Call<FAQs>

    @Headers(DONT_ADD_AUTH_TOKEN)
    @POST("add-device")
    fun addDevices(@Body addDeviceRequest: AddDeviceRequest): Call<FavouriteResponse>

    @Headers(DONT_ADD_AUTH_TOKEN)
    @POST("remove-device")
    fun removeDevices(@Body addDeviceRequest: AddDeviceRequest): Call<FavouriteResponse>

    @Headers(DONT_ADD_AUTH_TOKEN)
    @POST("user-devices-list")
    fun getUserDevices(@Body addDeviceRequest: AddDeviceRequest): Call<UserDevices>


}
