package com.zegacookware.fragment;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;

import androidx.annotation.AnyThread;
import androidx.annotation.CallSuper;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.zegacookware.R;
import com.zegacookware.activity.RecipesActivity;
import com.zegacookware.adapter.FavoriteSelectedAdapter;
import com.zegacookware.adapter.FavouriteTypeListAdapter;
import com.zegacookware.interfaces.ClickOnFavouritePopup;
import com.zegacookware.interfaces.SetOnItemClickListenerPopup;
import com.zegacookware.model.recipes.GetFoodTypeData;
import com.zegacookware.util.blurBackground.BlurUtilsTemp;

import org.jetbrains.annotations.NotNull;

import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.ArrayList;


@SuppressWarnings("ALL")
public class PopupWindowFilter extends FrameLayout {
    private static final String TAG = "BlurPopupWindow";

    private static final float DEFAULT_BLUR_RADIUS = 10;
    private static final float DEFAULT_SCALE_RATIO = 0.4f;
    private static final long DEFAULT_ANIMATION_DURATION = 300;

    public interface OnDismissListener {
        void onDismiss(PopupWindowFilter popupWindow);
    }

    private Activity mActivity;
    protected ImageView mBlurView;
    protected FrameLayout mContentLayout;
    private boolean mAnimating;

    private WindowManager mWindowManager;

    private View mContentView;
    private int mTintColor;
    private View mAnchorView;
    private float mBlurRadius;
    private float mScaleRatio;
    private long mAnimationDuration;
    private boolean mDismissOnTouchBackground;
    private boolean mDismissOnClickBack;
    private OnDismissListener mOnDismissListener;

    public PopupWindowFilter(@NonNull Context context) {
        super(context);
        init();
    }

    private void init() {
        if (!(getContext() instanceof Activity)) {
            throw new IllegalArgumentException("Context must be Activity");
        }
        mActivity = (Activity) getContext();
        mWindowManager = mActivity.getWindowManager();

        mBlurRadius = DEFAULT_BLUR_RADIUS;
        mScaleRatio = DEFAULT_SCALE_RATIO;
        mAnimationDuration = DEFAULT_ANIMATION_DURATION;

        setFocusable(true);
        setFocusableInTouchMode(true);

        mContentLayout = new FrameLayout(getContext());
        LayoutParams lp = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        addView(mContentLayout, lp);

        mBlurView = new ImageView(mActivity);
//        mBlurView.setScaleType(ImageView.ScaleType.FIT_XY);
        mBlurView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        lp = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        lp.gravity = Gravity.BOTTOM;
        mBlurView.setLayoutParams(lp);
        mContentLayout.addView(mBlurView);

        mContentView = createContentView(mContentLayout);
        if (mContentView != null) {
            mContentLayout.addView(mContentView);
        }
    }

    public boolean hasNavBar(Resources resources) {
        int id = resources.getIdentifier("config_showNavigationBar", "bool", "android");
        return id > 0 && resources.getBoolean(id);
    }

    /**
     * Override this to create custom content.
     *
     * @param parent the parent where content view would be.
     * @return
     */
    protected View createContentView(ViewGroup parent) {
        return null;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (mAnimating || !mDismissOnTouchBackground) {
            return super.onTouchEvent(event);
        }
        if (event.getAction() == MotionEvent.ACTION_UP) {
            dismiss();
        }
        return true;
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (mAnimating || !mDismissOnClickBack) {
            return super.onKeyUp(keyCode, event);
        }
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            dismiss();
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    public void setContentView(View contentView) {
        if (contentView == null) {
            throw new IllegalArgumentException("contentView can not be null");
        }
        if (mContentView != null) {
            if (mContentView.getParent() != null) {
                ((ViewGroup) mContentView.getParent()).removeView(mContentView);
            }
            mContentView = null;
        }
        mContentView = contentView;
        mContentLayout.addView(mContentView);
    }

    public View getContentView() {
        return mContentView;
    }

    public void show() {
        if (mAnimating) {
            return;
        }

        WindowManager.LayoutParams params = new WindowManager.LayoutParams();
        params.width = WindowManager.LayoutParams.MATCH_PARENT;
        params.height = WindowManager.LayoutParams.MATCH_PARENT;
        params.format = PixelFormat.RGBA_8888;

        int statusBarHeight = 0;
        int navigationBarHeight = PopupWindowFilter.getNaviHeight(mActivity);
        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            statusBarHeight = getResources().getDimensionPixelSize(resourceId);
        }

        int trimTopHeight = statusBarHeight;
        int trimBottomHeight = 0;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {

            // No need to trim status bar height in SDK > 21.
            trimTopHeight = 0;

            WindowManager.LayoutParams lp = mActivity.getWindow().getAttributes();
            if ((lp.flags & WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION) == 0 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                trimBottomHeight = navigationBarHeight;
            }

            // This line will cause decor view fill all the screen, even if FLAG_TRANSLUCENT_NAVIGATION
            // was not set.
            params.flags = lp.flags;

            if (trimBottomHeight > 0) {
                // If trimBottomHeight > 0, it means that we cut navigation bar off and we need shrink
                // popup windows' content height by increase bottom padding.
                if (navigationBarHeight < 120) {
                    setPadding(getPaddingLeft(), getPaddingTop(), getPaddingRight(), getPaddingBottom() + navigationBarHeight);
                } else {
                    setPadding(getPaddingLeft(), getPaddingTop(), getPaddingRight(), getPaddingBottom() /*+120*//* + navigationBarHeight*/);
//                    navigationBarHeight = 120;
                }
            } else {

                // If navigation is showing on the screen, whether translucent or not, we should move contentView
                // on top of it.
                boolean moveContent = false;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    moveContent = true;
                } else if (navigationBarHeight > 0 && (lp.flags & WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION) != 0) {
                    // Navigation feature diffs from v19 to v21.
                    moveContent = true;
                }
                if (navigationBarHeight > 0 && moveContent) {
                    if (mContentView != null) {
                        MarginLayoutParams layoutParams = (MarginLayoutParams) mContentView.getLayoutParams();
                        layoutParams.bottomMargin += navigationBarHeight;
                    }
                }
            }
        }

        new BlurTask(mActivity.getWindow().getDecorView(), trimTopHeight, trimBottomHeight, this, new BlurTask.BlurTaskCallback() {
            @Override
            public void onBlurFinish(Bitmap bitmap) {
                onBlurredImageGot(bitmap);
            }
        }).execute();

        mWindowManager.addView(this, params);

        ObjectAnimator showAnimator = createShowAnimator();
        if (showAnimator != null) {
            mAnimating = true;
            showAnimator.addListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationCancel(Animator animation) {
                    mAnimating = false;
                    requestFocus();
                }

                @Override
                public void onAnimationEnd(Animator animation) {
                    mAnimating = false;
                    requestFocus();
                }
            });
            showAnimator.start();
        }
        onShow();
    }

    public void dismiss() {
        if (mAnimating) {
            return;
        }
        onDismiss();
        ObjectAnimator animator = createDismissAnimator();
        if (animator == null) {
            mWindowManager.removeView(this);
        } else {
            mAnimating = true;
            ObjectAnimator.ofFloat(mBlurView, "alpha", mBlurView.getAlpha(), 0).setDuration(getAnimationDuration()).start();
            animator.addListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    removeSelf();
                }

                @Override
                public void onAnimationCancel(Animator animation) {
                    removeSelf();
                }

                private void removeSelf() {
                    try {
                        mWindowManager.removeView(PopupWindowFilter.this);
                    } catch (Exception e) {
                        e.printStackTrace();
                    } finally {
                        mAnimating = false;
                    }
                }
            });
            animator.start();
        }
    }

    protected void onBlurredImageGot(Bitmap bitmap) {
        mBlurView.setImageBitmap(bitmap);
        if (!mAnimating) {
            ObjectAnimator.ofFloat(mBlurView, "alpha", 0, 1f).setDuration(getAnimationDuration()).start();
        }
    }

    /**
     * When executing show method in this method, should override {@link PopupWindowFilter#createShowAnimator()}
     * and return null as well.
     */
    protected void onShow() {
    }

    /**
     * Do not start any animation in this method. use {@link PopupWindowFilter#createDismissAnimator()} instead.
     */
    @CallSuper
    public void onDismiss() {
        if (mOnDismissListener != null) {
            mOnDismissListener.onDismiss(this);
        }
    }

    protected ObjectAnimator createShowAnimator() {
        return ObjectAnimator.ofFloat(mContentLayout, "alpha", 0, 1.f).setDuration(getAnimationDuration());
    }

    protected ObjectAnimator createDismissAnimator() {
        return ObjectAnimator.ofFloat(mContentLayout, "alpha", mContentLayout.getAlpha(), 0).setDuration(getAnimationDuration());
    }

    public int getTintColor() {
        return mTintColor;
    }

    public void setTintColor(int tintColor) {
        mTintColor = tintColor;
    }

    public View getAnchorView() {
        return mAnchorView;
    }

    public void setAnchorView(View anchorView) {
        mAnchorView = anchorView;
    }

    @AnyThread
    public float getBlurRadius() {
        return mBlurRadius;
    }

    public void setBlurRadius(float blurRadius) {
        mBlurRadius = blurRadius;
    }

    @AnyThread
    public float getScaleRatio() {
        return mScaleRatio;
    }

    public void setScaleRatio(float scaleRatio) {
        mScaleRatio = scaleRatio;
    }

    public long getAnimationDuration() {
        return mAnimationDuration;
    }

    public void setAnimationDuration(long animationDuration) {
        mAnimationDuration = animationDuration;
    }

    public boolean isDismissOnTouchBackground() {
        return mDismissOnTouchBackground;
    }

    public void setDismissOnTouchBackground(boolean dismissOnTouchBackground) {
        mDismissOnTouchBackground = dismissOnTouchBackground;
    }

    public boolean isDismissOnClickBack() {
        return mDismissOnClickBack;
    }

    public void setDismissOnClickBack(boolean dismissOnClickBack) {
        mDismissOnClickBack = dismissOnClickBack;
    }

    public OnDismissListener getOnDismissListener() {
        return mOnDismissListener;
    }

    public void setOnDismissListener(OnDismissListener onDismissListener) {
        mOnDismissListener = onDismissListener;
    }

    public static class Builder<T extends PopupWindowFilter> {
        private static final String TAG = "BlurPopupWindow.Builder";
        protected Context mContext;
        private View mContentView;
        private int mTintColor;
        private float mBlurRadius;
        private float mScaleRatio;
        private long mAnimationDuration;
        private boolean mDismissOnTouchBackground = true;
        private boolean mDismissOnClickBack = true;
        private int mGravity = -1;
        private OnDismissListener mOnDismissListener;
        private ArrayList<GetFoodTypeData> list1;
        private ClickOnFavouritePopup clickOnFavouritePopup1;

        public Builder(Context context, ArrayList<GetFoodTypeData> list, ClickOnFavouritePopup clickOnFavouritePopup) {
            mContext = context;
            mBlurRadius = PopupWindowFilter.DEFAULT_BLUR_RADIUS;
            mScaleRatio = PopupWindowFilter.DEFAULT_SCALE_RATIO;
            mAnimationDuration = PopupWindowFilter.DEFAULT_ANIMATION_DURATION;
            list1 = list;
            clickOnFavouritePopup1 = clickOnFavouritePopup;
        }

        public Builder<T> setContentView(View contentView) {
            mContentView = contentView;
            return this;
        }

        public Builder<T> setContentView(int resId) {
            View view = LayoutInflater.from(mContext).inflate(resId, new FrameLayout(mContext), false);
            mContentView = view;
            return this;
        }

        public Builder<T> bindContentViewClickListener(OnClickListener listener) {
            if (mContentView != null) {
                mContentView.setClickable(true);
                mContentView.setOnClickListener(listener);
            }
            return this;
        }

        public Builder<T> bindClickListener(OnClickListener listener, int... views) {
            if (mContentView != null) {
                for (int viewId : views) {
                    View view = mContentView.findViewById(viewId);
                    if (view != null) {
                        view.setOnClickListener(listener);
                    }
                }
            }
            return this;
        }

        public Builder<T> setGravity(int gravity) {
            mGravity = gravity;
            return this;
        }

        public Builder<T> setTintColor(int tintColor) {
            mTintColor = tintColor;
            return this;
        }

        public Builder<T> setScaleRatio(float scaleRatio) {
            if (scaleRatio <= 0 || scaleRatio > 1) {
                Log.w(TAG, "scaleRatio invalid: " + scaleRatio + ". It can only be (0, 1]");
                return this;
            }
            mScaleRatio = scaleRatio;
            return this;
        }

        public Builder<T> setBlurRadius(float blurRadius) {
            if (blurRadius < 0 || blurRadius > 25) {
                Log.w(TAG, "blurRadius invalid: " + blurRadius + ". It can only be [0, 25]");
                return this;
            }
            mBlurRadius = blurRadius;
            return this;
        }

        public Builder<T> setAnimationDuration(long animatingDuration) {
            if (animatingDuration < 0) {
                Log.w(TAG, "animatingDuration invalid: " + animatingDuration + ". It can only be (0, ..)");
                return this;
            }
            mAnimationDuration = animatingDuration;
            return this;
        }

        public Builder<T> setDismissOnTouchBackground(boolean dismissOnTouchBackground) {
            mDismissOnTouchBackground = dismissOnTouchBackground;
            return this;
        }

        public Builder<T> setDismissOnClickBack(boolean dismissOnClickBack) {
            mDismissOnClickBack = dismissOnClickBack;
            return this;
        }

        public Builder<T> setOnDismissListener(OnDismissListener onDismissListener) {
            mOnDismissListener = onDismissListener;
            return this;
        }

        protected T createPopupWindow() {
            //noinspection unchecked
            return (T) new PopupWindowFilter(mContext);
        }

        AppCompatTextView tvFavorite, tvLunch, tvDinner, tvBreakfast;
        ArrayList<String> selectedFoodType;
        FavouriteTypeListAdapter typeListAdapter;
        FavoriteSelectedAdapter selectedAdapter1 = null;
        Typeface typeface, typefaceExtraLight;
        AppCompatImageView btnCloseFavorite, btnDoneFavorite;
        ArrayList<GetFoodTypeData> selectedCategory;
        RecyclerView rvSelectedFavoriteList, rvFavoriteList;

        public T build() {
            final T popupWindow = createPopupWindow();
            if (mContentView != null) {
                ViewGroup.LayoutParams layoutParams = mContentView.getLayoutParams();
                if (layoutParams == null || !(layoutParams instanceof LayoutParams)) {
                    layoutParams = new LayoutParams(layoutParams.width, layoutParams.height);
                }
                if (mGravity != -1) {
                    ((LayoutParams) layoutParams).gravity = mGravity;
                }
                mContentView.setLayoutParams(layoutParams);
                popupWindow.setContentView(mContentView);
                tvFavorite = mContentView.findViewById(R.id.tvFavorite);
                tvLunch = mContentView.findViewById(R.id.tvLunch);
                tvDinner = mContentView.findViewById(R.id.tvDinner);
                tvBreakfast = mContentView.findViewById(R.id.tvBreakfast);
                btnCloseFavorite = mContentView.findViewById(R.id.btnCloseFavorite);
                btnDoneFavorite = mContentView.findViewById(R.id.btnDoneFavorite);

                rvSelectedFavoriteList = mContentView.findViewById(R.id.rvSelectedFavoriteList);
                rvFavoriteList = mContentView.findViewById(R.id.rvFavoriteList);

                typeface = ResourcesCompat.getFont(mContext, R.font.poppins_semibold);
                typefaceExtraLight = ResourcesCompat.getFont(mContext, R.font.poppins_extralight);

                selectedCategory = new ArrayList<GetFoodTypeData>();
                selectedFoodType = new ArrayList<String>();

                GridLayoutManager gridLayoutManager = new GridLayoutManager(mContext, 2, LinearLayoutManager.HORIZONTAL, false);
                rvSelectedFavoriteList.setLayoutManager(gridLayoutManager); // set LayoutManager to RecyclerView

                btnCloseFavorite.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        clickOnFavouritePopup1.onItemClick(0, "close");
                        popupWindow.dismiss();
                    }
                });

                btnDoneFavorite.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        clickOnFavouritePopup1.onItemClick(0, "filter");
                        popupWindow.dismiss();
                    }
                });

                tvFavorite.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        GetFoodTypeData getFoodTypeDataF = null;
                        for (int i = 0; i < selectedCategory.size(); i++) {
                            if (selectedCategory.get(i).getFood_type_name().equalsIgnoreCase(tvFavorite.getText().toString())) {
                                getFoodTypeDataF = selectedCategory.get(i);
                            }
                        }
                        if (getFoodTypeDataF != null) {
                            selectedCategory.remove(getFoodTypeDataF);
                            tvFavorite.setTypeface(typefaceExtraLight);
                            RecipesActivity.Companion.setMyFavourite("");
                        } else {
                            GetFoodTypeData getFoodTypeData = new GetFoodTypeData();
                            getFoodTypeData.setFood_type_name(tvFavorite.getText().toString());
                            selectedCategory.add(getFoodTypeData);
                            tvFavorite.setTypeface(typeface);
                            RecipesActivity.Companion.setMyFavourite("my_favourite");
                        }
                        updateList(null, rvSelectedFavoriteList, selectedCategory);
                    }
                });
                tvDinner.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        GetFoodTypeData getFoodTypeDatad = null;
                        for (int i = 0; i < selectedCategory.size(); i++) {
                            if (selectedCategory.get(i).getFood_type_name().equalsIgnoreCase(tvDinner.getText().toString())) {
                                getFoodTypeDatad = selectedCategory.get(i);
                            }
                        }
                        if (getFoodTypeDatad != null) {
                            selectedCategory.remove(getFoodTypeDatad);
                            tvDinner.setTypeface(typefaceExtraLight);
                            selectedFoodType.remove(tvDinner.getText().toString());
                        } else {
                            GetFoodTypeData getFoodTypeData = new GetFoodTypeData();
                            getFoodTypeData.setFood_type_name(tvDinner.getText().toString());
                            selectedCategory.add(getFoodTypeData);
                            tvDinner.setTypeface(typeface);
                            selectedFoodType.add(tvDinner.getText().toString());
                        }
                        updateList(selectedFoodType, rvSelectedFavoriteList, selectedCategory);
                    }
                });
                tvLunch.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        GetFoodTypeData getFoodTypeData = null;
                        for (int i = 0; i < selectedCategory.size(); i++) {
                            if (selectedCategory.get(i).getFood_type_name().equalsIgnoreCase(tvLunch.getText().toString())) {
                                getFoodTypeData = selectedCategory.get(i);
                            }
                        }
                        if (getFoodTypeData != null) {
                            selectedCategory.remove(getFoodTypeData);
                            tvLunch.setTypeface(typefaceExtraLight);
                            selectedFoodType.remove(tvLunch.getText().toString().toLowerCase());
                        } else {
                            GetFoodTypeData getFoodTypeData2 = new GetFoodTypeData();
                            getFoodTypeData2.setFood_type_name(tvLunch.getText().toString());
                            selectedCategory.add(getFoodTypeData2);
                            tvLunch.setTypeface(typeface);
                            selectedFoodType.add(tvLunch.getText().toString().toLowerCase());
                        }
                        updateList(selectedFoodType, rvSelectedFavoriteList, selectedCategory);
                    }
                });
                tvBreakfast.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        GetFoodTypeData getFoodTypeData = null;
                        for (int i = 0; i < selectedCategory.size(); i++) {
                            if (selectedCategory.get(i).getFood_type_name().equalsIgnoreCase(tvBreakfast.getText().toString())) {
                                getFoodTypeData = selectedCategory.get(i);
                            }
                        }
                        if (getFoodTypeData != null) {
                            selectedCategory.remove(getFoodTypeData);
                            tvBreakfast.setTypeface(typefaceExtraLight);
                            selectedFoodType.remove(tvBreakfast.getText().toString().toLowerCase());
                        } else {
                            GetFoodTypeData getFoodTypeData1 = new GetFoodTypeData();
                            getFoodTypeData1.setFood_type_name(tvBreakfast.getText().toString());
                            selectedCategory.add(getFoodTypeData1);
                            tvBreakfast.setTypeface(typeface);
                            selectedFoodType.add(tvBreakfast.getText().toString().toLowerCase());

                        }
                        updateList(selectedFoodType, rvSelectedFavoriteList, selectedCategory);
                    }
                });

                rvFavoriteList.setLayoutManager(new LinearLayoutManager(mContext));
                typeListAdapter = new FavouriteTypeListAdapter(mContext, list1, new SetOnItemClickListenerPopup() {
                    @Override
                    public void onItemClick(GetFoodTypeData getFoodTypeData1) {

                        if (selectedCategory.contains(getFoodTypeData1)) {
                            selectedCategory.remove(getFoodTypeData1);
                        } else {
                            selectedCategory.add(getFoodTypeData1);
                        }

                        updateList(null, rvSelectedFavoriteList, selectedCategory);

                    }
                });
                rvFavoriteList.setAdapter(typeListAdapter);


                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        defaultSelected(list1);
                    }
                }, 400);

            }
            popupWindow.setTintColor(mContext.getColor(R.color.colorWhiteTransFilter));
            popupWindow.setAnimationDuration(mAnimationDuration);
            popupWindow.setBlurRadius(8);
            popupWindow.setScaleRatio(mScaleRatio);
            popupWindow.setDismissOnTouchBackground(mDismissOnTouchBackground);
            popupWindow.setDismissOnClickBack(mDismissOnClickBack);
            popupWindow.setOnDismissListener(mOnDismissListener);

            return popupWindow;
        }

        private void defaultSelected(ArrayList<GetFoodTypeData> list2) {
            selectedFoodType = RecipesActivity.Companion.getFoodType();
            for (int i = 0; i < selectedFoodType.size(); i++) {

                GetFoodTypeData getFoodTypeData1 = new GetFoodTypeData();
                getFoodTypeData1.setFood_type_name(selectedFoodType.get(i));
                selectedCategory.add(getFoodTypeData1);

                if (selectedFoodType.get(i).equalsIgnoreCase("DINNER")) {
                    tvDinner.setTypeface(typeface);
                } else if (selectedFoodType.get(i).equalsIgnoreCase("BREAKFAST")) {
                    tvBreakfast.setTypeface(typeface);
                } else if (selectedFoodType.get(i).equalsIgnoreCase("LUNCH")) {
                    tvLunch.setTypeface(typeface);
                }
            }

            if (RecipesActivity.Companion.getMyFavourite().equalsIgnoreCase("my_favourite")) {
                GetFoodTypeData getFoodTypeData1 = new GetFoodTypeData();
                getFoodTypeData1.setFood_type_name("FAVOURITES");
                selectedCategory.add(getFoodTypeData1);
                tvFavorite.setTypeface(typeface);
            }

            for (int i = 0; i < RecipesActivity.Companion.getCusineList().size(); i++) {
                for (int j = 0; j < list2.size(); j++) {
                    if (RecipesActivity.Companion.getCusineList().get(i).equalsIgnoreCase(list2.get(j).getFood_type_id().toString())) {
                        selectedCategory.add(list2.get(j));
                    }
                }
            }
            updateList(selectedFoodType, rvSelectedFavoriteList, selectedCategory);
        }

        private void updateList(ArrayList<String> selectedFoodType1, RecyclerView rvSelectedFavoriteList, ArrayList<GetFoodTypeData> selectedCategory) {
            if (selectedFoodType1 != null) {
                RecipesActivity.Companion.setFoodType(selectedFoodType1);
            }

            final ArrayList<GetFoodTypeData> strings = selectedCategory;

            if (strings.size() > 0) {
                btnDoneFavorite.setVisibility(View.VISIBLE);
                btnCloseFavorite.setVisibility(View.GONE);
            } else {
                btnCloseFavorite.setVisibility(View.VISIBLE);
                btnDoneFavorite.setVisibility(View.GONE);
            }
            selectedAdapter1 = new FavoriteSelectedAdapter(mContext, strings, new ClickOnFavouritePopup() {
                @Override
                public void onItemClick(int position, @NotNull String cusineType) {
                    if (cusineType.equalsIgnoreCase("DINNER")) {
                        tvDinner.setTypeface(typefaceExtraLight);
                        selectedFoodType.remove(cusineType);
                    } else if (cusineType.equalsIgnoreCase("BREAKFAST")) {
                        tvBreakfast.setTypeface(typefaceExtraLight);
                        selectedFoodType.remove(cusineType);
                    } else if (cusineType.equalsIgnoreCase("FAVOURITES")) {
                        tvFavorite.setTypeface(typefaceExtraLight);
                        selectedFoodType.remove(cusineType);
                        RecipesActivity.Companion.setMyFavourite("");
                    } else if (cusineType.equalsIgnoreCase("LUNCH")) {
                        tvLunch.setTypeface(typefaceExtraLight);
                        selectedFoodType.remove(cusineType);
                    }
                    RecipesActivity.Companion.setFoodType(selectedFoodType);
                    RecipesActivity.Companion.getCusineList().remove("" + strings.get(position).getFood_type_id());
                    strings.remove(strings.get(position));
//                    selectedCategory.remove()
//                    RecipesActivity.Companion.setCusineList(strings);
                    selectedAdapter1.notifyDataSetChanged();
                    typeListAdapter.notifyDataSetChanged();
                    if (strings.size() == 0) {
                        btnDoneFavorite.setVisibility(View.GONE);
                        btnCloseFavorite.setVisibility(View.VISIBLE);
                    }
                }
            });
            rvSelectedFavoriteList.setAdapter(selectedAdapter1);
        }
    }


    private final static class BlurTask extends AsyncTask<Void, Void, Bitmap> {

        private WeakReference<Context> mContextRef;
        private WeakReference<PopupWindowFilter> mPopupWindowRef;
        private Bitmap mSourceBitmap;
        private BlurTaskCallback mBlurTaskCallback;

        interface BlurTaskCallback {
            void onBlurFinish(Bitmap bitmap);
        }

        BlurTask(View sourceView, int statusBarHeight, int navigationBarheight, PopupWindowFilter popupWindow, BlurTaskCallback blurTaskCallback) {
            mContextRef = new WeakReference<>(sourceView.getContext());
            mPopupWindowRef = new WeakReference<>(popupWindow);
            mBlurTaskCallback = blurTaskCallback;

            int height = sourceView.getHeight() - statusBarHeight - navigationBarheight;
            if (height < 0) {
                height = sourceView.getHeight();
            }

            Drawable background = sourceView.getBackground();
            mSourceBitmap = Bitmap.createBitmap(sourceView.getWidth(), height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(mSourceBitmap);
            int saveCount = 0;
            if (statusBarHeight != 0) {
                saveCount = canvas.save();
                canvas.translate(0, -statusBarHeight);
            }
            if (popupWindow.getBlurRadius() > 0) {
                if (background == null) {
                    canvas.drawColor(0xffffffff);
                }
                sourceView.draw(canvas);
            }
            if (popupWindow.getTintColor() != 0) {
                canvas.drawColor(popupWindow.getTintColor());
            }
            if (statusBarHeight != 0 && saveCount != 0) {
                canvas.restoreToCount(saveCount);
            }
        }

        @Override
        protected Bitmap doInBackground(Void... params) {
            Context context = mContextRef.get();
            PopupWindowFilter popupWindow = mPopupWindowRef.get();
            if (context == null || popupWindow == null) {
                return null;
            }
            float scaleRatio = popupWindow.getScaleRatio();
            if (popupWindow.getBlurRadius() == 0) {
                return mSourceBitmap;
            }
            Bitmap scaledBitmap = Bitmap.createScaledBitmap(mSourceBitmap, (int) (mSourceBitmap.getWidth() * scaleRatio), (int) (mSourceBitmap.getHeight() * scaleRatio), false);
            float radius = popupWindow.getBlurRadius();
            Bitmap blurred = BlurUtilsTemp.blur(context, scaledBitmap, radius);
            return Bitmap.createScaledBitmap(blurred, mSourceBitmap.getWidth(), mSourceBitmap.getHeight(), true);
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            PopupWindowFilter popupWindow = mPopupWindowRef.get();
            if (popupWindow != null && popupWindow.getAnchorView() != null) {
                Canvas canvas = new Canvas(bitmap);
                View anchorView = popupWindow.getAnchorView();
                int[] location = new int[2];
                anchorView.getLocationInWindow(location);
                canvas.save();
                canvas.translate(location[0], location[1]);
                popupWindow.getAnchorView().draw(canvas);
                canvas.restore();
            }
            if (mBlurTaskCallback != null) {
                mBlurTaskCallback.onBlurFinish(bitmap);
            }
            if(mSourceBitmap!=null)
            {
                mSourceBitmap.recycle();
                mSourceBitmap=null;
            }
        }
    }

    private static int getNaviHeight(Activity activity) {
        if (activity == null) {
            return 0;
        }
        Display display = activity.getWindowManager().getDefaultDisplay();
        int contentHeight = activity.getResources().getDisplayMetrics().heightPixels;
        int realHeight = 0;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            final DisplayMetrics metrics = new DisplayMetrics();
            display.getRealMetrics(metrics);
            realHeight = metrics.heightPixels;
        } else {
            try {
                Method mGetRawH = Display.class.getMethod("getRawHeight");
                realHeight = (Integer) mGetRawH.invoke(display);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return realHeight - contentHeight;
    }

}
