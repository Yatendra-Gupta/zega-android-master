package com.zegacookware.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.zegacookware.R
import com.zegacookware.activity.RecipesDetailsActivity
import com.zegacookware.model.recipes.recipesdetail.IngriendientResult
import kotlinx.android.synthetic.main.fragment_ingredients.*

class IngredientsFragment : Fragment() {

    private var ingrendientsResultList = ArrayList<IngriendientResult>()
    private var str = StringBuilder()
    private var count1 = 4
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_ingredients, container, false)
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        ingrendientsResultList = RecipesDetailsActivity.recipesDetails?.ingriendientResult!!


        tvServesCount.text = "Serves $count1"

        if (RecipesDetailsActivity.recipesDetails?.recepieResult?.serveRequired.equals(
                "yes",
                true
            )
        ) {
            count1 = 4
            btnPlusMinus.visibility = View.VISIBLE
        } else {
            count1 = 1
            btnPlusMinus.visibility = View.GONE
            tvServesCount.text =
                "Serves " + RecipesDetailsActivity.recipesDetails?.recepieResult?.serveSize
        }

        updateServesCount()

        btnPlus.setOnClickListener {
            if (count1 > 11) {
                Toast.makeText(activity!!, "MAXIMUM 12", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            str.clear()
            count1++
            tvServesCount.text = "Serves $count1"
            updateServesCount()
        }
        btnMinus.setOnClickListener {
            if (count1 < 3) {
                Toast.makeText(activity!!, "MINIMUM 2", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            str.clear()
            count1--
            tvServesCount.text = "Serves $count1"
            updateServesCount()
        }
    }

    private fun updateServesCount() {
        for (i in 0 until ingrendientsResultList.size) {
            if (ingrendientsResultList[i].ingriedientWise.equals(
                    "unit_wise",
                    true
                )
            ) {
//                if (ingrendientsResultList[i].ingriedientQuantity?.contains(".", true)!!) {
//                    if (ingrendientsResultList[i].ingriedientQuantityType != null) {
//                        str.append((ingrendientsResultList[i].ingriedientQuantity!!.toFloat() * count1).toString() + " " + ingrendientsResultList[i].ingriedientQuantityType + " " + ingrendientsResultList[i].ingriedientName + "\n")
//                    } else {
//                        str.append((ingrendientsResultList[i].ingriedientQuantity!!.toFloat() * count1).toString() + " " + ingrendientsResultList[i].ingriedientName + "\n")
//                    }
//                } else {
//                    if (ingrendientsResultList[i].ingriedientQuantityType != null) {
//                        str.append((ingrendientsResultList[i].ingriedientQuantity!!.toInt() * count1).toString() + " " + ingrendientsResultList[i].ingriedientQuantityType + " " + ingrendientsResultList[i].ingriedientName + "\n")
//                    } else {
//                        str.append((ingrendientsResultList[i].ingriedientQuantity!!.toInt() * count1).toString() + " " + ingrendientsResultList[i].ingriedientName + "\n")
//                    }
//                }
                if (ingrendientsResultList[i].ingriedientQuantity?.contains(".", true)!!) {
                    if (ingrendientsResultList[i].quantityType != null) {
                        str.append((ingrendientsResultList[i].ingriedientQuantity!!.toFloat() * count1).toString().replace(".0","") + " " + ingrendientsResultList[i].quantityType + " " + ingrendientsResultList[i].ingriedientName + "\n")
                    } else {
                        str.append((ingrendientsResultList[i].ingriedientQuantity!!.toFloat() * count1).toString().replace(".0","") + " " + ingrendientsResultList[i].ingriedientName + "\n")
                    }
                } else {
                    if (ingrendientsResultList[i].quantityType != null) {
                        str.append((ingrendientsResultList[i].ingriedientQuantity!!.toInt() * count1).toString() + " " + ingrendientsResultList[i].quantityType + " " + ingrendientsResultList[i].ingriedientName + "\n")
                    } else {
                        str.append((ingrendientsResultList[i].ingriedientQuantity!!.toInt() * count1).toString() + " " + ingrendientsResultList[i].ingriedientName + "\n")
                    }
                }
            } else {
                str.append(ingrendientsResultList[i].ingriedientName + "\n")
            }
        }
        tvIngredients.text = str.toString()
    }

}
