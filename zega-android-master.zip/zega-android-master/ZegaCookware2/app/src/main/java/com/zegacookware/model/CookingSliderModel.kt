package com.zegacookware.model

import com.zegacookware.R


enum class CookingSliderModel private constructor(val layoutResId: Int) {
    RED(R.layout.layout_start_cooking1),
    BLUE(R.layout.layout_start_cooking2),
}