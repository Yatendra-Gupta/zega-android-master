package com.zegacookware.util.blurBackground;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.PopupWindow;

import androidx.annotation.AnyThread;
import androidx.annotation.CallSuper;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.zegacookware.R;
import com.zegacookware.interfaces.ClickOnFavouritePopup;

import java.lang.reflect.Method;

/**
 * PopupWindow with blurred below view.
 * Created by kyle on 2017/3/14.
 */

@SuppressWarnings("ALL")
public class CompleteCookingPopup extends FrameLayout {
    private static final String TAG = "BlurPopupWindow";

    private static final float DEFAULT_BLUR_RADIUS = 10;
    private static final float DEFAULT_SCALE_RATIO = 0.4f;
    private static final long DEFAULT_ANIMATION_DURATION = 300;

    public interface OnDismissListener {
        void onDismiss(CompleteCookingPopup popupWindow);
    }

    private Activity mActivity;
    protected ImageView mBlurView;
    protected FrameLayout mContentLayout;
    private boolean mAnimating;

    private WindowManager mWindowManager;

    private View mContentView;
    private int mTintColor;
    private View mAnchorView;
    private float mBlurRadius;
    private float mScaleRatio;
    private long mAnimationDuration;
    private boolean mDismissOnTouchBackground;
    private boolean mDismissOnClickBack;
    private OnDismissListener mOnDismissListener;
    private static PopupWindow realPopupWindow11;

    public CompleteCookingPopup(@NonNull Context context) {
        super(context);
        init();
    }

    private void init() {
        if (!(getContext() instanceof Activity)) {
            throw new IllegalArgumentException("Context must be Activity");
        }
        mActivity = (Activity) getContext();
        mWindowManager = mActivity.getWindowManager();

        mBlurRadius = DEFAULT_BLUR_RADIUS;
        mScaleRatio = DEFAULT_SCALE_RATIO;
        mAnimationDuration = DEFAULT_ANIMATION_DURATION;

        setFocusable(true);
        setFocusableInTouchMode(true);

        mContentLayout = new FrameLayout(getContext());
        LayoutParams lp = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        addView(mContentLayout, lp);

        mBlurView = new ImageView(mActivity);
        mBlurView.setScaleType(ImageView.ScaleType.FIT_XY);
        lp = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        lp.gravity = Gravity.BOTTOM;
        mBlurView.setLayoutParams(lp);
        mContentLayout.addView(mBlurView);
        mBlurView.setImageDrawable(ContextCompat.getDrawable(mActivity, R.drawable.bg_blur));

        mContentView = createContentView(mContentLayout);
        if (mContentView != null) {
            mContentLayout.addView(mContentView);
        }
    }

    /**
     * Override this to create custom content.
     *
     * @param parent the parent where content view would be.
     * @return
     */
    protected View createContentView(ViewGroup parent) {
        return null;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (mAnimating || !mDismissOnTouchBackground) {
            return super.onTouchEvent(event);
        }
        if (event.getAction() == MotionEvent.ACTION_UP) {
            dismiss();
        }
        return true;
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (mAnimating || !mDismissOnClickBack) {
            return super.onKeyUp(keyCode, event);
        }
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            dismiss();
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    public void setContentView(View contentView) {
        if (contentView == null) {
            throw new IllegalArgumentException("contentView can not be null");
        }
        if (mContentView != null) {
            if (mContentView.getParent() != null) {
                ((ViewGroup) mContentView.getParent()).removeView(mContentView);
            }
            mContentView = null;
        }
        mContentView = contentView;
        mContentLayout.addView(mContentView);
    }

    public View getContentView() {
        return mContentView;
    }

    public void show() {
    }

    public void dismiss() {
        if (realPopupWindow11 != null) {
            realPopupWindow11.dismiss();
        }
    }

    protected void onBlurredImageGot(Bitmap bitmap) {
        mBlurView.setImageBitmap(bitmap);
        if (!mAnimating) {
            ObjectAnimator.ofFloat(mBlurView, "alpha", 0, 1f).setDuration(getAnimationDuration()).start();
        }
    }

    /**
     * When executing show method in this method, should override {@link CompleteCookingPopup#createShowAnimator()}
     * and return null as well.
     */
    protected void onShow() {
    }

    /**
     * Do not start any animation in this method. use {@link CompleteCookingPopup#createDismissAnimator()} instead.
     */
    @CallSuper
    protected void onDismiss() {
        if (mOnDismissListener != null) {
            mOnDismissListener.onDismiss(this);
        }
    }

    protected ObjectAnimator createShowAnimator() {
        return ObjectAnimator.ofFloat(mContentLayout, "alpha", 0, 1.f).setDuration(getAnimationDuration());
    }

    protected ObjectAnimator createDismissAnimator() {
        return ObjectAnimator.ofFloat(mContentLayout, "alpha", mContentLayout.getAlpha(), 0).setDuration(getAnimationDuration());
    }

    public int getTintColor() {
        return mTintColor;
    }

    public void setTintColor(int tintColor) {
        mTintColor = tintColor;
    }

    public View getAnchorView() {
        return mAnchorView;
    }

    public void setAnchorView(View anchorView) {
        mAnchorView = anchorView;
    }

    @AnyThread
    public float getBlurRadius() {
        return mBlurRadius;
    }

    public void setBlurRadius(float blurRadius) {
        mBlurRadius = blurRadius;
    }

    @AnyThread
    public float getScaleRatio() {
        return mScaleRatio;
    }

    public void setScaleRatio(float scaleRatio) {
        mScaleRatio = scaleRatio;
    }

    public long getAnimationDuration() {
        return mAnimationDuration;
    }

    public void setAnimationDuration(long animationDuration) {
        mAnimationDuration = animationDuration;
    }

    public boolean isDismissOnTouchBackground() {
        return mDismissOnTouchBackground;
    }

    public void setDismissOnTouchBackground(boolean dismissOnTouchBackground) {
        mDismissOnTouchBackground = dismissOnTouchBackground;
    }

    public boolean isDismissOnClickBack() {
        return mDismissOnClickBack;
    }

    public void setDismissOnClickBack(boolean dismissOnClickBack) {
        mDismissOnClickBack = dismissOnClickBack;
    }

    public OnDismissListener getOnDismissListener() {
        return mOnDismissListener;
    }

    public void setOnDismissListener(OnDismissListener onDismissListener) {
        mOnDismissListener = onDismissListener;
    }

    public static class Builder<T extends CompleteCookingPopup> {
        private static final String TAG = "BlurPopupWindow.Builder";
        protected Context mContext;
        private View mContentView;
        private int mTintColor;
        private float mBlurRadius;
        private float mScaleRatio;
        private long mAnimationDuration;
        private boolean mDismissOnTouchBackground = true;
        private boolean mDismissOnClickBack = true;
        private int mGravity = -1;
        private OnDismissListener mOnDismissListener;
        private String msgText;
        private String buttonText;
        private String headerText;
        private Drawable drawable;
        private ClickOnFavouritePopup clickOnFavouritePopup1;
        private T popupWindow1;

        public Builder(Context context, String msg, String btText, String headerText1, Drawable drawable1, ClickOnFavouritePopup clickOnFavouritePopup) {
            mContext = context;
            msgText = msg;
            buttonText = btText;
            drawable = drawable1;
            headerText = headerText1;
            clickOnFavouritePopup1 = clickOnFavouritePopup;
            mBlurRadius = CompleteCookingPopup.DEFAULT_BLUR_RADIUS;
            mScaleRatio = CompleteCookingPopup.DEFAULT_SCALE_RATIO;
            mAnimationDuration = CompleteCookingPopup.DEFAULT_ANIMATION_DURATION;
        }

        public Builder<T> setContentView(View contentView) {
            mContentView = contentView;
            return this;
        }

        public Builder<T> setContentView(int resId) {
            View view = LayoutInflater.from(mContext).inflate(resId, new FrameLayout(mContext), false);
            mContentView = view;
            return this;
        }

        public Builder<T> bindContentViewClickListener(OnClickListener listener) {
            if (mContentView != null) {
                mContentView.setClickable(true);
                mContentView.setOnClickListener(listener);
            }
            return this;
        }

        public Builder<T> bindClickListener(OnClickListener listener, int... views) {
            if (mContentView != null) {
                for (int viewId : views) {
                    View view = mContentView.findViewById(viewId);
                    if (view != null) {
                        view.setOnClickListener(listener);
                    }
                }
            }
            return this;
        }

        public Builder<T> setGravity(int gravity) {
            mGravity = gravity;
            return this;
        }

        public Builder<T> setTintColor(int tintColor) {
            mTintColor = tintColor;
            return this;
        }

        public Builder<T> setScaleRatio(float scaleRatio) {
            if (scaleRatio <= 0 || scaleRatio > 1) {
                Log.w(TAG, "scaleRatio invalid: " + scaleRatio + ". It can only be (0, 1]");
                return this;
            }
            mScaleRatio = scaleRatio;
            return this;
        }

        public Builder<T> setBlurRadius(float blurRadius) {
            if (blurRadius < 0 || blurRadius > 25) {
                Log.w(TAG, "blurRadius invalid: " + blurRadius + ". It can only be [0, 25]");
                return this;
            }
            mBlurRadius = blurRadius;
            return this;
        }

        public Builder<T> setAnimationDuration(long animatingDuration) {
            if (animatingDuration < 0) {
                Log.w(TAG, "animatingDuration invalid: " + animatingDuration + ". It can only be (0, ..)");
                return this;
            }
            mAnimationDuration = animatingDuration;
            return this;
        }

        public Builder<T> setDismissOnTouchBackground(boolean dismissOnTouchBackground) {
            mDismissOnTouchBackground = dismissOnTouchBackground;
            return this;
        }

        public Builder<T> setDismissOnClickBack(boolean dismissOnClickBack) {
            mDismissOnClickBack = dismissOnClickBack;
            return this;
        }

        public Builder<T> setOnDismissListener(OnDismissListener onDismissListener) {
            mOnDismissListener = onDismissListener;
            return this;
        }

        protected T createPopupWindow() {
            //noinspection unchecked
            return (T) new CompleteCookingPopup(mContext);
        }

        public T build() {
            final T popupWindow = createPopupWindow();
            ViewGroup.LayoutParams layoutParams = null;
            if (mContentView != null) {
                popupWindow1 = popupWindow;
                LocalBroadcastManager.getInstance(mContext).unregisterReceiver(broadcastManager);
                LocalBroadcastManager.getInstance(mContext).registerReceiver(broadcastManager, new IntentFilter("DismissDialog"));
                layoutParams = mContentView.getLayoutParams();
                if (layoutParams == null || !(layoutParams instanceof LayoutParams)) {
                    layoutParams = new LayoutParams(layoutParams.width, layoutParams.height);
                }
                if (mGravity != -1) {
                    ((LayoutParams) layoutParams).gravity = Gravity.CENTER;
                }
                mContentView.setLayoutParams(layoutParams);
                popupWindow.setContentView(mContentView);
                AppCompatTextView textView = mContentView.findViewById(R.id.tvMsg);
                AppCompatTextView btnDone = mContentView.findViewById(R.id.btnDone);
                AppCompatTextView headerText2 = mContentView.findViewById(R.id.tvHeaderMsg);
                AppCompatImageView ivTop = mContentView.findViewById(R.id.ivAlertTop);
                textView.setText(msgText);
                btnDone.setText(buttonText);
                headerText2.setText(headerText);
                ivTop.setImageDrawable(drawable);

                btnDone.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        clickOnFavouritePopup1.onItemClick(0, "");
//                        popupWindow.dismiss();
                        if (realPopupWindow11.isShowing()) {
                            realPopupWindow11.dismiss();
                        }
                    }
                });

            }
            popupWindow.setTintColor(mTintColor);
            popupWindow.setAnimationDuration(mAnimationDuration);
            popupWindow.setBlurRadius(mBlurRadius);
            popupWindow.setScaleRatio(mScaleRatio);
            popupWindow.setDismissOnTouchBackground(mDismissOnTouchBackground);
            popupWindow.setDismissOnClickBack(mDismissOnClickBack);
            popupWindow.setOnDismissListener(mOnDismissListener);
            realPopupWindow11 = new PopupWindow(popupWindow, layoutParams.width, layoutParams.height, true);
            try {
//                if (!realPopupWindow11.isShowing()) {
                    realPopupWindow11.showAtLocation(popupWindow, Gravity.CENTER, 0, 0);
//                }
            } catch (Exception e) {
            }
            return popupWindow;
        }

        public BroadcastReceiver broadcastManager = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                try {
                    if (realPopupWindow11 != null) {
                        realPopupWindow11.dismiss();
                    }
                }catch (Exception e){
                    if (realPopupWindow11 != null) {
                        realPopupWindow11.dismiss();
                    }
                }
            }
        };
    }

}
