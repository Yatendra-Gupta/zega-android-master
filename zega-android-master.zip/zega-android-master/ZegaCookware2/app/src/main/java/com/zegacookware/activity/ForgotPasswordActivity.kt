package com.zegacookware.activity

import android.app.Activity
import android.content.Context
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.InputFilter
import android.view.Gravity
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.zegacookware.interfaces.ClickOnFavouritePopup
import com.zegacookware.util.CommonUtility
import com.zegacookware.R
import com.zegacookware.model.user.Forgot
import com.zegacookware.model.user.LoginRequest
import com.zegacookware.network.Constant
import com.zegacookware.util.blurBackground.BlurPopupWindowTemp
import kotlinx.android.synthetic.main.activity_forgot_pass.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ForgotPasswordActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_pass)

        hideKeyboard()
        etEmail.filters = etEmail.filters + InputFilter.AllCaps()

        btnResetPass.setOnClickListener {
            postResetPass()
        }

        back.setOnClickListener { finish() }
    }

    private fun postResetPass() {
        if (etEmail.text.toString().isEmpty()) {
            CommonUtility.openDialog(
                "PLEASE ENTER EMAIL",
                "OK",
                ContextCompat.getDrawable(this, R.drawable.ic_alert)!!,
                this
            )
            return
        }

        if (!CommonUtility.isEmailValid(etEmail.text.toString())) {
            CommonUtility.openDialog(
                "PLEASE ENTER VALID EMAIL",
                "OK",
                ContextCompat.getDrawable(this, R.drawable.ic_alert)!!,
                this
            )
            return
        }

        CommonUtility.showProgressDialog(this@ForgotPasswordActivity)
        Constant.service.forgotPasswordMethod(
            LoginRequest(
                user_email = etEmail.text.toString().trim()
            )
        ).apply {
            enqueue(object : Callback<Forgot> {
                override fun onFailure(call: Call<Forgot>, t: Throwable) {
                    CommonUtility.hideProgressBar()
                    CommonUtility.showToast(
                        this@ForgotPasswordActivity,
                        "Something went wrong"
                    )
                }

                override fun onResponse(
                    call: Call<Forgot>,
                    response: Response<Forgot>
                ) {
                    CommonUtility.hideProgressBar()
                    if (response.isSuccessful && response.body()?.status == 1) {
                        openSuccessDialog(
                            response.body()?.msg!!,
                            "OK",
                            ContextCompat.getDrawable(
                                this@ForgotPasswordActivity,
                                R.drawable.ic_right
                            )!!,
                            this@ForgotPasswordActivity
                        )
                    } else if (response.isSuccessful && response.body()?.status == 0) {

                        CommonUtility.openDialog(
                            "" + response.body()?.msg!!,
                            "OK",
                            ContextCompat.getDrawable(
                                this@ForgotPasswordActivity,
                                R.drawable.ic_alert
                            )!!,
                            this@ForgotPasswordActivity
                        )
                    } else {
                        CommonUtility.showToast(
                            this@ForgotPasswordActivity,
                            "Something went wrong"
                        )
                    }
                }
            })
        }
    }

    fun openSuccessDialog(msgString: String, buttonText: String, ids: Drawable, mContext: Context) {
        BlurPopupWindowTemp.Builder<BlurPopupWindowTemp>(
            mContext as Activity,
            msgString,
            buttonText,
            "ALERT!",
            ids, object : ClickOnFavouritePopup {
                override fun onItemClick(position: Int, cusineType: String) {
                    finish()
                }
            }
        ).setContentView(R.layout.dialog_success_message)
            .setGravity(Gravity.CENTER)
            .setScaleRatio(0.1f)
            .setBlurRadius(Constant.blurRadius)
            .setDismissOnClickBack(false)
            .setDismissOnTouchBackground(false)
            .build()
            .show()
    }

    private fun AppCompatActivity.hideKeyboard() {
        val view = this.currentFocus
        if (view != null) {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(view.windowToken, 0)
        }
        // else {
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        // }
    }
}
