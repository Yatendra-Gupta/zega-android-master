package com.zegacookware.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.zegacookware.R
import com.zegacookware.model.feedback.FeedbackData
import com.zegacookware.activity.setting.FeedbackNegativeActivity
import kotlinx.android.synthetic.main.item_feedback.view.*

class FeedbackAdapter(
    var mContext: Context,
    var feedbackData: List<FeedbackData>
) :
    RecyclerView.Adapter<FeedbackAdapter.RecipesViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecipesViewHolder {
        val view =
            LayoutInflater.from(mContext).inflate(R.layout.item_feedback, parent, false)
        return RecipesViewHolder(view)
    }

    override fun getItemCount(): Int {
        return feedbackData.size
    }

    override fun onBindViewHolder(holder: RecipesViewHolder, position: Int) {
        holder.itemView.radioButton1.text = feedbackData[position].master_feedback
        holder.itemView.radioButton1.setOnClickListener {
            if (FeedbackNegativeActivity.feedback_id.contains(""+feedbackData[position].master_id)){
                FeedbackNegativeActivity.feedback_id.remove(""+feedbackData[position].master_id)
            }else{
                FeedbackNegativeActivity.feedback_id.add(""+feedbackData[position].master_id!!)
            }
        }
        if (position==feedbackData.size-1){
            holder.itemView.viewFeedback.visibility=View.GONE
        }else{
            holder.itemView.viewFeedback.visibility=View.VISIBLE
        }
    }

    class RecipesViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    }
}