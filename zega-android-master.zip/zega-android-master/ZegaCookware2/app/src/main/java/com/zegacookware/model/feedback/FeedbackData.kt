package com.zegacookware.model.feedback

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class FeedbackData {
    @SerializedName("master_id")
    @Expose
    var master_id: Int? = null
    @SerializedName("master_feedback")
    @Expose
    var master_feedback: String? = null
    @SerializedName("deleted")
    @Expose
    var deleted: Int? = null

}
