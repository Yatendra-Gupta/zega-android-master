package com.zegacookware.model.recipes.recipesdetail

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class IngriendientResult {

    @SerializedName("ingridient_id")
    @Expose
    var ingridientId: Int? = null
    @SerializedName("recepie_id")
    @Expose
    var recepieId: Int? = null
    @SerializedName("ingriedient_name")
    @Expose
    var ingriedientName: String? = null
    @SerializedName("ingriedient_quantity")
    @Expose
    var ingriedientQuantity: String? = null
    @SerializedName("ingriedient_quantity_type")
    @Expose
    var ingriedientQuantityType: String? = null
    @SerializedName("ingriedient_wise")
    @Expose
    var ingriedientWise: String? = null
    @SerializedName("quantity_type")
    @Expose
    var quantityType: String? = null

//    serve_required ,  serve_size , quantity_type

}
