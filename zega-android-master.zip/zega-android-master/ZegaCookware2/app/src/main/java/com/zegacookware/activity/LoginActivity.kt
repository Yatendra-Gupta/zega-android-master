package com.zegacookware.activity

import android.content.Context
import android.content.Intent
import android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK
import android.content.Intent.FLAG_ACTIVITY_NEW_TASK
import android.os.Bundle
import android.text.InputFilter
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.iid.FirebaseInstanceId
import com.zegacookware.R
import com.zegacookware.activity.manage_device.DeviceSelectActivity
import com.zegacookware.model.AddDeviceRequest
import com.zegacookware.model.UserDevices
import com.zegacookware.model.user.LoginRequest
import com.zegacookware.model.user.UserInfo
import com.zegacookware.model.user.UserModel
import com.zegacookware.network.Constant
import com.zegacookware.util.CommonUtility
import kotlinx.android.synthetic.main.activity_login.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class LoginActivity : AppCompatActivity() {
    private var deviceToken: String = ""
    private lateinit var mContext: Context


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        mContext = this@LoginActivity

        etEmail.filters = etEmail.filters + InputFilter.AllCaps()
        hideKeyboard()

        try {
            deviceToken = FirebaseInstanceId.getInstance().token!!
        } catch (e: Exception) {
        }

        btnSignIn.setOnClickListener {
            postLogin()
        }
        back.setOnClickListener {
            finish()
        }
        btnForgot.setOnClickListener {
            startActivity(Intent(this@LoginActivity, ForgotPasswordActivity::class.java))
        }

        FirebaseInstanceId.getInstance().instanceId
            .addOnCompleteListener(OnCompleteListener { task ->
                if (!task.isSuccessful) {
                    return@OnCompleteListener
                }
                // Get new Instance ID token
                deviceToken = task.result?.token!!
            })

        etEmail.setText(CommonUtility.getStringPreference("email", this@LoginActivity))
        etPassword.setText(CommonUtility.getStringPreference("password", this@LoginActivity))

        etEmail.placeCursorToEnd()

        btnShowPass.setOnClickListener {
            if (ContextCompat.getDrawable(
                    mContext,
                    R.drawable.eye_show
                )!!.constantState == btnShowPass.drawable.constantState
            ) {
                etPassword.transformationMethod = PasswordTransformationMethod.getInstance()
                btnShowPass.setImageDrawable(
                    ContextCompat.getDrawable(
                        mContext,
                        R.drawable.eye_hide
                    )
                )
            } else {
                etPassword.transformationMethod = HideReturnsTransformationMethod.getInstance()
                btnShowPass.setImageDrawable(
                    ContextCompat.getDrawable(
                        mContext,
                        R.drawable.eye_show
                    )
                )
            }
            etPassword.placeCursorToEnd()
        }
    }

    private fun postLogin() {
        if (etEmail.text.toString().isEmpty()) {
            CommonUtility.openDialog(
                "PLEASE ENTER EMAIL",
                "OK",
                ContextCompat.getDrawable(this, R.drawable.ic_alert)!!,
                this
            )
            return
        }
        if (!CommonUtility.isEmailValid(etEmail.text.toString())) {
            CommonUtility.openDialog(
                "PLEASE ENTER VALID EMAIL",
                "OK",
                ContextCompat.getDrawable(this, R.drawable.ic_alert)!!,
                this
            )
            return
        }
        if (etPassword.text.toString().isEmpty()) {
            CommonUtility.openDialog(
                "PLEASE ENTER PASSWORD",
                "OK",
                ContextCompat.getDrawable(this@LoginActivity, R.drawable.ic_alert)!!,
                this@LoginActivity
            )
            return
        }

        CommonUtility.showProgressDialog(mContext)
        Constant.service.loginMethod(
            LoginRequest(
                user_email = etEmail.text.toString().trim(),
                password = etPassword.text.toString().trim(),
                device_token = deviceToken,
                device_type = "Android"
            )
        ).apply {
            enqueue(object : Callback<UserInfo> {
                override fun onFailure(call: Call<UserInfo>, t: Throwable) {
                    CommonUtility.openDialog(
                        "SOMETHING WENT WRONG",
                        "OK",
                        ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
                        mContext
                    )
                    CommonUtility.hideProgressBar()
                }

                override fun onResponse(
                    call: Call<UserInfo>,
                    response: Response<UserInfo>
                ) {
                    CommonUtility.hideProgressBar()
                    if (response.isSuccessful && response.body()?.status == 1 && response.body()?.userResult != null) {

                        CommonUtility.setStringPreference(
                            etEmail.text.toString(),
                            "email",
                            this@LoginActivity
                        )
                        CommonUtility.setStringPreference(
                            etPassword.text.toString(),
                            "password",
                            this@LoginActivity
                        )

                        UserModel.userInfo = response.body()?.userResult!!
                        CommonUtility.setUserData(
                            response.body()?.userResult!!,
                            Constant.userInfo,
                            this@LoginActivity
                        )
                        CommonUtility.setBooleanPreference(
                            true,
                            Constant.isLoggedIn,
                            this@LoginActivity
                        )
//                        getDevices()
                        startActivity(
                            Intent(this@LoginActivity, MainActivity::class.java).putExtra("isFromTimer",false)
                                .setFlags(FLAG_ACTIVITY_NEW_TASK or FLAG_ACTIVITY_CLEAR_TASK)
                        )
                        finish()
                    } else if (response.isSuccessful && response.body()?.status == 0) {
                        CommonUtility.openDialog(
                            "" + response.body()?.msg!!,
                            "OK",
                            ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
                            mContext
                        )
                    }
                }
            })
        }
    }

    private fun getDevices() {
        //CommonUtility.showProgressDialog(this@MainActivity)
        Constant.service.getUserDevices(AddDeviceRequest(user_id = "" + UserModel.userInfo.userId))
            .apply {
                enqueue(object : Callback<UserDevices> {
                    override fun onFailure(call: Call<UserDevices>, t: Throwable) {
                        //     CommonUtility.hideProgressBar()
                    }

                    override fun onResponse(
                        call: Call<UserDevices>,
                        response: Response<UserDevices>
                    ) {
                        //CommonUtility.hideProgressBar()
                        if (response.isSuccessful && response.body()?.status == 1) {
                            CommonUtility.setBooleanPreference(
                                true,
                                "isDeviceAvailable",
                                this@LoginActivity
                            )
                            startActivity(
                                Intent(this@LoginActivity, MainActivity::class.java)
                                    .putExtra("isFromTimer",false)
                                    .setFlags(FLAG_ACTIVITY_NEW_TASK or FLAG_ACTIVITY_CLEAR_TASK)
                            )
                            finish()
                        } else {
                            startActivity(
                                Intent(
                                    this@LoginActivity,
                                    DeviceSelectActivity::class.java
                                ).putExtra("isFromSignUp", true)
                                    .setFlags(FLAG_ACTIVITY_NEW_TASK or FLAG_ACTIVITY_CLEAR_TASK)
                            )
                        }
                    }
                })
            }
    }

    private fun EditText.placeCursorToEnd() {
        this.setSelection(this.text.length)
    }

    private fun AppCompatActivity.hideKeyboard() {
        val view = this.currentFocus
        if (view != null) {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(view.windowToken, 0)
        }
        // else {
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        // }
    }

}
