package com.zegacookware.model

import com.zegacookware.R


enum class IntroSliderModel private constructor(val layoutResId: Int) {
    RED(R.layout.layout_one),
    BLUE(R.layout.layout_two),
    GREEN(R.layout.layout_three),
    YELLOW(R.layout.layout_four)
}