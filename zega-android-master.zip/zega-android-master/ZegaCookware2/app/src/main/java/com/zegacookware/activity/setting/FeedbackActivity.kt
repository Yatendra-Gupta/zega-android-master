package com.zegacookware.activity.setting

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.Gravity
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.zegacookware.interfaces.ClickOnFavouritePopup
import com.zegacookware.util.CommonUtility
import com.zegacookware.R
import com.zegacookware.model.recipes.recipesdetail.FavouriteResponse
import com.zegacookware.model.user.ChangePasswordRequest
import com.zegacookware.model.user.UserResult
import com.zegacookware.network.Constant
import com.zegacookware.util.blurBackground.BlurPopupWindowTemp
import kotlinx.android.synthetic.main.activity_feedback.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class FeedbackActivity : AppCompatActivity() {


    private lateinit var userData: UserResult

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(com.zegacookware.R.layout.activity_feedback)
        userData = CommonUtility.getUserData(Constant.userInfo, this@FeedbackActivity)

        btnPositive.setOnClickListener {
            Constant.service.userPositiveFeedback(ChangePasswordRequest(user_id = "" + userData.userId))
                .apply {
                    enqueue(object : Callback<FavouriteResponse> {
                        override fun onFailure(call: Call<FavouriteResponse>, t: Throwable) {
                        }

                        override fun onResponse(
                            call: Call<FavouriteResponse>,
                            response: Response<FavouriteResponse>
                        ) {
                            if (response.isSuccessful && response.body()?.status == 1){
                                openDialog(
                                    response.body()?.msg!!,
                                    "Done",
                                    ContextCompat.getDrawable(this@FeedbackActivity, R.drawable.ic_right)!!,
                                    this@FeedbackActivity
                                )
                            } else if (response.isSuccessful && response.body()?.status == 0) {
                                CommonUtility.openDialog(
                                    response.body()?.msg!!,
                                    "OK",
                                    ContextCompat.getDrawable(this@FeedbackActivity, R.drawable.ic_alert)!!,
                                    this@FeedbackActivity
                                )
                            }

                        }

                    })
                }

        }

        btnBackFeed.setOnClickListener { finish() }
        btnNegative.setOnClickListener {
            startActivity(Intent(this@FeedbackActivity, FeedbackNegativeActivity::class.java))
            finish()
        }



//        rgRadioGroup.setOnCheckedChangeListener(
//            RadioGroup.OnCheckedChangeListener { group, checkedId ->
//                val radio: RadioButton = findViewById(checkedId)
////                Toast.makeText(
////                    applicationContext, " On checked change : ${radio.text}",
////                    Toast.LENGTH_SHORT
////                ).show()
//            })

    }

    fun openDialog(msgString: String, buttonText: String, ids: Drawable, mContext: Context) {
        BlurPopupWindowTemp.Builder<BlurPopupWindowTemp>(
            mContext as Activity,
            msgString,
            buttonText,
            "",
            ids, object : ClickOnFavouritePopup {
                override fun onItemClick(position: Int, cusineType: String) {
                    startActivity(
                        Intent(
                            this@FeedbackActivity,
                            FeedbackPositiveActivity::class.java
                        )
                    )
                    finish()
                }
            }
        ).setContentView(R.layout.dialog_validation)
            .setGravity(Gravity.CENTER)
            .setScaleRatio(0.1f)
            .setBlurRadius(Constant.blurRadius)
            .setDismissOnTouchBackground(false)
            .setDismissOnClickBack(false)
            .build()
            .show()
    }
}



