package com.zegacookware.activity.setting

import android.app.Activity
import android.content.Context
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.Gravity
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.zegacookware.interfaces.ClickOnFavouritePopup
import com.zegacookware.util.CommonUtility
import com.zegacookware.R
import com.zegacookware.adapter.FeedbackAdapter
import com.zegacookware.model.feedback.FeedBackResult
import com.zegacookware.model.feedback.SubmitFeedback
import com.zegacookware.model.recipes.recipesdetail.FavouriteResponse
import com.zegacookware.model.user.UserResult
import com.zegacookware.network.Constant
import com.zegacookware.util.blurBackground.BlurPopupWindowTemp
import kotlinx.android.synthetic.main.activity_negative_feedback.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class FeedbackNegativeActivity : AppCompatActivity() {

    private lateinit var userData: UserResult

    companion object {
        var feedback_id: ArrayList<String> = ArrayList<String>()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_negative_feedback)
        userData = CommonUtility.getUserData(Constant.userInfo, this@FeedbackNegativeActivity)

        CommonUtility.showProgressDialog(this)

        rvFeedBack.layoutManager =
            LinearLayoutManager(this@FeedbackNegativeActivity) as RecyclerView.LayoutManager?


        Constant.service.getMasterFeedback().apply {
            enqueue(object : Callback<FeedBackResult> {
                override fun onFailure(call: Call<FeedBackResult>, t: Throwable) {
                    CommonUtility.hideProgressBar()
                }

                override fun onResponse(
                    call: Call<FeedBackResult>,
                    response: Response<FeedBackResult>
                ) {
                    CommonUtility.hideProgressBar()
                    if (response.isSuccessful && response.body()?.status == 1) {
                        val adapter = FeedbackAdapter(
                            this@FeedbackNegativeActivity,
                            response.body()?.feedbackData!!
                        )
                        rvFeedBack.adapter = adapter
                    }
                }
            })
        }

        btnSubmitFeed.setOnClickListener {
            CommonUtility.showProgressDialog(this)
            Constant.service.submitFeedback(
                SubmitFeedback(
                    feedback_id = feedback_id.joinToString(),
                    user_id = "" + userData.userId
                )
            ).apply {
                enqueue(object : Callback<FavouriteResponse> {
                    override fun onFailure(call: Call<FavouriteResponse>, t: Throwable) {
                        CommonUtility.hideProgressBar()
                    }

                    override fun onResponse(
                        call: Call<FavouriteResponse>,
                        response: Response<FavouriteResponse>
                    ) {
                        CommonUtility.hideProgressBar()
                        if (response.isSuccessful && response.body()?.status == 1) {
                            feedback_id.clear()
                            openDialog(
                                response.body()?.msg!!,
                                "Ok",
                                ContextCompat.getDrawable(this@FeedbackNegativeActivity, R.drawable.ic_right)!!,
                                this@FeedbackNegativeActivity
                            )
                        }
                    }
                })
            }
        }

        btnBackFeed.setOnClickListener { finish() }

    }
    fun openDialog(msgString: String, buttonText: String, ids: Drawable, mContext: Context) {
        BlurPopupWindowTemp.Builder<BlurPopupWindowTemp>(
            mContext as Activity,
            msgString,
            buttonText,
            "",
            ids,object : ClickOnFavouritePopup {
                override fun onItemClick(position: Int, cusineType: String) {
                    finish()
                }
            }
        ).setContentView(R.layout.dialog_validation)
            .setGravity(Gravity.CENTER)
            .setScaleRatio(0.1f)
            .setBlurRadius(Constant.blurRadius)
            .setDismissOnTouchBackground(false)
            .setDismissOnClickBack(false)
            .build()
            .show()
    }

}



