package com.zegacookware.model.recipes.recipesdetail

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class RecepieDetailsResult {

    @SerializedName("recepie_id")
    @Expose
    var recepieId: Int? = null
    @SerializedName("recepie_title")
    @Expose
    var recepieTitle: String? = null
    @SerializedName("recepie_description")
    @Expose
    var recepieDescription: String? = null
    @SerializedName("recepie_image")
    @Expose
    var recepieImage: String? = null
    @SerializedName("recepie_time")
    @Expose
    var recepieTime: Int? = null
    @SerializedName("recepie_temperature")
    @Expose
    var recepieTemperature: Int? = null
    @SerializedName("recepie_instructions")
    @Expose
    var recepieInstructions: String? = null
    @SerializedName("serve_required")
    @Expose
    var serveRequired: String? = null
    @SerializedName("serve_size")
    @Expose
    var serveSize: Int? = 0
}
