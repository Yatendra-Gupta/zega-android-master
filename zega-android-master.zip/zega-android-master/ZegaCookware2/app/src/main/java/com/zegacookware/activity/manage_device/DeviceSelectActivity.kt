package com.zegacookware.activity.manage_device

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.zegacookware.R
import com.zegacookware.activity.MainActivity
import com.zegacookware.interfaces.ClickOnFavouritePopup
import com.zegacookware.model.AddDeviceRequest
import com.zegacookware.model.recipes.recipesdetail.FavouriteResponse
import com.zegacookware.model.user.UserModel
import com.zegacookware.model.user.UserResult
import com.zegacookware.network.Constant
import com.zegacookware.util.CommonUtility
import com.zegacookware.util.blurBackground.BlurPopupWindowTemp
import kotlinx.android.synthetic.main.activity_device_select.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DeviceSelectActivity : AppCompatActivity() {
    private val STRING_CHARACTERS = ('0'..'z').toList().toTypedArray()
    private lateinit var userData: UserResult
    private lateinit var vibrator: Vibrator
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_device_select)
        userData = CommonUtility.getUserData(Constant.userInfo, this@DeviceSelectActivity)

        vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator

        if (intent.getBooleanExtra("isFromSignUp", false)) {
            ivBack.visibility = View.GONE
            btnBuyZega.visibility = View.GONE
            val param = tvDeviceSelect.layoutParams as LinearLayout.LayoutParams
            param.setMargins(15, 0, 0, 0)
            tvDeviceSelect.layoutParams = param
        }

        btnDigital.setOnClickListener {
            callVibration()
            startActivity(
                Intent(this, ConnectBluetoothActivity::class.java).putExtra(
                    "device_name",
                    "digital"
                ).putExtra("isFromSignUp", intent.getBooleanExtra("isFromSignUp", false))
            )
        }
        btnAnalogue.setOnClickListener {
            callVibration()
            addDevice()
        }

        ivBack.setOnClickListener { finish() }
    }

    private fun callVibration() {
        if (Build.VERSION.SDK_INT >= 26) {
            vibrator.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            vibrator.vibrate(200)
        }
    }

    override fun onResume() {
        super.onResume()
        if (UserModel.isFromConnectScreen) {
            UserModel.isFromConnectScreen = false
            finish()
        }
    }

    private fun addDevice() {
        val deviceId = (1..32).map { STRING_CHARACTERS.random() }.joinToString("")
        CommonUtility.showProgressDialog(this@DeviceSelectActivity)
        Constant.service.addDevices(
            AddDeviceRequest(
                user_id = "" + userData.userId,
                device_id = deviceId,
                device_name = "analogue",
                mac_id = deviceId
            )
        ).apply {
            enqueue(object : Callback<FavouriteResponse> {
                override fun onFailure(call: Call<FavouriteResponse>, t: Throwable) {
                    CommonUtility.hideProgressBar()
                }

                override fun onResponse(
                    call: Call<FavouriteResponse>,
                    response: Response<FavouriteResponse>
                ) {
                    CommonUtility.hideProgressBar()
                    CommonUtility.setStringPreference(
                        deviceId,
                        "deviceId",
                        this@DeviceSelectActivity
                    )
                    CommonUtility.setBooleanPreference(
                        false,
                        Constant.isDigital,
                        this@DeviceSelectActivity
                    )
                    openConnectDialog(
                        "CONGRATULATIONS\n" +
                                "YOU HAVE ADDED\n" +
                                "‘" + userData.name + "’S ZEGA’",
                        "OK",
                        ContextCompat.getDrawable(
                            this@DeviceSelectActivity,
                            R.drawable.ic_right
                        )!!,
                        this@DeviceSelectActivity
                    )
                    CommonUtility.setBooleanPreference(
                        true,
                        "isDeviceAvailable",
                        this@DeviceSelectActivity
                    )
                }

            })
        }
    }

    fun openConnectDialog(msgString: String, buttonText: String, ids: Drawable, mContext: Context) {
        BlurPopupWindowTemp.Builder<BlurPopupWindowTemp>(
            mContext as Activity,
            msgString,
            buttonText,
            "",
            ids, object : ClickOnFavouritePopup {
                override fun onItemClick(position: Int, cusineType: String) {
                    if (intent.getBooleanExtra("isFromSignUp", false)) {
                        startActivity(
                            Intent(
                                this@DeviceSelectActivity,
                                MainActivity::class.java
                            ).putExtra("isFromTimer", false)
                                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                        )
                    }
                    finish()
                }
            }
        ).setContentView(R.layout.dialog_add_device_done)
            .setGravity(Gravity.CENTER)
            .setScaleRatio(0.1f)
            .setBlurRadius(Constant.blurRadius)
            .setDismissOnClickBack(false)
            .setDismissOnTouchBackground(false)
            .build()
            .show()
    }


}
