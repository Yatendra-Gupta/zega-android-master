package com.zegacookware.interfaces

import com.zegacookware.model.recipes.GetFoodTypeData

interface SetOnItemClickListenerPopup {
    fun onItemClick(getFoodTypeData: GetFoodTypeData)
}