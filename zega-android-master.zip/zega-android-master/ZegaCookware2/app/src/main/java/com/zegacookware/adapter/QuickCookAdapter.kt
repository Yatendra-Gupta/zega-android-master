package com.zegacookware.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.zegacookware.R
import com.zegacookware.interfaces.SetOnItemClickListener
import com.zegacookware.model.quickcook.QuickCookData
import com.zegacookware.network.Constant
import kotlinx.android.synthetic.main.item_recipes_category.view.*

class QuickCookAdapter(
    var mContext: Context,
    var categoryList: List<QuickCookData>,
    var setOnItemClickListener: SetOnItemClickListener
) :
    RecyclerView.Adapter<QuickCookAdapter.RecipesViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecipesViewHolder {
        val view =
            LayoutInflater.from(mContext).inflate(R.layout.item_recipes_category, parent, false)
        return RecipesViewHolder(view)
    }

    override fun getItemCount(): Int {
        return categoryList.size
    }

    override fun onBindViewHolder(holder: RecipesViewHolder, position: Int) {
        holder.itemView.tvCategoryName.text = categoryList[position].recepieCategoryName
        Glide.with(mContext)
            .load(Constant.categoryImageBaseUrl+categoryList[position].recepieImage)
            .centerCrop()
            .into(holder.itemView.ivRecipes)

        holder.itemView.setOnClickListener { setOnItemClickListener.onItemClick(position) }
//        if (position==categoryList.size-1){
//                holder.itemView.divider.visibility=View.GONE
//        }
    }

    class RecipesViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    }
}