package com.zegacookware.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.RecyclerView

import com.zegacookware.R
import com.zegacookware.interfaces.SetOnItemClickListenerPopup
import com.zegacookware.activity.RecipesActivity
import com.zegacookware.model.recipes.GetFoodTypeData
import kotlinx.android.synthetic.main.item_favorite_type.view.*

import java.util.ArrayList

class FavouriteTypeListAdapter(
    private val mContext: Context,
    private val favouriteType: ArrayList<GetFoodTypeData>,
    private val setOnItemClickListener: SetOnItemClickListenerPopup
) : RecyclerView.Adapter<FavouriteTypeListAdapter.MyViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view = LayoutInflater.from(mContext).inflate(R.layout.item_favorite_type, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.itemView.tvFavoriteType.text = favouriteType[position].food_type_name

        if (RecipesActivity.cusineList.contains(""+favouriteType[position].food_type_id!!)) {
            val typeface1 = ResourcesCompat.getFont(mContext, R.font.poppins_semibold)
            holder.itemView.tvFavoriteType.typeface=typeface1
        } else {
            val typeface2 = ResourcesCompat.getFont(mContext, R.font.poppins_extralight)
            holder.itemView.tvFavoriteType.typeface=typeface2
        }

        holder.itemView.tvFavoriteType.setOnClickListener {
            if (RecipesActivity.cusineList.contains(""+favouriteType[position].food_type_id!!)) {
                RecipesActivity.cusineList.remove(""+favouriteType[position].food_type_id!!)
                val typeface1 = ResourcesCompat.getFont(mContext, R.font.poppins_extralight)
                holder.itemView.tvFavoriteType.typeface=typeface1
            } else {
                RecipesActivity.cusineList.add(""+favouriteType[position].food_type_id!!)
                val typeface2 = ResourcesCompat.getFont(mContext, R.font.poppins_semibold)
                holder.itemView.tvFavoriteType.typeface=typeface2
            }
            setOnItemClickListener.onItemClick(favouriteType[position])
        }
    }

    override fun getItemCount(): Int {
        return favouriteType.size
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    }
}
