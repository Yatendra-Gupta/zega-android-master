package com.zegacookware.service

import android.annotation.SuppressLint
import android.app.Service
import android.bluetooth.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.CountDownTimer
import android.os.Handler
import android.os.IBinder
import android.util.Log
import android.view.*
import android.widget.ImageView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.zegacookware.R
import com.zegacookware.activity.BaseActivity
import com.zegacookware.activity.MainActivity
import com.zegacookware.activity.bl.DigitalTimerActivity
import com.zegacookware.model.user.UserModel
import com.zegacookware.network.Constant
import com.zegacookware.util.CommonUtility
import org.jetbrains.anko.runOnUiThread
import java.util.*
import kotlin.math.roundToInt


class DigitalTimerService : Service() {

    private var isCookingCompleteBroadcastSend: Boolean = false
    private var currentDeviceTime: Long = 0
    private var isTempCalled: Boolean = false
    private var isTempNotifyContinue: Boolean = false
    private var isCalled: Boolean = false
    private var isNotifyData: Boolean = true
    private var isOpenTryAgain: Boolean? = false
    private var hardwareState: Int = 0
    private var isBroadcastIsCall: Boolean = false
    private val TAG: String? = "Service ======"
    private lateinit var mDeviceAddress: String
    private var recipesTime: Long = 0
    private var recipesTimeInMin: Long = 0

    private var recipesTemp: Long = 0
    private var mBluetoothAdapter: BluetoothAdapter? = null
    private var mBluetoothDeviceAddress: String? = null

    private var mConnectionState = STATE_DISCONNECTED
    private var countDown: CountDownTimer? = null
    private lateinit var intentPopup: Intent
    private var isTempWrite: Boolean = true

    private var mWindowManager: WindowManager? = null
    private var mChatHeadView: View? = null
    private var timer1: ImageView? = null
    private var timer2: ImageView? = null
    private var timer3: ImageView? = null
    private var timer4: ImageView? = null
    private var timer5: ImageView? = null
    private var timer6: ImageView? = null
    private var timer7: ImageView? = null
    private var timer8: ImageView? = null
    private var timer9: ImageView? = null
    private var timer10: ImageView? = null
    private var timer11: ImageView? = null
    private var timer12: ImageView? = null
    private var countJobScheduler: Int = 0

//    init {
//        instance = this
//    }

    override fun onBind(intent: Intent): IBinder? {
        return null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (isOpenTryAgain!!) {
//            CommonUtility.hideProgressBar()
            mBluetoothGatt = null
            connect(mDeviceAddress)
        }
        return START_STICKY
    }

    private val mGattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {

            if (newState == BluetoothProfile.STATE_CONNECTED) {
                Log.e("Service ===>", "Connnected")
                mBluetoothGatt!!.discoverServices()
                UserModel.isHardwareOutOfRange = false
                if (countJobScheduler < 1) {
                    BaseActivity.openJobScheduler(applicationContext)
                    countJobScheduler++
                }
                CommonUtility.hideProgressBar()
                isOpenTryAgain = false
                LocalBroadcastManager.getInstance(applicationContext)
                    .sendBroadcast(Intent("DismissDialog"))
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                isTempNotifyContinue = false
                if (CommonUtility.getBooleanPreference(
                        Constant.cookingIsRunning,
                        applicationContext
                    ) && !isOpenTryAgain!!
                ) {
                    isOpenTryAgain = true
                    UserModel.isHardwareOutOfRange = true
                    CommonUtility.sendNotificationOutOfTheRange(
                        "Zega",
                        "Your Device is out of range from Zega",
                        applicationContext
                    )
                    CommonUtility.hideProgressBar()

                    Thread.sleep(100)
                    openTryAgain()
                }
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                val mCustomService =
                    gatt.getService(UUID.fromString("0000FFF0-0000-1000-8000-00805F9B34FB"))

                if (mCustomService == null) {
                    Log.w("Test", "Custom BLE Service not found on write")
                    return
                }
                /*get the read characteristic from the service*/
                val mWriteCharacteristic =
                    mCustomService.getCharacteristic(UUID.fromString("0000FFF5-0000-1000-8000-00805F9B34FB"))

                UserModel.mBluetoothGattChar = mWriteCharacteristic

                if (CommonUtility.getBooleanPreference(
                        Constant.isShowTemperatureView,
                        applicationContext
                    ) && !isOpenTryAgain!! && !CommonUtility.getBooleanPreference(
                        Constant.cookingIsRunning,
                        applicationContext
                    )
                ) {
                    Log.e("Service ====>  ", "Temperature")

                    val recipesTemp1 =
                        CommonUtility.getStringPreference("recipesTemp", applicationContext)
                            .toLong()

                    var recipesTime1 =
                        CommonUtility.getStringPreference("recipesTime", applicationContext)
                            .toLong()

                    recipesTime1 *= 60

                    val byte = ByteArray(6)
                    byte[0] = 0x01
                    byte[1] = recipesTemp1.toByte()//temp
                    byte[2] = (recipesTime1 and 0xFF).toByte()//time
                    byte[3] = (recipesTime1 shr 8 and 0xFF).toByte()//time

                    mWriteCharacteristic.value = byte
                    gatt.writeCharacteristic(mWriteCharacteristic)

                } else {
                    UserModel.isCallFromDevice = false

                    Log.e("Service ====>  ", "timer time")

                    val byte1 = byteArrayOf(0x08, 0x25, 0x00, 0x00, 0x00, 0x00, 0x00)
                    mWriteCharacteristic.value = byte1
//                mWriteCharacteristic.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                    gatt.writeCharacteristic(mWriteCharacteristic)
                    setCharacteristicNotification(isNotifyData, gatt)

                }
//                else {
//                    isOpenTryAgain = false
//                    isTempWrite = false
//                    val byte1 = byteArrayOf(0x0B, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00)
//                    mWriteCharacteristic.value = byte1
//                    gatt.writeCharacteristic(mWriteCharacteristic)
//                }
            } else {
                Log.d("", "onServicesDiscovered received: $status")
            }
        }

        override fun onCharacteristicRead(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            status: Int
        ) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
            }
        }

        override fun onCharacteristicWrite(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            status: Int
        ) {
            CommonUtility.hideProgressBar()
            if (isTempWrite /*&& CommonUtility.getBooleanPreference(
                    Constant.isShowTemperatureView,
                    applicationContext
                )*/
            ) {
                CommonUtility.setBooleanPreference(
                    true,
                    Constant.cookingIsRunning,
                    applicationContext
                )
                isTempWrite = false
                val byte1 = byteArrayOf(0x0B, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00)
                characteristic.value = byte1
//                mWriteCharacteristic.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                gatt.writeCharacteristic(characteristic)
                Log.e("Service ====>  ", "isTempWrite")
            } else {
                Log.e("Service ====>  ", "isNotifyData")
                LocalBroadcastManager.getInstance(applicationContext)
                    .sendBroadcast(Intent("DismissDialog"))
                setCharacteristicNotification(isNotifyData, gatt)
            }
        }

        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic
        ) {
//            Log.e("TEMP===>>>", "" + characteristic.value.toUByteArray())
            val temp = characteristic.value[0].toInt()
            isTempNotifyContinue = true
            when (characteristic.value[5].toInt()) {
                1 -> {
                    if (!UserModel.isCallFromDevice && !isTempCalled) {
                        isTempCalled = true
                        stopPlayer()
                        UserModel.isCallFromDevice = true

                        Thread.sleep(100)
                        LocalBroadcastManager.getInstance(applicationContext).sendBroadcast(
                            Intent("isFromServiceForTimer11").putExtra(
                                "isFromServiceForTimer",
                                false
                            )
                        )
                    }
                }
                2 -> {

                    isOpenTryAgain = false
                    if (startTemp == 0) {
                        startTemp = temp
                    }

                    val diff = (recipesTemp.toDouble() - startTemp.toDouble()) / 12
                    val diff1 = (temp.toDouble() - startTemp.toDouble()) / diff
                    count = diff1.toInt()

                    if (diff1.toInt() > 11 && temp >= recipesTemp && !isSendForRemoveFromHeat) {
                        isSendForRemoveFromHeat = true
                        Thread.sleep(100)
                        LocalBroadcastManager.getInstance(applicationContext)
                            .sendBroadcast(intentPopup)
                        count = 12
                    }
//                    Log.e("Service ======33333 ", diff1.toString())
                    if (diff1.toInt() == 0 && diff1.toInt() != sameValue) {
                        sameValue = diff1.toInt()
                        count = 0
                        updateImage(count)
//                        Toast.makeText(applicationContext,"Int: "+count+"  roundInt: "+diff1.roundToInt(),Toast.LENGTH_LONG).show()
                    }
                    if (!diff1.toString().startsWith("-") && diff1.toInt() != sameValue) {
                        sameValue = diff1.toInt()
                        updateImage(count)
                        LocalBroadcastManager.getInstance(applicationContext)
                            .sendBroadcast(
                                Intent("segmentCountRegister").putExtra("count", count)
                            )
//                        Toast.makeText(applicationContext,"Int: "+count+"  roundInt: "+diff1.roundToInt(),Toast.LENGTH_LONG).show()
                    }
                }
                3 -> {
                    Thread.sleep(100)
                    if (temp >= recipesTemp && !isSendForRemoveFromHeat) {
                        isSendForRemoveFromHeat = true
                        LocalBroadcastManager.getInstance(applicationContext)
                            .sendBroadcast(intentPopup)
                        count = 12
                        updateImage(count)
                    }
                }
                4 -> {
//                    if (isOpenTryAgain!!){
//                        CommonUtility.setBooleanPreference(
//                            false,
//                            Constant.isShowTemperatureView,
//                            applicationContext
//                        )
//                        isOpenTryAgain = false
//                    }

                    if (!UserModel.isCallFromDevice && !isCalled) {

                        val firstHexTime = convertIntToHex(characteristic.value[1].toInt())
                        val secondHexTime = convertIntToHex(characteristic.value[2].toInt())
                        currentDeviceTime =
                            convertHexToInt(firstHexTime + "" + secondHexTime).toLong()

                        if (recipesTime == recipesTimeInMin) {
                            recipesTime *= 60000
                        }

                        UserModel.isCallFromDevice = true
                        stopPlayer()
                        isCalled = true
                        CommonUtility.setBooleanPreference(
                            false,
                            Constant.isShowTemperatureView,
                            applicationContext
                        )
                        CommonUtility.setStringPreference("0", "count", applicationContext)


                        Thread.sleep(100)
                        LocalBroadcastManager.getInstance(applicationContext).sendBroadcast(
                            Intent("isFromServiceForTimer11").putExtra(
                                "isFromServiceForTimer",
                                true
                            )
                        )

                        Thread.sleep(100)
                        LocalBroadcastManager.getInstance(applicationContext).sendBroadcast(
                            Intent("startSelfCooking")
                        )

                    }
                }
                5 -> {
                    hardwareState = characteristic.value[5].toInt()

                    Thread.sleep(200)
                    if (!isCookingCompleteBroadcastSend) {
                        CommonUtility.setBooleanPreference(
                            false,
                            Constant.cookingIsRunning,
                            applicationContext
                        )
                        if (countDown != null) {
                            countDown?.cancel()
                            countDown = null
                        }
                        isCookingCompleteBroadcastSend = true
                        LocalBroadcastManager.getInstance(applicationContext)
                            .sendBroadcast(intentPopup)
                    }
                }
            }
//            }
        }

        override fun onReadRemoteRssi(gatt: BluetoothGatt, rssi: Int, status: Int) {
            Log.e("Service ====== ", "1333 =====")
        }
    }

    /**
     * Enables or disables notification on a give characteristic.
     *
     * @param characteristic Characteristic to act on.
     * @param enabled        If true, enable notification.  False otherwise.
     */
    fun setCharacteristicNotification(
        enabled: Boolean,
        gatt: BluetoothGatt
    ) {
        if (mBluetoothGatt == null) {
            Log.w("", "BluetoothAdapter not initialized")
            return
        }
        val mCustomService =
            gatt.getService(UUID.fromString("0000FFF0-0000-1000-8000-00805F9B34FB"))

        val charForTimeTemp =
            mCustomService.getCharacteristic(UUID.fromString("0000FFF4-0000-1000-8000-00805F9B34FB"))
        gatt.setCharacteristicNotification(charForTimeTemp, enabled)

        for (des in charForTimeTemp.descriptors) {
            if (null != des) {
                if (0 != (charForTimeTemp.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY)) {
                    des.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    gatt.writeDescriptor(des)
                    break
                }
            }
        }
    }

    /**
     * Connects to the GATT server hosted on the Bluetooth LE device.
     *
     * @param address The device address of the destination device.
     * @return Return true if the connection is initiated successfully. The connection result
     * is reported asynchronously through the
     * `BluetoothGattCallback#onConnectionStateChange(android.bluetooth.BluetoothGatt, int, int)`
     * callback.
     */
    private fun connect(address: String?): Boolean {
        if (address == null) {
            Log.w("", "BluetoothAdapter not initialized or unspecified address.")
            return false
        }

        // Previously connected device.  Try to reconnect.
        if (mBluetoothDeviceAddress != null && address == mBluetoothDeviceAddress
            && mBluetoothGatt != null
        ) {
            Log.d("", "Trying to use an existing mBluetoothGatt for connection.")
            if (mBluetoothGatt!!.connect()) {
                mConnectionState = STATE_CONNECTING
//                mBluetoothGatt!!.discoverServices()
//                UserModel.isHardwareOutOfRange = false
                return true
            } else {
                return false
            }
        }


        val device = mBluetoothAdapter?.getRemoteDevice(address)
        if (device == null) {
            Log.w("", "Device not found.  Unable to connect.")
            return false
        }
        // We want to directly connect to the device, so we are setting the autoConnect
        // parameter to false.
        mBluetoothGatt = device.connectGatt(this, false, mGattCallback)
        Log.d("", "Trying to create a new connection.")
        mBluetoothDeviceAddress = address
        mConnectionState = STATE_CONNECTING
        return true
    }

    fun convertIntToHex(n: Int): String {
        return n.toString(16)
    }

    fun convertHexToInt(n: String): Int {
        return Integer.parseInt(n, 16)
    }

    private fun disconnect() {
        if (mBluetoothGatt == null) {
            Log.w("", "BluetoothAdapter not initialized")
            return
        }
        mBluetoothGatt!!.disconnect()
    }

    private fun close() {
        if (mBluetoothGatt == null) {
            return
        }
        mBluetoothGatt!!.close()
        mBluetoothGatt = null
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate() {
        super.onCreate()
        //Inflate the chat head layout we created
//        Log.e("Service ====== ", "11")
        isOpenTryAgain = false
        mDeviceAddress = CommonUtility.getStringPreference(
            "deviceId",
            applicationContext
        )
        Log.e("Service ====>  ", "onCreate")
        countJobScheduler = 0

//        Handler().postDelayed({
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        connect(mDeviceAddress)
//        }, 200)

        intentPopup = Intent("OpenCookingDialog")
        mChatHeadView = LayoutInflater.from(this).inflate(R.layout.layout_home_button, null)

        mChatHeadView!!.visibility = View.GONE

        LocalBroadcastManager.getInstance(applicationContext).unregisterReceiver(registerReceiver)
        LocalBroadcastManager.getInstance(applicationContext).registerReceiver(
            registerReceiver,
            IntentFilter("AppIsBackground")
        )

        LocalBroadcastManager.getInstance(applicationContext)
            .unregisterReceiver(isFromServiceForTimerRegister)
        LocalBroadcastManager.getInstance(applicationContext).registerReceiver(
            isFromServiceForTimerRegister,
            IntentFilter("isFromServiceForTimer11")
        )


        val LAYOUT_FLAG = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }
        //Add the view to the window.
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            LAYOUT_FLAG,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )


        //Specify the chat head position
        params.gravity =
            Gravity.BOTTOM or Gravity.START        //Initially view will be added to top-left corner
        params.x = 0
        params.y = 0

        //Add the view to the window
        mWindowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        mWindowManager!!.addView(mChatHeadView, params)


        timer1 = mChatHeadView!!.findViewById<ImageView>(R.id.timer_1) as ImageView
        timer2 = mChatHeadView!!.findViewById<ImageView>(R.id.timer_2) as ImageView
        timer3 = mChatHeadView!!.findViewById<ImageView>(R.id.timer_3) as ImageView
        timer4 = mChatHeadView!!.findViewById<ImageView>(R.id.timer_4) as ImageView
        timer5 = mChatHeadView!!.findViewById<ImageView>(R.id.timer_5) as ImageView
        timer6 = mChatHeadView!!.findViewById<ImageView>(R.id.timer_6) as ImageView
        timer7 = mChatHeadView!!.findViewById<ImageView>(R.id.timer_7) as ImageView
        timer8 = mChatHeadView!!.findViewById<ImageView>(R.id.timer_8) as ImageView
        timer9 = mChatHeadView!!.findViewById<ImageView>(R.id.timer_9) as ImageView
        timer10 = mChatHeadView!!.findViewById<ImageView>(R.id.timer_10) as ImageView
        timer11 = mChatHeadView!!.findViewById<ImageView>(R.id.timer_11) as ImageView
        timer12 = mChatHeadView!!.findViewById<ImageView>(R.id.timer_12) as ImageView

        recipesTemp =
            CommonUtility.getStringPreference("recipesTemp", applicationContext).toLong()

        recipesTime =
            CommonUtility.getStringPreference("recipesTime", applicationContext).toLong()

        recipesTimeInMin = recipesTime

        mChatHeadView!!.setOnTouchListener(object : View.OnTouchListener {
            private var lastAction: Int = 0

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        lastAction = event.action
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (lastAction == MotionEvent.ACTION_DOWN) {

                            val isTemp1 = CommonUtility.getBooleanPreference(
                                Constant.isShowTemperatureView,
                                applicationContext
                            )
                            mChatHeadView!!.visibility = View.GONE
                            val intent = Intent(
                                this@DigitalTimerService,
                                DigitalTimerActivity::class.java
                            ).putExtra("isFromService", true)
                                .putExtra("isFromServiceForTimer", !isTemp1)
                            intent.flags =
                                Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                            startActivity(intent)
//                            ActivityCompat.finishAffinity(applicationContext as Activity)
                        }
                        lastAction = event.action
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        return true
                    }
                }
                return false
            }
        })
    }

    private var isFromServiceForTimerRegister = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent!!.getBooleanExtra("isFromServiceForTimer", false)) {
                Thread.sleep(200)
                if (!currentDeviceTime.toString().startsWith("-")) {
                    startTimeForSelfCooking()
                } else {
                    runOnUiThread {
                        Toast.makeText(
                            applicationContext,
                            "Timer Value is in minus!",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            } else {
                isBroadcastIsCall = false
                if (UserModel.mBluetoothGattChar != null) {
//                    Log.e("Service ====== ", "2")
                    if (countDown != null) {
                        countDown?.cancel()
                        countDown = null
                    }
                    if (hardwareState == 5) {
                        doneAlarm(UserModel.mBluetoothGattChar!!)
                    } else {
                        cancelRecipes(UserModel.mBluetoothGattChar!!)
                    }

                    Handler().postDelayed({
                        CommonUtility.setBooleanPreference(
                            false,
                            Constant.cookingIsRunning,
                            applicationContext
                        )

                        try {
                            isTempWrite = true
                            disconnect()
                            close()
                            recipesTime = 0
                            resetValues()
                        } catch (e: Exception) {

                        }

                        UserModel.isHardwareOutOfRange = false
                        UserModel.isCallFromDevice = true
                        UserModel.mBluetoothGattChar = null

                        stopSelf()
                        stopService(Intent(applicationContext, DigitalTimerService::class.java))
                        startActivity(
                            Intent(
                                applicationContext,
                                MainActivity::class.java
                            ).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                        )
                        LocalBroadcastManager.getInstance(applicationContext)
                            .unregisterReceiver(registerReceiver)
                    }, 500)
                } else {
                    CommonUtility.setBooleanPreference(
                        false,
                        Constant.cookingIsRunning,
                        applicationContext
                    )

                    try {
                        isTempWrite = true
                        disconnect()
                        close()
                        recipesTime = 0
                        resetValues()
                    } catch (e: Exception) {

                    }

                    UserModel.isHardwareOutOfRange = false
                    UserModel.isCallFromDevice = true
                    UserModel.mBluetoothGattChar = null

                    stopSelf()
                    stopService(Intent(applicationContext, DigitalTimerService::class.java))
                    startActivity(
                        Intent(
                            applicationContext,
                            MainActivity::class.java
                        ).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                    )
                    LocalBroadcastManager.getInstance(applicationContext)
                        .unregisterReceiver(registerReceiver)
                }

            }
        }
    }

    private fun startTimeForSelfCooking() {
        if (!isBroadcastIsCall && countDown == null) {
            isBroadcastIsCall = true
            isNotifyData = true
            CommonUtility.setBooleanPreference(
                true,
                Constant.cookingIsRunning,
                applicationContext
            )
            //                    Log.e("Service ====== ", "1")
            CommonUtility.setStringPreference(
                CommonUtility.getUpdateTime(recipesTimeInMin.toInt()),
                "clockTime",
                applicationContext
            )
            confirmAlarm(UserModel.mBluetoothGattChar!!)
            CommonUtility.setBooleanPreference(
                false,
                Constant.isShowTemperatureView,
                applicationContext
            )
            if (recipesTime < 60000 && recipesTime == recipesTimeInMin) {
                recipesTime *= 60000
                currentDeviceTime = recipesTime
            }

            hideAllImages()
            if (countDown != null) {
                countDown?.cancel()
            }

            timerCountDown()
        }
    }

    var sameValueForTimer: Int = -1
    private fun timerCountDown() {
        Log.e("Service ====== ", "4")
        if (countDown != null) {
            countDown?.cancel()
            countDown = null
        }
        isCalled = true
        countDown = object : CountDownTimer(currentDeviceTime.toLong(), 1000) {
            override fun onTick(millisUntilFinished: Long) {
                CommonUtility.setStringPreference(
                    millisUntilFinished.toString(),
                    "timer",
                    applicationContext
                )
                var minutes = (millisUntilFinished / 1000 / 60).toString()
                var seconds = (millisUntilFinished / 1000 % 60).toString()
                if (minutes.length < 2) {
                    minutes = "0$minutes"
                }
                if (seconds.length < 2) {
                    seconds = "0$seconds"
                }
                val timeStr = "$minutes:$seconds"

                LocalBroadcastManager.getInstance(applicationContext)
                    .sendBroadcast(Intent("countDown").putExtra("countTime", timeStr))


                val diffTime = (recipesTime.toDouble() - 0) / 12
                val diff1 = (millisUntilFinished.toDouble() - 0) / diffTime
                var countTime = 12 - diff1.roundToInt()
                if (countTime <= 0) {
                    countTime = 0
                }

                if (!countTime.toString().startsWith("-") && countTime != sameValueForTimer) {
                    CommonUtility.setStringPreference(
                        countTime.toString(),
                        "count",
                        applicationContext
                    )
//                    Log.d(TAG, "count == $countTime")
                    sameValueForTimer = countTime
                    countTimer = countTime
                    updateImage(countTime)
                    LocalBroadcastManager.getInstance(applicationContext)
                        .sendBroadcast(
                            Intent("segmentCountRegister").putExtra("count", countTime)
                        )
                }
                if (countTime >= 12 && countDown != null && timeStr.equals(
                        "00:00",
                        true
                    )
                ) {
//                    Thread.sleep(200)
//                    Handler().postDelayed({
                    Thread.sleep(100)
                    cookingComplete()
//                    }, 200)
//                    cookingComplete()
                }
            }

            override fun onFinish() {
                if (!isTempNotifyContinue) {
                    hardwareState = 5
                }
            }
        }.start()
    }

    private fun cookingComplete() {
        if (hardwareState == 5 && countDown != null) {
            CommonUtility.setBooleanPreference(
                false,
                Constant.cookingIsRunning,
                applicationContext
            )
            countDown?.cancel()
            countDown = null
            if (!isCookingCompleteBroadcastSend) {
                isCookingCompleteBroadcastSend = true
                LocalBroadcastManager.getInstance(applicationContext)
                    .sendBroadcast(intentPopup)
            }
        } else {
//            Thread.sleep(500)
//            Handler().postDelayed({
//                cookingComplete()
//            }, 1000)
        }

    }

    private fun updateImage(count: Int) {
//        Log.e("Service ====== ", "7")

        if (count == 0) {
            CommonUtility.setStringPreference(count.toString(), "count", applicationContext)
            LocalBroadcastManager.getInstance(applicationContext)
                .sendBroadcast(
                    Intent("segmentCountRegister").putExtra("count", count)
                )
            timer1!!.alpha = 0.1f
            timer2!!.alpha = 0.1f
            timer3!!.alpha = 0.1f
            timer4!!.alpha = 0.1f
            timer5!!.alpha = 0.1f
            timer6!!.alpha = 0.1f
            timer7!!.alpha = 0.1f
            timer8!!.alpha = 0.1f
            timer9!!.alpha = 0.1f
            timer10!!.alpha = 0.1f
            timer11!!.alpha = 0.1f
            timer12!!.alpha = 0.1f

        }
        if (count == 1) {
//            CommonUtility.setStringPreference(count.toString(), "count", applicationContext)
//            LocalBroadcastManager.getInstance(applicationContext)
//                .sendBroadcast(
//                    Intent("segmentCountRegister").putExtra("count", count)
//                )
            timer1!!.alpha = 1f
            timer2!!.alpha = 0.1f
            timer3!!.alpha = 0.1f
            timer4!!.alpha = 0.1f
            timer5!!.alpha = 0.1f
            timer6!!.alpha = 0.1f
            timer7!!.alpha = 0.1f
            timer8!!.alpha = 0.1f
            timer9!!.alpha = 0.1f
            timer10!!.alpha = 0.1f
            timer11!!.alpha = 0.1f
            timer12!!.alpha = 0.1f

        }
        if (count == 2) {
            timer1!!.alpha = 1f
            timer2!!.alpha = 1f
            timer3!!.alpha = 0.1f
            timer4!!.alpha = 0.1f
            timer5!!.alpha = 0.1f
            timer6!!.alpha = 0.1f
            timer7!!.alpha = 0.1f
            timer8!!.alpha = 0.1f
            timer9!!.alpha = 0.1f
            timer10!!.alpha = 0.1f
            timer11!!.alpha = 0.1f
            timer12!!.alpha = 0.1f

        }
        if (count == 3) {
            timer1!!.alpha = 1f
            timer2!!.alpha = 1f
            timer3!!.alpha = 1f
            timer4!!.alpha = 0.1f
            timer5!!.alpha = 0.1f
            timer6!!.alpha = 0.1f
            timer7!!.alpha = 0.1f
            timer8!!.alpha = 0.1f
            timer9!!.alpha = 0.1f
            timer10!!.alpha = 0.1f
            timer11!!.alpha = 0.1f
            timer12!!.alpha = 0.1f

        }
        if (count == 4) {
            timer1!!.alpha = 1f
            timer2!!.alpha = 1f
            timer3!!.alpha = 1f
            timer4!!.alpha = 1f
            timer5!!.alpha = 0.1f
            timer6!!.alpha = 0.1f
            timer7!!.alpha = 0.1f
            timer8!!.alpha = 0.1f
            timer9!!.alpha = 0.1f
            timer10!!.alpha = 0.1f
            timer11!!.alpha = 0.1f
            timer12!!.alpha = 0.1f

        }
        if (count == 5) {
            timer1!!.alpha = 1f
            timer2!!.alpha = 1f
            timer3!!.alpha = 1f
            timer4!!.alpha = 1f
            timer5!!.alpha = 1f
            timer6!!.alpha = 0.1f
            timer7!!.alpha = 0.1f
            timer8!!.alpha = 0.1f
            timer9!!.alpha = 0.1f
            timer10!!.alpha = 0.1f
            timer11!!.alpha = 0.1f
            timer12!!.alpha = 0.1f

        }
        if (count == 6) {
            timer1!!.alpha = 1f
            timer2!!.alpha = 1f
            timer3!!.alpha = 1f
            timer4!!.alpha = 1f
            timer5!!.alpha = 1f
            timer6!!.alpha = 1f
            timer7!!.alpha = 0.1f
            timer8!!.alpha = 0.1f
            timer9!!.alpha = 0.1f
            timer10!!.alpha = 0.1f
            timer11!!.alpha = 0.1f
            timer12!!.alpha = 0.1f

        }
        if (count == 7) {
            timer1!!.alpha = 1f
            timer2!!.alpha = 1f
            timer3!!.alpha = 1f
            timer4!!.alpha = 1f
            timer5!!.alpha = 1f
            timer6!!.alpha = 1f
            timer7!!.alpha = 1f
            timer8!!.alpha = 0.1f
            timer9!!.alpha = 0.1f
            timer10!!.alpha = 0.1f
            timer11!!.alpha = 0.1f
            timer12!!.alpha = 0.1f

        }
        if (count == 8) {
            timer1!!.alpha = 1f
            timer2!!.alpha = 1f
            timer3!!.alpha = 1f
            timer4!!.alpha = 1f
            timer5!!.alpha = 1f
            timer6!!.alpha = 1f
            timer7!!.alpha = 1f
            timer8!!.alpha = 1f
            timer9!!.alpha = 0.1f
            timer10!!.alpha = 0.1f
            timer11!!.alpha = 0.1f
            timer12!!.alpha = 0.1f

        }
        if (count == 9) {
            timer1!!.alpha = 1f
            timer2!!.alpha = 1f
            timer3!!.alpha = 1f
            timer4!!.alpha = 1f
            timer5!!.alpha = 1f
            timer6!!.alpha = 1f
            timer7!!.alpha = 1f
            timer8!!.alpha = 1f
            timer9!!.alpha = 1f
            timer10!!.alpha = 0.1f
            timer11!!.alpha = 0.1f
            timer12!!.alpha = 0.1f

        }
        if (count == 10) {
            timer1!!.alpha = 1f
            timer2!!.alpha = 1f
            timer3!!.alpha = 1f
            timer4!!.alpha = 1f
            timer5!!.alpha = 1f
            timer6!!.alpha = 1f
            timer7!!.alpha = 1f
            timer8!!.alpha = 1f
            timer9!!.alpha = 1f
            timer10!!.alpha = 1f
            timer11!!.alpha = 0.1f
            timer12!!.alpha = 0.1f
        }
        if (count == 11) {
            timer1!!.alpha = 1f
            timer2!!.alpha = 1f
            timer3!!.alpha = 1f
            timer4!!.alpha = 1f
            timer5!!.alpha = 1f
            timer6!!.alpha = 1f
            timer7!!.alpha = 1f
            timer8!!.alpha = 1f
            timer9!!.alpha = 1f
            timer10!!.alpha = 1f
            timer11!!.alpha = 1f
            timer12!!.alpha = 0.1f

        }
        if (count == 12) {
            timer1!!.alpha = 1f
            timer2!!.alpha = 1f
            timer3!!.alpha = 1f
            timer4!!.alpha = 1f
            timer5!!.alpha = 1f
            timer6!!.alpha = 1f
            timer7!!.alpha = 1f
            timer8!!.alpha = 1f
            timer9!!.alpha = 1f
            timer10!!.alpha = 1f
            timer11!!.alpha = 1f
            timer12!!.alpha = 1f
        }
        CommonUtility.setStringPreference(count.toString(), "count", applicationContext)
    }

    private fun hideAllImages() {
        timer1!!.alpha = 0.1f
        timer2!!.alpha = 0f
        timer3!!.alpha = 0f
        timer4!!.alpha = 0f
        timer5!!.alpha = 0f
        timer6!!.alpha = 0f
        timer7!!.alpha = 0f
        timer8!!.alpha = 0f
        timer9!!.alpha = 0f
        timer10!!.alpha = 0f
        timer11!!.alpha = 0f
        timer12!!.alpha = 0f
    }

    override fun onDestroy() {
        super.onDestroy()
        stopSelf()
        Log.e("Service ====== ", "9")
        isTempNotifyContinue = false
        if (mChatHeadView != null) {
            mWindowManager!!.removeView(mChatHeadView)
        }
        if (!CommonUtility.getBooleanPreference(Constant.cookingIsRunning, applicationContext)) {
            if (countDown != null) {
                countDown?.cancel()
                countDown = null
            }
        }
        if (CommonUtility.getBooleanPreference(
                Constant.cookingIsRunning,
                applicationContext
            ) && !isOpenTryAgain!!
        ) {
            isOpenTryAgain = true
            CommonUtility.sendNotificationOutOfTheRange(
                "Zega",
                "Your Device is out of range from Zega",
                applicationContext
            )
            openTryAgain()
        }
        LocalBroadcastManager.getInstance(applicationContext).unregisterReceiver(registerReceiver)
        isTempWrite = true
        disconnect()
        close()
        recipesTime = 0
        resetValues()

    }

    private fun resetValues() {
        STATE_DISCONNECTED = 0
        STATE_CONNECTING = 1
        STATE_CONNECTED = 2
        timerCount = null
        count = 0
        mBluetoothGatt = null
        startTemp = 0
        isSendForRemoveFromHeat = false
        sameValue = -1
        countTimer = 0
        sameValueForTimer = -1
        isSendForCoockingComplete = false

    }

    private var registerReceiver = object : BroadcastReceiver() {
        @RequiresApi(Build.VERSION_CODES.O)
        override fun onReceive(context: Context?, intent: Intent?) {
            Log.e("Service ====== ", "10 ===" + intent!!.getBooleanExtra("isBackground", false))
            if (intent.getBooleanExtra("isBackground", false)) {
                mChatHeadView!!.visibility = View.GONE
            } else {
                mChatHeadView!!.visibility = View.VISIBLE
            }
        }
    }

    fun openTryAgain() {
        isTempWrite = false
        LocalBroadcastManager.getInstance(applicationContext).sendBroadcast(Intent("TryAgain"))
    }

    private fun stopPlayer() {
        LocalBroadcastManager.getInstance(applicationContext).sendBroadcast(Intent("DismissDialog"))
        LocalBroadcastManager.getInstance(applicationContext).sendBroadcast(Intent("StopPlayer"))
    }

    companion object {

//        lateinit var instance: HomeButtonService
//
//        fun terminateService() {
//            if (instance != null) {
//                instance.stopSelf()
//            }
//        }

        private var STATE_DISCONNECTED = 0
        private var STATE_CONNECTING = 1
        private var STATE_CONNECTED = 2
        private var timerCount: Long? = null
        private var count = 0
        private var countTimer = 0
        private var mBluetoothGatt: BluetoothGatt? = null
        private var startTemp: Int = 0
        private var startTime: Int = 0
        private var sameValueForTime: Int = -1
        private var isSendForRemoveFromHeat: Boolean = false
        private var isSendForCoockingComplete: Boolean = false

        var sameValue: Int? = -1

        fun confirmAlarm(mWriteCharacteristic: BluetoothGattCharacteristic) {
//        val mWriteCharacteristic = bluetoothCharacteristic(mBluetoothGatt)
            val byte = ByteArray(5)
            byte[0] = 0x04
            mWriteCharacteristic.value = byte
            if (mBluetoothGatt != null) {
                mBluetoothGatt!!.writeCharacteristic(mWriteCharacteristic)
            }
        }

        fun cancelRecipes(mWriteCharacteristic: BluetoothGattCharacteristic) {
//        val mWriteCharacteristic = bluetoothCharacteristic(mBluetoothGatt)
            val byte = ByteArray(5)
            byte[0] = 0x05
            mWriteCharacteristic.value = byte
            if (mBluetoothGatt != null) {
                mBluetoothGatt!!.writeCharacteristic(mWriteCharacteristic)
            }

        }

        fun doneAlarm(mWriteCharacteristic: BluetoothGattCharacteristic) {
            val byte = ByteArray(5)
            byte[0] = 0x03
            mWriteCharacteristic.value = byte
            if (mBluetoothGatt != null) {
                mBluetoothGatt!!.writeCharacteristic(mWriteCharacteristic)
            }
        }

        fun readFireWare(mWriteCharacteristic: BluetoothGattCharacteristic) {
//        val mWriteCharacteristic = bluetoothCharacteristic(mBluetoothGatt)
            val byte = ByteArray(6)
            byte[0] = 0x08
            byte[1] = 0x23
            mWriteCharacteristic.value = byte
        }
    }

}
