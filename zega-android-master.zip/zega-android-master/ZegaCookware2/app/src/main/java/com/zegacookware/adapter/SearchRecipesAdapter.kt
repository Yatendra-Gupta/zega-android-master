package com.zegacookware.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.zegacookware.R
import com.zegacookware.interfaces.SetOnItemClickListener
import com.zegacookware.model.recipes.RecipesResult
import kotlinx.android.synthetic.main.item_recipes_title.view.*

class SearchRecipesAdapter(
    var mContext: Context,
    var categoryList: List<RecipesResult>,
    var setOnItemClickListener: SetOnItemClickListener
) :
    RecyclerView.Adapter<SearchRecipesAdapter.RecipesViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecipesViewHolder {
        val view =
            LayoutInflater.from(mContext).inflate(R.layout.item_recipes_title, parent, false)
        return RecipesViewHolder(view)
    }

    override fun getItemCount(): Int {
        return categoryList.size
    }

    override fun onBindViewHolder(holder: RecipesViewHolder, position: Int) {
        holder.itemView.tvRecipesTitle.text = categoryList[position].recepieTitle
        holder.itemView.setOnClickListener { setOnItemClickListener.onItemClick(position) }
        if (position==categoryList.size-1){
            holder.itemView.divider.visibility=View.GONE
        }else{
            holder.itemView.divider.visibility=View.VISIBLE
        }
    }

    class RecipesViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    }
}