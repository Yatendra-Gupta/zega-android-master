package com.zegacookware.widget;

import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Transformation;

public class ResizeAnimation extends Animation {
    final int targetHeight;
    View view;
    int startHeight;
    private boolean isExisting;

    public ResizeAnimation(View view, int targetHeight, int startHeight,boolean isExisting) {
        this.view = view;
        this.targetHeight = targetHeight;
        this.startHeight = startHeight;
        this.isExisting=isExisting;
    }

    @Override
    protected void applyTransformation(float interpolatedTime, Transformation t) {

        int newHeight = (int) (startHeight + targetHeight * interpolatedTime);
        //to support decent animation, change new heigt as Nico S. recommended in comments
//        int newHeight = (int) (startHeight+(targetHeight - startHeight) * interpolatedTime);
        if (isExisting){

        }
        view.getLayoutParams().height = newHeight;
        view.requestLayout();
    }

    @Override
    public void initialize(int width, int height, int parentWidth, int parentHeight) {
        super.initialize(width, height, parentWidth, parentHeight);
    }

    @Override
    public boolean willChangeBounds() {
        return true;
    }
}
