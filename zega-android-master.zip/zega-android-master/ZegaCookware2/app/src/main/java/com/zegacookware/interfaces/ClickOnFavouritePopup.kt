package com.zegacookware.interfaces

interface ClickOnFavouritePopup {
    fun onItemClick(position: Int,cusineType:String)
}