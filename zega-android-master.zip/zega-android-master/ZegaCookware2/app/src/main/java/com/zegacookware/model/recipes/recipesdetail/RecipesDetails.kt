package com.zegacookware.model.recipes.recipesdetail

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class RecipesDetails {

    @SerializedName("recepie_result")
    @Expose
    var recepieResult: RecepieDetailsResult? = null
    @SerializedName("ingriendient_result")
    @Expose
    var ingriendientResult: ArrayList<IngriendientResult>? = null
    @SerializedName("favourite_result")
    @Expose
    var favouriteResult: List<Favourite>? = null
    @SerializedName("status")
    @Expose
    var status: Int? = null
}

class Favourite {
    @SerializedName("favourite_status")
    @Expose
    var favouriteStatus: String = ""
}