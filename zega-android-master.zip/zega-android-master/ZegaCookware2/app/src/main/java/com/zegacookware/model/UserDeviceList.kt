package com.zegacookware.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class UserDeviceList {
    @SerializedName("user_device_id")
    @Expose
    var userDeviceId: Int? = null
    @SerializedName("device_id")
    @Expose
    var deviceId: String? = null
    @SerializedName("mac_id")
    @Expose
    var macId: String? = null
    @SerializedName("user_id")
    @Expose
    var userId: Int? = null
    @SerializedName("device_name")
    @Expose
    var deviceName: String? = null
    @SerializedName("created_at")
    @Expose
    var createdAt: String? = null

}
