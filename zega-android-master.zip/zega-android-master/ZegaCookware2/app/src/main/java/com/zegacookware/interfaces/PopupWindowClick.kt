package com.zegacookware.interfaces

interface PopupWindowClick {
    fun onButton1Click()
    fun onButton2Click()
}