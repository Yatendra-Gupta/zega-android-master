package com.zegacookware.util

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.zegacookware.R


abstract class FullBottomSheetFragment : BottomSheetDialogFragment() {

    private var errorDialog: AlertDialog? = null
    private var mBehavior: BottomSheetBehavior<*>? = null

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = super.onCreateDialog(savedInstanceState) as BottomSheetDialog

        val contentView = View.inflate(context, R.layout.full_bottom_sheet, null)
        val frame = contentView.findViewById<FrameLayout>(R.id.btdContent)
        val childView = onCreateDialogView(savedInstanceState, frame)
        frame.addView(childView)

        dialog.setContentView(contentView)
        dialog.setCancelable(false)
        mBehavior = BottomSheetBehavior.from(contentView.parent as View)
        mBehavior?.isHideable=false
        return dialog
    }

    protected abstract fun onCreateDialogView(savedInstanceState: Bundle?, parent: ViewGroup): View
    //protected abstract fun dismissDialog()

    override fun onStart() {
        super.onStart()
        mBehavior!!.state = BottomSheetBehavior.STATE_EXPANDED
    }

    @SuppressLint("RestrictedApi")
    override fun setupDialog(dialog: Dialog, style: Int) {
        super.setupDialog(dialog, style)

        val marginTop = resources.getDimension(R.dimen.bottomsheet_margin_top).toInt()
        val dialogHeight = CommonUtility.getDisplayContentHeight(activity!!) - marginTop

        val bottomSheet = dialog.window!!.findViewById<FrameLayout>(R.id.design_bottom_sheet)
//        bottomSheet.setBackgroundResource(R.drawable.shape_bottomsheet_background_white)
//        bottomSheet.minimumHeight = dialogHeight
        val params =
            bottomSheet.layoutParams as androidx.coordinatorlayout.widget.CoordinatorLayout.LayoutParams
        params.height = dialogHeight
        dialog.setCancelable(false)
        bottomSheet.layoutParams = params

        mBehavior!!.peekHeight = dialogHeight
    }
    override fun setCancelable(cancelable: Boolean) {
        val dialog = dialog
        val touchOutsideView =
            dialog!!.window!!.decorView.findViewById<View>(com.google.android.material.R.id.touch_outside)
        val bottomSheetView =
            dialog.window!!.decorView.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)

        if (cancelable) {
            touchOutsideView.setOnClickListener(View.OnClickListener {
                if (dialog.isShowing) {
                    dialog.cancel()
                }
            })
            BottomSheetBehavior.from<View>(bottomSheetView).setHideable(true)
        } else {
            touchOutsideView.setOnClickListener(null)
            BottomSheetBehavior.from<View>(bottomSheetView).setHideable(false)
        }
    }

}