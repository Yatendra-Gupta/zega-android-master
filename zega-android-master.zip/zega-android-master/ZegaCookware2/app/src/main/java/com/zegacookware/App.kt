package com.zegacookware


import android.content.pm.PackageManager
import android.util.Base64
import android.util.Log
import androidx.lifecycle.ProcessLifecycleOwner

import androidx.multidex.MultiDexApplication

import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import com.zegacookware.service.ForegroundBackgroundListener

import java.security.MessageDigest
import java.security.NoSuchAlgorithmException


class App : MultiDexApplication() {

    override fun onCreate() {
        super.onCreate()

        FirebaseApp.initializeApp(this)
        FirebaseMessaging.getInstance().isAutoInitEnabled = true
       // printHashKey()
        ProcessLifecycleOwner.get()
            .lifecycle
            .addObserver(
                ForegroundBackgroundListener(applicationContext)
                    .also {  })
    }


    fun printHashKey() {
        try {
            val info = packageManager.getPackageInfo(
                "com.zegacookware",
                PackageManager.GET_SIGNATURES
            )
            for (signature in info.signatures) {
                val md = MessageDigest.getInstance("SHA")
                md.update(signature.toByteArray())
                Log.e("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT))
            }
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
        } catch (e: NoSuchAlgorithmException) {
            e.printStackTrace()
        }

    }
}
