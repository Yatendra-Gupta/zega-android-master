package com.zegacookware.service

import android.content.Context
import android.content.Intent
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.OnLifecycleEvent
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.zegacookware.network.Constant
import com.zegacookware.util.CommonUtility

class ForegroundBackgroundListener(var mContext: Context) : LifecycleObserver {


    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    fun startSomething() {
//        Log.v("ProcessLog", "APP IS ON FOREGROUND")
        if (CommonUtility.getBooleanPreference(Constant.cookingIsRunning, mContext)){
            LocalBroadcastManager.getInstance(mContext).sendBroadcast(Intent("AppIsBackground").putExtra("isBackground",false))
        }
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_STOP)
    fun stopSomething() {
        if (CommonUtility.getBooleanPreference(Constant.cookingIsRunning, mContext)){
            LocalBroadcastManager.getInstance(mContext).sendBroadcast(Intent("AppIsBackground").putExtra("isBackground",true))
        }
//        Log.v("ProcessLog", "APP IS IN BACKGROUND")
    }
//    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
//    fun destroyTheApplication(){
//        CommonUtility.setBooleanPreference(false, "cookingIsRunning", mContext)
//    }
}