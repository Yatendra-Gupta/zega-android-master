package com.zegacookware.activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.trading212.diverserecycleradapter.layoutmanager.DiverseLinearLayoutManager
import com.zegacookware.R
import com.zegacookware.activity.setting.WebViewActivity
import com.zegacookware.model.faq.FAQs
import com.zegacookware.model.faq.FaqDatum
import com.zegacookware.model.faq.FaqResult
import com.zegacookware.model.user.UserResult
import com.zegacookware.network.Constant
import com.zegacookware.util.CommonUtility
import com.zegacookware.widget.item.ItemType
import com.zegacookware.widget.stickyheader.StickyHeader
import com.zegacookware.widget.stickyheader.StickyHeaderDecoration
import kotlinx.android.synthetic.main.activity_faq.*
import kotlinx.android.synthetic.main.item_faq_title.view.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FAQActivity : BaseActivity() {

    private lateinit var adapter: FaqRecyclerAdapter
    private lateinit var userData: UserResult
    private lateinit var mContext: Context
    private val faqList: ArrayList<FaqResult> = ArrayList()
    private val items: ArrayList<RecyclerItem> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_faq)
        mContext = this
        userData = CommonUtility.getUserData(Constant.userInfo, this@FAQActivity)

        rvFaq.layoutManager = DiverseLinearLayoutManager(this)
        rvFaq.setHasFixedSize(true)
        adapter = FaqRecyclerAdapter(mContext, false)
        getAllFaqList()
        ivBack.setOnClickListener { finish() }

    }


    private fun setStickyLis(isShowGrid: Boolean) {
        items.clear()
        for (i in 0 until faqList.size) {
            items.add(
                RecyclerItem(
                    title = faqList[i].faqCategoryName!!,
                    isSticky = true
                )
            )
            val gamesRecyclerItems =
                faqList[i].faqData!!.map { RecyclerItem("", false, it) }
            items.addAll(gamesRecyclerItems)
        }

        adapter.items = items
        adapter.isGrid = isShowGrid
        rvFaq.adapter = adapter
        rvFaq.addItemDecoration(StickyHeaderDecoration())
        adapter.notifyDataSetChanged()
    }

    data class RecyclerItem(
        val title: String,
        val isSticky: Boolean = false,
        val faqData: FaqDatum? = null
    )

    class FaqRecyclerAdapter(val mContext: Context, private val isShowGrid: Boolean) :
        RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        var isGrid: Boolean = false
        var items: List<RecyclerItem> = listOf()

        override fun getItemCount(): Int = items.size

        override fun getItemViewType(position: Int) =
            if (items[position].isSticky) {
                STICKY_ITEM_TYPE
            } else {
                TEXT_ITEM_TYPE
            }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val isStickyItem = viewType == STICKY_ITEM_TYPE

            val layoutInflater = LayoutInflater.from(parent.context)

            return if (isStickyItem) {
                StickyViewHolder(layoutInflater.inflate(R.layout.item_sticky_text, parent, false))
            } else {
                TextViewHolder(layoutInflater.inflate(R.layout.item_faq_title, parent, false))
            }
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            if (holder is TextViewHolder) {

                if (items[position].isSticky) {
                    holder.textView.text = items[position].title
                    holder.itemView.isClickable = false
                } else {

                    holder.itemView.isClickable = true
                    holder.itemView.tvRecipesTitle.text = items[position].faqData?.faqTitle

                    if (position == items.size - 1) {
                        holder.itemView.divider.visibility = View.GONE
                    }
                    holder.itemView.setOnClickListener {
                        mContext.startActivity(
                            Intent(mContext, WebViewActivity::class.java)
                                .putExtra("header", "FAQs")
                                .putExtra(
                                    "url",
                                    Constant.faqBaseUrl + items[position].faqData!!.faqId
                                )
                        )
                    }
                    if (position != items.size - 1 && items[position + 1].isSticky) {
                        holder.itemView.divider.visibility = View.GONE
                    }
                }

            }
        }

        inner class StickyViewHolder(itemView: View) : TextViewHolder(itemView), StickyHeader {
            override val stickyId: String
                get() = items[adapterPosition].title
        }

        open inner class TextViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val textView: TextView = itemView.findViewById(R.id.tvRecipesTitle)
        }

        companion object {
            val STICKY_ITEM_TYPE = ItemType.STICKY.ordinal
            val TEXT_ITEM_TYPE = ItemType.SIMPLE_TEXT.ordinal
        }
    }


    private fun getAllFaqList() {
        Constant.service.getFaqList().apply {
            enqueue(object : Callback<FAQs> {
                override fun onFailure(call: Call<FAQs>, t: Throwable) {
                }

                override fun onResponse(
                    call: Call<FAQs>,
                    response: Response<FAQs>
                ) {
                    if (response.isSuccessful && response.body()?.status == 1) {
                        faqList += response.body()?.faqResult!!
                        setStickyLis(false)
                    }
                }

            })
        }
    }
}
