package com.zegacookware.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.zegacookware.interfaces.ClickOnFavouritePopup
import com.zegacookware.R
import com.zegacookware.model.recipes.GetFoodTypeData
import kotlinx.android.synthetic.main.item_selected_favorite.view.*

class FavoriteSelectedAdapter(
    var mContext: Context,
    var categoryList: List<GetFoodTypeData>,
    var clickOnFavouritePopup: ClickOnFavouritePopup
) :
    RecyclerView.Adapter<FavoriteSelectedAdapter.RecipesViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecipesViewHolder {
        val view =
            LayoutInflater.from(mContext).inflate(R.layout.item_selected_favorite, parent, false)
        return RecipesViewHolder(view)
    }

    override fun getItemCount(): Int {
        return categoryList.size
    }

    override fun onBindViewHolder(holder: RecipesViewHolder, position: Int) {
        holder.itemView.tvFavoriteSelect.text = categoryList[position].food_type_name
        holder.itemView.setOnClickListener { clickOnFavouritePopup.onItemClick(position,categoryList[position].food_type_name!!) }
    }

    class RecipesViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    }
}