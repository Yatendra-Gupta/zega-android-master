package com.zegacookware.model.recipes

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class GetRecipesByCategoryId {
    @SerializedName("recepie_result")
    @Expose
    var recipesTitle: List<RecepieTitle>? = null
    @SerializedName("status")
    @Expose
    var status: Int? = null
}