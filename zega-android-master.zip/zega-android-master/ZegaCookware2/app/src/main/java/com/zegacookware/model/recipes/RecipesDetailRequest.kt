package com.zegacookware.model.recipes

data class RecipesDetailRequest(
    var recepie_id: String = "",
    var recepie_keyword: String = "",
    var category_id: String = "",
    var user_id: String = "",
    var favourite_status:String="",
    var enable_status:String=""
)

