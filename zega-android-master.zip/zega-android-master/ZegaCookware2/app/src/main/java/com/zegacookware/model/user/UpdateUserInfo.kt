package com.zegacookware.model.user

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class UpdateUserInfo {
    @SerializedName("profile_result")
    @Expose
    var userResult: UserResult? = null
    @SerializedName("status")
    @Expose
    var status: Int? = null
    @SerializedName("msg")
    @Expose
    var msg: String? = null
}
