package com.zegacookware.model.recipes.recipesdetail

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class FavouriteResponse {
    @SerializedName("msg")
    @Expose
    var msg: String = ""
    @SerializedName("status")
    @Expose
    var status: Int? = null
}
