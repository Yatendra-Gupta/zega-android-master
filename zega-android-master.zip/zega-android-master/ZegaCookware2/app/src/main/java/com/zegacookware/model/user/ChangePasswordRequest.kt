package com.zegacookware.model.user

data class ChangePasswordRequest (
    var user_id:String="",
    var old_pass:String="",
    var new_pass:String="",
    var first_name:String="",
    var last_name:String=""

)
