package com.zegacookware.util

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.zegacookware.R
import kotlinx.android.synthetic.main.layout_home_button.view.*

class ServiceListFragment : FullBottomSheetFragment() {

    private var selectedService: String = ""
    private var listener: ((name: String) -> Unit)? = null

    companion object {
        const val SERVICES_ADMIN = "SERVICES_ADMIN"
    }

    fun newInstance(): ServiceListFragment {
        return ServiceListFragment()
    }

    override fun onCreateDialogView(savedInstanceState: Bundle?, parent: ViewGroup): View {
        val view = LayoutInflater.from(context).inflate(R.layout.layout_home_button, parent, false)

        view.lytTimerImage.setOnClickListener {
//            listener?.invoke(selectedService)
//            dismissDialog()
        }

        return view
    }

    fun withListener(listener: ((name: String) -> Unit)?): ServiceListFragment {
        this.listener = listener
        return this
    }
//    override fun dismissDialog() {
//        dismiss()
//    }
}