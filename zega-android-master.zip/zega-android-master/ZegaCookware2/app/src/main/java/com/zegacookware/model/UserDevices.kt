package com.zegacookware.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class UserDevices {

    @SerializedName("user_device_list")
    @Expose
    var userDeviceList: List<UserDeviceList>? = null
    @SerializedName("status")
    @Expose
    var status: Int? = null

}
