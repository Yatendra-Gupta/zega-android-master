package com.zegacookware.widget.timer_progress;

/**
 * @author Adrián García Lomas
 */
public interface InternalCirclePainter extends Painter {
}
