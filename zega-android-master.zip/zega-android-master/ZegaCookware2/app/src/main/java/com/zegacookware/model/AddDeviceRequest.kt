package com.zegacookware.model

data class AddDeviceRequest(
    var user_id: String = "",
    var device_id: String = "",
    var user_device_id: String = "",
    var device_name: String = "",
    var mac_id: String = ""
)