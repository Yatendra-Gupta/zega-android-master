package com.zegacookware.activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.view.WindowManager
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.zegacookware.R
import com.zegacookware.activity.setting.SettingActivity
import com.zegacookware.model.AddDeviceRequest
import com.zegacookware.model.UserDevices
import com.zegacookware.model.user.UserModel
import com.zegacookware.model.user.UserResult
import com.zegacookware.network.Constant
import com.zegacookware.util.CommonUtility
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class MainActivity : BaseActivity(), View.OnClickListener {
    private lateinit var userData: UserResult
    private lateinit var mContext: Context
    private var isFromTimer: Boolean? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        overridePendingTransition(0, 0)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        mContext = this
        isFromTimer = intent.getBooleanExtra("isFromTimer", false)
        btnRecipes.setOnClickListener(this)
        btnFAQs.setOnClickListener(this)
        btnQuickCook.setOnClickListener(this)
        btnSetting.setOnClickListener(this)

        userData = CommonUtility.getUserData(Constant.userInfo, this@MainActivity)
        tvUserName.text = "${userData.name}'S ZEGA"
        getDevices()
    }

    private fun connectDevice() {
        if (CommonUtility.getBooleanPreference(
                "isDeviceAvailable",
                mContext
            ) && CommonUtility.getBooleanPreference(
                Constant.isDigital, mContext
            )
        ) {
            if (!CommonUtility.getBooleanPreference(
                    Constant.cookingIsRunning,
                    mContext
                )
            ) {
//                UserModel.isHardwareOutOfRange = false
                connectHardware()
            }

        }
    }


    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btnRecipes -> {
                startActivity(Intent(this@MainActivity, RecipesActivity::class.java))
            }
            R.id.btnQuickCook -> {
                startActivity(Intent(this@MainActivity, QuickCookActivity::class.java))
            }
            R.id.btnFAQs -> {
                startActivity(Intent(this@MainActivity, FAQActivity::class.java))
            }
            R.id.btnSetting -> {
                startActivity(Intent(this@MainActivity, SettingActivity::class.java))
            }
        }
    }

    private fun getDevices() {
        Constant.service.getUserDevices(AddDeviceRequest(user_id = "" + userData.userId)).apply {
            enqueue(object : Callback<UserDevices> {
                override fun onFailure(call: Call<UserDevices>, t: Throwable) {
                }

                override fun onResponse(
                    call: Call<UserDevices>,
                    response: Response<UserDevices>
                ) {
                    if (response.isSuccessful && response.body()?.status == 1) {
                        CommonUtility.setBooleanPreference(
                            true,
                            "isDeviceAvailable",
                            this@MainActivity
                        )
                        val diId = CommonUtility.getStringPreference(
                            "deviceId",
                            mContext
                        )
                        if (diId.isNullOrEmpty()) {
                            CommonUtility.setStringPreference(
                                response.body()?.userDeviceList!![0].macId!!,
                                "deviceId",
                                mContext
                            )
                            if (response.body()?.userDeviceList!![0].deviceName.equals(
                                    "digital",
                                    true
                                )
                            ) {
                                CommonUtility.setBooleanPreference(
                                    true,
                                    Constant.isDigital,
                                    mContext
                                )
                            } else {
                                CommonUtility.setBooleanPreference(
                                    false,
                                    Constant.isDigital,
                                    mContext
                                )
                            }
                        }
                        connectDevice()
                    } else {
                        CommonUtility.setBooleanPreference(
                            false,
                            "isDeviceAvailable",
                            this@MainActivity
                        )
                    }
                }
            })
        }
    }

    override fun onResume() {
        super.onResume()
        if (CommonUtility.getBooleanPreference(Constant.cookingIsRunning, mContext)) {
            Handler().postDelayed({
                LocalBroadcastManager.getInstance(mContext)
                    .sendBroadcast(Intent("AppIsBackground").putExtra("isBackground", false))
            }, 600)
        }
    }

}
