package com.zegacookware.service

import android.annotation.SuppressLint
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.CountDownTimer
import android.os.IBinder
import android.util.Log
import android.view.*
import android.widget.ImageView
import androidx.annotation.RequiresApi
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.zegacookware.R
import com.zegacookware.activity.MainActivity
import com.zegacookware.activity.TimerActivity
import com.zegacookware.network.Constant
import com.zegacookware.util.CommonUtility
import kotlin.math.roundToInt


class AnalogueButtonService : Service() {

    private var sameValueForTimer: Int = 0
    private var recipesTime: Long = 0
    private var countDown: CountDownTimer? = null
    private lateinit var intentOpenPopup: Intent

    private var mWindowManager: WindowManager? = null
    private var mChatHeadView: View? = null
    private var timer1: ImageView? = null
    private var timer2: ImageView? = null
    private var timer3: ImageView? = null
    private var timer4: ImageView? = null
    private var timer5: ImageView? = null
    private var timer6: ImageView? = null
    private var timer7: ImageView? = null
    private var timer8: ImageView? = null
    private var timer9: ImageView? = null
    private var timer10: ImageView? = null
    private var timer11: ImageView? = null
    private var timer12: ImageView? = null

    override fun onBind(intent: Intent): IBinder? {
        return null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate() {
        super.onCreate()

        intentOpenPopup = Intent("OpenCookingDialog")
        mChatHeadView = LayoutInflater.from(this).inflate(R.layout.layout_home_button, null)

        mChatHeadView!!.visibility = View.GONE

        LocalBroadcastManager.getInstance(applicationContext).unregisterReceiver(registerReceiver)
        LocalBroadcastManager.getInstance(applicationContext).registerReceiver(
            registerReceiver,
            IntentFilter("AppIsBackground")
        )

        LocalBroadcastManager.getInstance(applicationContext)
            .unregisterReceiver(isFromServiceForTimerRegister)
        LocalBroadcastManager.getInstance(applicationContext).registerReceiver(
            isFromServiceForTimerRegister,
            IntentFilter("isFromServiceForTimer11")
        )

        val LAYOUT_FLAG = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }
        //Add the view to the window.
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            LAYOUT_FLAG,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

        //Specify the chat head position
        params.gravity =
            Gravity.BOTTOM or Gravity.START        //Initially view will be added to top-left corner
        params.x = 0
        params.y = 0

        //Add the view to the window
        mWindowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        mWindowManager!!.addView(mChatHeadView, params)


        timer1 = mChatHeadView!!.findViewById<ImageView>(R.id.timer_1) as ImageView
        timer2 = mChatHeadView!!.findViewById<ImageView>(R.id.timer_2) as ImageView
        timer3 = mChatHeadView!!.findViewById<ImageView>(R.id.timer_3) as ImageView
        timer4 = mChatHeadView!!.findViewById<ImageView>(R.id.timer_4) as ImageView
        timer5 = mChatHeadView!!.findViewById<ImageView>(R.id.timer_5) as ImageView
        timer6 = mChatHeadView!!.findViewById<ImageView>(R.id.timer_6) as ImageView
        timer7 = mChatHeadView!!.findViewById<ImageView>(R.id.timer_7) as ImageView
        timer8 = mChatHeadView!!.findViewById<ImageView>(R.id.timer_8) as ImageView
        timer9 = mChatHeadView!!.findViewById<ImageView>(R.id.timer_9) as ImageView
        timer10 = mChatHeadView!!.findViewById<ImageView>(R.id.timer_10) as ImageView
        timer11 = mChatHeadView!!.findViewById<ImageView>(R.id.timer_11) as ImageView
        timer12 = mChatHeadView!!.findViewById<ImageView>(R.id.timer_12) as ImageView

        recipesTime =
            CommonUtility.getStringPreference("recipesTime", applicationContext).toLong()

        recipesTime *= 60000

        CommonUtility.setBooleanPreference(
            false,
            Constant.isShowTemperatureView,
            applicationContext
        )
        timerCountDown()
        count = 0

        mChatHeadView!!.setOnTouchListener(object : View.OnTouchListener {
            private var lastAction: Int = 0

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        lastAction = event.action
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (lastAction == MotionEvent.ACTION_DOWN) {

                            mChatHeadView!!.visibility = View.GONE

                            val intent = Intent(
                                this@AnalogueButtonService,
                                TimerActivity::class.java
                            ).putExtra("isFromService", true)
                            intent.flags =
                                Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                            startActivity(intent)
                        }
                        lastAction = event.action
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        return true
                    }
                }
                return false
            }
        })
    }

    private var isFromServiceForTimerRegister = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            Log.e("Service ====== ", "2")
            if (countDown != null) {
                countDown?.cancel()
            }
            stopSelf()
            stopService(Intent(applicationContext, AnalogueButtonService::class.java))
            startActivity(
                Intent(
                    applicationContext,
                    MainActivity::class.java
                ).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            )
        }
    }

    private fun timerCountDown() {
        Log.e("Service ====== ", "4")
        countDown = object : CountDownTimer(recipesTime, 1000) {
            override fun onTick(millisUntilFinished: Long) {

                var minutes = (millisUntilFinished / 1000 / 60).toString()
                var seconds = (millisUntilFinished / 1000 % 60).toString()
                if (minutes.length < 2) {
                    minutes = "0$minutes"
                }
                if (seconds.length < 2) {
                    seconds = "0$seconds"
                }
                val timeStr = "$minutes:$seconds"

                LocalBroadcastManager.getInstance(applicationContext)
                    .sendBroadcast(Intent("countDown").putExtra("countTime", timeStr))

                val diffTime = (recipesTime.toDouble() - 0) / 12
                val diff1 = (millisUntilFinished.toDouble() - 0) / diffTime
                var countTime = 12 - diff1.roundToInt()
                if (countTime == 0) {
                    countTime = 0
                }
                if (!countTime.toString().startsWith("-") && countTime != sameValueForTimer) {

                    sameValueForTimer = countTime
                    count = countTime
                    updateImage()
                    LocalBroadcastManager.getInstance(applicationContext)
                        .sendBroadcast(
                            Intent("segmentCountRegister").putExtra("count", countTime)
                        )
                }

                if (countTime >= 12 && countDown != null && timeStr.equals("00:00", true)) {
                    countDown?.cancel()
                    countDown = null
                    LocalBroadcastManager.getInstance(applicationContext)
                        .sendBroadcast(intentOpenPopup)
                }
            }

            override fun onFinish() {
            }
        }.start()
    }


    private fun updateImage() {
        if (count == 0) {
            timer1!!.alpha = 0.1f
            timer2!!.alpha = 0.1f
            timer3!!.alpha = 0.1f
            timer4!!.alpha = 0.1f
            timer5!!.alpha = 0.1f
            timer6!!.alpha = 0.1f
            timer7!!.alpha = 0.1f
            timer8!!.alpha = 0.1f
            timer9!!.alpha = 0.1f
            timer10!!.alpha = 0.1f
            timer11!!.alpha = 0.1f
            timer12!!.alpha = 0.1f
        }
        if (count == 1) {
            timer1!!.alpha = 1f
            timer2!!.alpha = 0.1f
            timer3!!.alpha = 0.1f
            timer4!!.alpha = 0.1f
            timer5!!.alpha = 0.1f
            timer6!!.alpha = 0.1f
            timer7!!.alpha = 0.1f
            timer8!!.alpha = 0.1f
            timer9!!.alpha = 0.1f
            timer10!!.alpha = 0.1f
            timer11!!.alpha = 0.1f
            timer12!!.alpha = 0.1f
        }
        if (count == 2) {
            timer1!!.alpha = 1f
            timer2!!.alpha = 1f
            timer3!!.alpha = 0.1f
            timer4!!.alpha = 0.1f
            timer5!!.alpha = 0.1f
            timer6!!.alpha = 0.1f
            timer7!!.alpha = 0.1f
            timer8!!.alpha = 0.1f
            timer9!!.alpha = 0.1f
            timer10!!.alpha = 0.1f
            timer11!!.alpha = 0.1f
            timer12!!.alpha = 0.1f
        }
        if (count == 3) {
            timer1!!.alpha = 1f
            timer2!!.alpha = 1f
            timer3!!.alpha = 1f
            timer4!!.alpha = 0.1f
            timer5!!.alpha = 0.1f
            timer6!!.alpha = 0.1f
            timer7!!.alpha = 0.1f
            timer8!!.alpha = 0.1f
            timer9!!.alpha = 0.1f
            timer10!!.alpha = 0.1f
            timer11!!.alpha = 0.1f
            timer12!!.alpha = 0.1f
        }
        if (count == 4) {
            timer1!!.alpha = 1f
            timer2!!.alpha = 1f
            timer3!!.alpha = 1f
            timer4!!.alpha = 1f
            timer5!!.alpha = 0.1f
            timer6!!.alpha = 0.1f
            timer7!!.alpha = 0.1f
            timer8!!.alpha = 0.1f
            timer9!!.alpha = 0.1f
            timer10!!.alpha = 0.1f
            timer11!!.alpha = 0.1f
            timer12!!.alpha = 0.1f
        }
        if (count == 5) {
            timer1!!.alpha = 1f
            timer2!!.alpha = 1f
            timer3!!.alpha = 1f
            timer4!!.alpha = 1f
            timer5!!.alpha = 1f
            timer6!!.alpha = 0.1f
            timer7!!.alpha = 0.1f
            timer8!!.alpha = 0.1f
            timer9!!.alpha = 0.1f
            timer10!!.alpha = 0.1f
            timer11!!.alpha = 0.1f
            timer12!!.alpha = 0.1f
        }
        if (count == 6) {
            timer1!!.alpha = 1f
            timer2!!.alpha = 1f
            timer3!!.alpha = 1f
            timer4!!.alpha = 1f
            timer5!!.alpha = 1f
            timer6!!.alpha = 1f
            timer7!!.alpha = 0.1f
            timer8!!.alpha = 0.1f
            timer9!!.alpha = 0.1f
            timer10!!.alpha = 0.1f
            timer11!!.alpha = 0.1f
            timer12!!.alpha = 0.1f
        }
        if (count == 7) {
            timer1!!.alpha = 1f
            timer2!!.alpha = 1f
            timer3!!.alpha = 1f
            timer4!!.alpha = 1f
            timer5!!.alpha = 1f
            timer6!!.alpha = 1f
            timer7!!.alpha = 1f
            timer8!!.alpha = 0.1f
            timer9!!.alpha = 0.1f
            timer10!!.alpha = 0.1f
            timer11!!.alpha = 0.1f
            timer12!!.alpha = 0.1f
        }
        if (count == 8) {
            timer1!!.alpha = 1f
            timer2!!.alpha = 1f
            timer3!!.alpha = 1f
            timer4!!.alpha = 1f
            timer5!!.alpha = 1f
            timer6!!.alpha = 1f
            timer7!!.alpha = 1f
            timer8!!.alpha = 1f
            timer9!!.alpha = 0.1f
            timer10!!.alpha = 0.1f
            timer11!!.alpha = 0.1f
            timer12!!.alpha = 0.1f
        }
        if (count == 9) {
            timer1!!.alpha = 1f
            timer2!!.alpha = 1f
            timer3!!.alpha = 1f
            timer4!!.alpha = 1f
            timer5!!.alpha = 1f
            timer6!!.alpha = 1f
            timer7!!.alpha = 1f
            timer8!!.alpha = 1f
            timer9!!.alpha = 1f
            timer10!!.alpha = 0.1f
            timer11!!.alpha = 0.1f
            timer12!!.alpha = 0.1f
        }
        if (count == 10) {
            timer1!!.alpha = 1f
            timer2!!.alpha = 1f
            timer3!!.alpha = 1f
            timer4!!.alpha = 1f
            timer5!!.alpha = 1f
            timer6!!.alpha = 1f
            timer7!!.alpha = 1f
            timer8!!.alpha = 1f
            timer9!!.alpha = 1f
            timer10!!.alpha = 1f
            timer11!!.alpha = 0.1f
            timer12!!.alpha = 0.1f
        }
        if (count == 11) {
            timer1!!.alpha = 1f
            timer2!!.alpha = 1f
            timer3!!.alpha = 1f
            timer4!!.alpha = 1f
            timer5!!.alpha = 1f
            timer6!!.alpha = 1f
            timer7!!.alpha = 1f
            timer8!!.alpha = 1f
            timer9!!.alpha = 1f
            timer10!!.alpha = 1f
            timer11!!.alpha = 1f
            timer12!!.alpha = 0.1f
        }
        if (count == 12) {
            timer1!!.alpha = 1f
            timer2!!.alpha = 1f
            timer3!!.alpha = 1f
            timer4!!.alpha = 1f
            timer5!!.alpha = 1f
            timer6!!.alpha = 1f
            timer7!!.alpha = 1f
            timer8!!.alpha = 1f
            timer9!!.alpha = 1f
            timer10!!.alpha = 1f
            timer11!!.alpha = 1f
            timer12!!.alpha = 1f
        }
        CommonUtility.setStringPreference(count.toString(), "count", applicationContext)
    }


    override fun onDestroy() {
        super.onDestroy()
        count = 0
        CommonUtility.setStringPreference(count.toString(), "count", applicationContext)
        if (mChatHeadView != null) mWindowManager!!.removeView(mChatHeadView)
        CommonUtility.setBooleanPreference(false, Constant.cookingIsRunning, applicationContext)
        LocalBroadcastManager.getInstance(applicationContext).unregisterReceiver(registerReceiver)
    }

    private var registerReceiver = object : BroadcastReceiver() {
        @RequiresApi(Build.VERSION_CODES.O)
        override fun onReceive(context: Context?, intent: Intent?) {
            Log.d("Service ====== ", "10 ===" + intent!!.getBooleanExtra("isBackground", false))
            if (intent.getBooleanExtra("isBackground", false)) {
                mChatHeadView!!.visibility = View.GONE
            } else {
                mChatHeadView!!.visibility = View.VISIBLE
            }
        }
    }

    companion object {
        private var count = 0
    }

}
