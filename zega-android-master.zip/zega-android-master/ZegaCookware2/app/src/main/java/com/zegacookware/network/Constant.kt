package com.zegacookware.network

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import javax.security.cert.CertificateException

object Constant {

    const val blurRadius: Float = 15f
    const val isDigital = "IS_DIGITAL"
    const val isShowTemperatureView = "IS_TEMPERATURE_VIEW"
    /*CONSTANT NAMES*/
    const val isLoggedIn = "IS_LOGIN"
    const val userInfo = "USER_INFO"
    const val cookingIsRunning = "cookingIsRunning"

    /*-----------------------------------------RETROFIT API-----------------------------------------------------------*/
//    var baseForImage = "http://zegacookware.extreme.org.in/zega_cookware"
//    var baseForImage = "http://157.230.244.73"

    var baseForImage = "http://zegacooking.com"

    var categoryImageBaseUrl =
        "$baseForImage/public/uploads/category_image/"
    val recipesImageBaseUrl =
        "$baseForImage/public/uploads/recepie_image/"
    val profileImageBaseUrl =
        "$baseForImage/public/uploads/recepie_image/"

    val faqWebUrl = "$baseForImage/front-faq-list"
    val termsWebUrl = "$baseForImage/term-condition"
    val privacyPolicyUrl = "$baseForImage/privacy-policy"
    val licensingWebUrl =
        "$baseForImage/licensing-imformation"
    val disclaimerUrl = "$baseForImage/disclaimer"


    val faqBaseUrl = "$baseForImage/faq-detail/"
    val bluetoothUrl = "$baseForImage/bluetooth-help"


    //     private   var baseUrl = "http://zegacookware.extreme.org.in/zega_cookware/api/"
    private var baseUrl = "http://zegacooking.com/api/"
    var tokenInjectInterceptor: TokenInjectInterceptor =
        TokenInjectInterceptor()

    var service = Retrofit.Builder()
        .baseUrl(baseUrl)
        .client(getUnsafeOkHttpClient())
        .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
        .addConverterFactory(GsonConverterFactory.create())
        .build().create(ServiceApi::class.java)!!

    private fun getUnsafeOkHttpClient(): OkHttpClient {
        try {
            val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
                override fun getAcceptedIssuers(): Array<X509Certificate> {
                    return arrayOf()
                }

                @Throws(CertificateException::class)
                override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {
                }

                @Throws(CertificateException::class)
                override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {
                }
            })
            // Install the all-trusting trust manager
            val sslContext = SSLContext.getInstance("SSL")
            sslContext.init(null, trustAllCerts, java.security.SecureRandom())
            // Create an ssl socket factory with our all-trusting manager
            val sslSocketFactory = sslContext.socketFactory
            val builder = OkHttpClient.Builder()
            builder.sslSocketFactory(sslSocketFactory, trustAllCerts[0] as X509TrustManager)
            builder.hostnameVerifier { hostname, session -> true }
                .connectTimeout(40, TimeUnit.SECONDS)
                .readTimeout(40, TimeUnit.SECONDS)
                .writeTimeout(40, TimeUnit.SECONDS)
                .addInterceptor(tokenInjectInterceptor)
                .addInterceptor(HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY)) // should be added last
                .build()
            return builder.build()
        } catch (e: Exception) {
            throw RuntimeException(e)
        }
    }
    /*----------------------------------------------------------------------------------------------------------------*/
}
