package com.zegacookware.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.zegacookware.R
import com.zegacookware.activity.BaseActivity
import com.zegacookware.activity.manage_device.ManageDevicesActivity
import com.zegacookware.interfaces.SetOnItemClickListener
import com.zegacookware.model.UserDeviceList
import com.zegacookware.network.Constant
import com.zegacookware.util.CommonUtility
import kotlinx.android.synthetic.main.item_device_list.view.*

class DeviceListAdapter(
    var mContext: Context,
    var userDeviceList: List<UserDeviceList>,
    var setOnItemClickListener: SetOnItemClickListener
) :
    RecyclerView.Adapter<DeviceListAdapter.RecipesViewHolder>() {
    private var currentPosition = -1
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecipesViewHolder {
        val view =
            LayoutInflater.from(mContext).inflate(R.layout.item_device_list, parent, false)
        return RecipesViewHolder(view)
    }

    override fun getItemCount(): Int {
        return userDeviceList.size
    }

    override fun onBindViewHolder(holder: RecipesViewHolder, position: Int) {
        holder.itemView.deviceName.text = userDeviceList[position].deviceName
        holder.itemView.tvDeviceId.text = userDeviceList[position].deviceId
        if (position == currentPosition || userDeviceList[position].deviceId.equals(
                CommonUtility.getStringPreference(
                    "deviceId",
                    mContext
                ), true
            )
        ) {
            currentPosition = -1
            holder.itemView.lytMainSelect.background =
                ContextCompat.getDrawable(mContext, R.drawable.selected_shape_device)
        } else {
            holder.itemView.lytMainSelect.background =
                ContextCompat.getDrawable(mContext, R.drawable.unselected_shape_device)
        }

        holder.itemView.btnRemoveDevice.setOnClickListener {
            setOnItemClickListener.onItemClick(position)
        }
        holder.itemView.setOnClickListener {
            (mContext as ManageDevicesActivity).callVibration()
            currentPosition = position
            notifyDataSetChanged()

            BaseActivity.disconnect()
            BaseActivity.close()

            if (userDeviceList[position].deviceName.equals("digital", true)) {
                CommonUtility.setBooleanPreference(true, Constant.isDigital, mContext)
                CommonUtility.setStringPreference(
                    userDeviceList[position].macId!!,
                    "deviceId",
                    mContext
                )
                BaseActivity.connectHardware()
            } else {
                CommonUtility.setBooleanPreference(false, Constant.isDigital, mContext)
                CommonUtility.setStringPreference(
                    userDeviceList[position].deviceId!!,
                    "deviceId",
                    mContext
                )
            }

        }
    }

    class RecipesViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    }
}