package com.zegacookware.activity.setting
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.core.content.ContextCompat
import com.zegacookware.BuildConfig
import com.zegacookware.R
import com.zegacookware.activity.BaseActivity
import com.zegacookware.activity.manage_device.ManageDevicesActivity
import com.zegacookware.model.recipes.RecipesDetailRequest
import com.zegacookware.model.recipes.recipesdetail.FavouriteResponse
import com.zegacookware.model.user.UserModel
import com.zegacookware.model.user.UserResult
import com.zegacookware.network.Constant
import com.zegacookware.util.CommonUtility
import kotlinx.android.synthetic.main.activity_setting.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SettingActivity : BaseActivity(), View.OnClickListener {

    private lateinit var mContext: Context
    private lateinit var userData: UserResult

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setting)
        mContext = this
        userData = CommonUtility.getUserData(Constant.userInfo, this@SettingActivity)

        tvUserName.text = userData.name + " " + userData.lastName

        tvAppVersion.text = "App version " + BuildConfig.VERSION_NAME

        lytMyProfile.setOnClickListener(this)
        lytManageDevice.setOnClickListener(this)
        lytFeedback.setOnClickListener(this)
        lytLicensingInformation.setOnClickListener(this)
        lytTermsOfService.setOnClickListener(this)
        lytPrivacyPolicy.setOnClickListener(this)
        btnBackSetting.setOnClickListener(this)
        btnEnableNotification.setOnClickListener(this)
        lytHelp.setOnClickListener(this)
        lytDisclaimer.setOnClickListener(this)

        if (userData.enableNotification != null && userData.enableNotification == "yes") {
            btnEnableNotification.setImageDrawable(
                ContextCompat.getDrawable(
                    mContext,
                    R.drawable.toggle_on
                )
            )
        }
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.lytHelp -> {
                startActivity(
                    Intent(this@SettingActivity, WebViewActivity::class.java)
                        .putExtra("header", "HELP")
                        .putExtra("url", Constant.bluetoothUrl)
                )
            }
            R.id.btnEnableNotification -> {
                if (ContextCompat.getDrawable(
                        mContext,
                        R.drawable.toggle_off
                    )?.constantState == btnEnableNotification.drawable.constantState
                ) {
                    enableNotification("yes")
                } else {
                    enableNotification("no")
                }
            }
            R.id.btnBackSetting -> {
                finish()
            }
            R.id.lytMyProfile -> {
                startActivity(Intent(this@SettingActivity, MyAccountActivity::class.java))

            }
            R.id.lytManageDevice -> {
                if (CommonUtility.getBooleanPreference(Constant.cookingIsRunning, mContext)) {
                    CommonUtility.openDialogForCookingRunning(mContext)
                    return
                }
                startActivity(Intent(this, ManageDevicesActivity::class.java))
            }
            R.id.lytFeedback -> {
                startActivity(Intent(this@SettingActivity, FeedbackActivity::class.java))
            }
            R.id.lytTermsOfService -> {
                startActivity(
                    Intent(this@SettingActivity, WebViewActivity::class.java)
                        .putExtra("header", "TERMS OF SERVICE")
                        .putExtra("url", Constant.termsWebUrl)
                )
            }
            R.id.lytPrivacyPolicy -> {
                startActivity(
                    Intent(this@SettingActivity, WebViewActivity::class.java)
                        .putExtra("header", "PRIVACY POLICY")
                        .putExtra("url", Constant.privacyPolicyUrl)
                )
            }
            R.id.lytLicensingInformation -> {
                startActivity(
                    Intent(this@SettingActivity, WebViewActivity::class.java)
                        .putExtra("header", "EULA")
                        .putExtra("url", Constant.licensingWebUrl)
                )
            }
            R.id.lytDisclaimer -> {
                startActivity(
                    Intent(this@SettingActivity, WebViewActivity::class.java)
                        .putExtra("header", "Disclaimer")
                        .putExtra("url", Constant.disclaimerUrl)
                )
            }
        }
    }
    private fun enableNotification(status: String) {
        Constant.service.enableNotification(
            RecipesDetailRequest(
                user_id = "" + userData.userId,
                enable_status = status
            )
        ).apply {
            enqueue(object : Callback<FavouriteResponse> {
                override fun onFailure(call: Call<FavouriteResponse>, t: Throwable) {
                }

                override fun onResponse(
                    call: Call<FavouriteResponse>,
                    response: Response<FavouriteResponse>
                ) {
                    if (response.isSuccessful && response.body()?.status == 1) {

                        CommonUtility.openDialog(
                            response.body()?.msg!!,
                            "Ok",
                            ContextCompat.getDrawable(this@SettingActivity, R.drawable.ic_right)!!,
                            this@SettingActivity
                        )

                        UserModel.getUserProfile(this@SettingActivity)

//                        Thread.sleep(4300)
                        if (status == "yes") {
                            btnEnableNotification.setImageDrawable(
                                ContextCompat.getDrawable(
                                    mContext,
                                    R.drawable.toggle_on
                                )
                            )
                        } else {
                            btnEnableNotification.setImageDrawable(
                                ContextCompat.getDrawable(
                                    mContext,
                                    R.drawable.toggle_off
                                )
                            )
                        }

                    }

                }
            })
        }
    }

}

