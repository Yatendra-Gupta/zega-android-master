package com.zegacookware.adapter

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.appcompat.widget.AppCompatButton
import androidx.core.app.ActivityCompat
import androidx.viewpager.widget.PagerAdapter
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.zegacookware.R
import com.zegacookware.activity.StartCookingSliderActivity
import com.zegacookware.activity.bl.DigitalTimerActivity
import com.zegacookware.model.CookingSliderModel
import com.zegacookware.model.user.UserModel
import com.zegacookware.network.Constant
import com.zegacookware.service.DigitalTimerService
import com.zegacookware.util.CommonUtility

class StartCookingPagerAdapter(var mContext: Context, var id: String) : PagerAdapter() {

    override fun instantiateItem(collection: ViewGroup, position: Int): Any {
        val modelObject = CookingSliderModel.values()[position]
        val inflater = LayoutInflater.from(mContext)
        val layout = inflater.inflate(modelObject.layoutResId, collection, false) as ViewGroup
        if (modelObject.layoutResId == R.layout.layout_start_cooking2) {
            val btnStartCooking1 = layout.findViewById<AppCompatButton>(R.id.btnStartCooking1)
            val btnBack2 = layout.findViewById<ImageView>(R.id.btnBack2)
            btnBack2.setOnClickListener { (mContext as StartCookingSliderActivity).changePages(0) }
            val ivGif = layout.findViewById<ImageView>(R.id.ivGif)
            Glide.with(mContext).asGif().load(R.raw.turn_on_stove).apply(
                RequestOptions.diskCacheStrategyOf(
                    DiskCacheStrategy.NONE
                )
            ).into(ivGif)
            btnStartCooking1.setOnClickListener {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (Settings.canDrawOverlays(mContext)) {

                        CommonUtility.setBooleanPreference(
                            false,
                            Constant.cookingIsRunning,
                            mContext
                        )
                        UserModel.isHardwareOutOfRange = false
                        UserModel.isCallFromDevice = true
                        UserModel.mBluetoothGattChar = null
                        mContext.stopService(Intent(mContext, DigitalTimerService::class.java))
//                        HomeButtonService.terminateService()
                        val mIntent = Intent(
                            mContext,
                            DigitalTimerActivity::class.java
                        )
                        CommonUtility.setBooleanPreference(
                            true,
                            Constant.isShowTemperatureView,
                            mContext
                        )

                        mIntent.putExtra("isFromService", false)
                            .putExtra("isFromServiceForTimer", false)
                        mIntent.flags =
                            Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                        mContext.startActivity(mIntent)
                        ActivityCompat.finishAffinity(mContext as Activity)
                    } else {
                        StartCookingSliderActivity().openDialogForAllowPermission(mContext)
                    }
                } else {
                    CommonUtility.setBooleanPreference(
                        false,
                        Constant.cookingIsRunning,
                        mContext
                    )
                    UserModel.isHardwareOutOfRange = false
                    UserModel.isCallFromDevice = true
                    UserModel.mBluetoothGattChar = null
                    mContext.stopService(Intent(mContext, DigitalTimerService::class.java))
//                    HomeButtonService.terminateService()
                    val mIntent = Intent(
                        mContext,
                        DigitalTimerActivity::class.java
                    )
                    CommonUtility.setBooleanPreference(
                        true,
                        Constant.isShowTemperatureView,
                        mContext
                    )
                    mIntent.putExtra("isFromService", false)
                        .putExtra("isFromServiceForTimer", false)
                    mIntent.flags =
                        Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                    mContext.startActivity(mIntent)
                    ActivityCompat.finishAffinity(mContext as Activity)
                }
            }
        } else {
            val btnForward1 = layout.findViewById<ImageView>(R.id.btnForward1)
            btnForward1.setOnClickListener {
                (mContext as StartCookingSliderActivity).changePages(
                    1
                )
            }

            val ivGif = layout.findViewById<ImageView>(R.id.ivGif)
            Glide.with(mContext).asGif().load(R.raw.add_ingredients).apply(
                RequestOptions.diskCacheStrategyOf(
                    DiskCacheStrategy.NONE
                )
            ).into(ivGif)
        }
        collection.addView(layout)

        return layout
    }

    override fun destroyItem(collection: ViewGroup, position: Int, view: Any) {
        collection.removeView(view as View)
    }

    override fun getCount(): Int {
        return CookingSliderModel.values().size
    }

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view === `object`
    }

//    override fun getPageTitle(position: Int): CharSequence {
//        val customPagerEnum = IntroSliderModel.values()[position]
//        return mContext.getString(customPagerEnum.titleResId)
//    }
}