package com.zegacookware.fragment

import android.view.ViewGroup

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter

import com.zegacookware.util.CustomViewPager

import java.util.ArrayList

class MyPagerAdapter(fm: FragmentManager) : FragmentPagerAdapter(fm,
    BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {

    private val fragments: MutableList<Fragment>
    private var mCurrentPosition = -1

    init {
        this.fragments = ArrayList()
        fragments.add(IngredientsFragment())
        fragments.add(InstructionsFragment())
    }

    override fun setPrimaryItem(container: ViewGroup, position: Int, `object`: Any) {
        super.setPrimaryItem(container, position, `object`)
        if (position != mCurrentPosition) {
            val fragment = `object` as Fragment
            val pager = container as CustomViewPager
            if (fragment?.view != null) {
                mCurrentPosition = position
                pager.measureCurrentView(fragment.view)
            }
        }
    }

    override fun getItem(position: Int): Fragment {
        return fragments[position]
    }

    override fun getCount(): Int {
        return fragments.size
    }
}