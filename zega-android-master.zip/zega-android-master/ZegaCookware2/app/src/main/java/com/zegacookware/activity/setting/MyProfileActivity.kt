package com.zegacookware.activity.setting

import android.app.Activity
import android.content.Context
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.InputFilter
import android.view.Gravity
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.zegacookware.interfaces.ClickOnFavouritePopup
import com.zegacookware.util.CommonUtility
import com.zegacookware.R
import com.zegacookware.model.recipes.recipesdetail.FavouriteResponse
import com.zegacookware.model.user.ChangePasswordRequest
import com.zegacookware.model.user.UserModel
import com.zegacookware.model.user.UserResult
import com.zegacookware.network.Constant
import com.zegacookware.util.blurBackground.BlurPopupWindowTemp
import kotlinx.android.synthetic.main.activity_my_profile.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MyProfileActivity : AppCompatActivity() {

    private lateinit var mContext: Context
    private lateinit var userData: UserResult

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_profile)
        mContext = this@MyProfileActivity
        hideKeyboard()
        userData = CommonUtility.getUserData(Constant.userInfo, this@MyProfileActivity)
        etEmail.filters = etEmail.filters + InputFilter.AllCaps()
        etFirstName.setText(userData.name)
        etLastName.setText(userData.lastName)
        etEmail.setText(userData.email)
        ivBack.setOnClickListener { finish() }


        btnUpdate.setOnClickListener {
            if (etFirstName.text.toString().isEmpty()) {
                CommonUtility.openDialog(
                    "PLEASE ENTER FIRST NAME",
                    "OK",
                    ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
                    mContext
                )
                return@setOnClickListener
            }
            if (etLastName.text.toString().isEmpty()) {
                CommonUtility.openDialog(
                    "PLEASE ENTER LAST NAME",
                    "OK",
                    ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
                    mContext
                )
                return@setOnClickListener
            }

            Constant.service.changeDetails(
                ChangePasswordRequest(
                    first_name = etFirstName.text.toString().trim(),
                    last_name = etLastName.text.toString().trim(),
                    user_id = "" + userData.userId
                )
            ).apply {
                enqueue(object : Callback<FavouriteResponse> {
                    override fun onFailure(call: Call<FavouriteResponse>, t: Throwable) {
                    }

                    override fun onResponse(
                        call: Call<FavouriteResponse>,
                        response: Response<FavouriteResponse>
                    ) {

                        if (response.isSuccessful && response.body()?.status == 1) {
                            UserModel.getUserProfile(this@MyProfileActivity)
                            openDialog(
                                response.body()?.msg!!,
                                "Done",
                                ContextCompat.getDrawable(mContext, R.drawable.ic_right)!!,
                                this@MyProfileActivity
                            )
                        }
                    }
                })
            }


        }
    }

    fun openDialog(msgString: String, buttonText: String, ids: Drawable, mContext: Context) {
        BlurPopupWindowTemp.Builder<BlurPopupWindowTemp>(
            mContext as Activity,
            msgString,
            buttonText,
            "",
            ids, object : ClickOnFavouritePopup {
                override fun onItemClick(position: Int, cusineType: String) {
                    finish()
                }
            }
        ).setContentView(R.layout.dialog_validation)
            .setGravity(Gravity.CENTER)
            .setScaleRatio(0.1f)
            .setBlurRadius(Constant.blurRadius)
            .setDismissOnClickBack(false)
            .setDismissOnTouchBackground(false)
            .build()
            .show()
    }

    private fun AppCompatActivity.hideKeyboard() {
        val view = this.currentFocus
        if (view != null) {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(view.windowToken, 0)
        }
        // else {
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        // }
    }
}
