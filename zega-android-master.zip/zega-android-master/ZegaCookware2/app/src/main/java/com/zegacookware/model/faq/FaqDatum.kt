package com.zegacookware.model.faq

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class FaqDatum {

    @SerializedName("faq_id")
    @Expose
    var faqId: Int? = null
    @SerializedName("faq_title")
    @Expose
    var faqTitle: String? = null

}
