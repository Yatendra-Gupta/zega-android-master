package com.zegacookware.model.quickcook

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class QuickCook {
    @SerializedName("quick_cook")
    @Expose
    var quickCook: List<QuickCookData>? = null
    @SerializedName("status")
    @Expose
    var status: Int? = null

}
