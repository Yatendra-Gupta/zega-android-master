package com.zegacookware.model.recipes

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class AllRecipes {
    @SerializedName("title_result")
    @Expose
    var titleResult: List<TitleResult>? = null
    @SerializedName("status")
    @Expose
    var status: Int? = null

}
