package com.zegacookware.interfaces

interface SetOnItemClickListener {
    fun onItemClick(position: Int)
}