package com.zegacookware.model.recipes

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class RecipesCategory {
    @SerializedName("category_result")
    @Expose
    var categoryResult: List<CategoryResult>? = null
    @SerializedName("status")
    @Expose
    var status: Int? = null
}
class CategoryResult {

    @SerializedName("recepie_category_id")
    @Expose
    var recepieCategoryId: Int? = null
    @SerializedName("recepie_category_name")
    @Expose
    var recepieCategoryName: String? = null
    @SerializedName("recepie_image")
    @Expose
    var recepieImage: String? = null

}