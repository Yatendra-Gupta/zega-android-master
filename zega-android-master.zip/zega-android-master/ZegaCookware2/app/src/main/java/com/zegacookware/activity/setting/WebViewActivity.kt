package com.zegacookware.activity.setting

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import com.zegacookware.R
import com.zegacookware.activity.BaseActivity
import kotlinx.android.synthetic.main.activity_web_view.*


class WebViewActivity : BaseActivity() {
    private lateinit var mContext: Context
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_web_view)
        mContext = this
        overridePendingTransition(R.anim.slide_left_enter, R.anim.slide_left_exit)
        prepareWebView()

        tvHeader.text = intent.getStringExtra("header")
        webView?.loadUrl(intent.getStringExtra("url"))

        btnBackWeb.setOnClickListener {
            if (webView.canGoBack()) {
                webView.goBack()
            } else {
                super.onBackPressed()
                overridePendingTransition(R.anim.slide_right_enter, R.anim.slide_right_exit)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        webView?.onResume()
    }

    override fun onPause() {
        webView?.onPause()
        super.onPause()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun prepareWebView() {
        webView?.apply {
            settings.apply {
                javaScriptEnabled = true
                allowUniversalAccessFromFileURLs = true
                allowFileAccessFromFileURLs = true
                domStorageEnabled = true
                useWideViewPort = true
                loadWithOverviewMode = true
//                setSupportMultipleWindows(true)
                javaScriptCanOpenWindowsAutomatically = true
            }
            isHorizontalScrollBarEnabled = false
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    startActivity(intent)
                    return true
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    progressB.visibility = View.GONE
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {

                }
            }
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
