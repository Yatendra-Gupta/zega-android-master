package com.zegacookware.activity

import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.zegacookware.R
import com.zegacookware.adapter.QuickCookAdapter
import com.zegacookware.interfaces.SetOnItemClickListener
import com.zegacookware.model.quickcook.QuickCook
import com.zegacookware.model.quickcook.QuickCookData
import com.zegacookware.network.Constant
import com.zegacookware.util.CommonUtility
import kotlinx.android.synthetic.main.activity_quick_cook.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class QuickCookActivity : BaseActivity() {

    private lateinit var mContext: Context
    private val recipesList: ArrayList<QuickCookData> = ArrayList()

    private lateinit var adapter: QuickCookAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quick_cook)
        mContext = this
        ivBack.setOnClickListener { finish() }
        getCategoryList()
    }

    private fun getCategoryList() {
        CommonUtility.showProgressDialog(mContext)
        rvRecipesCategory.layoutManager =
            LinearLayoutManager(mContext)
        adapter = QuickCookAdapter(mContext, recipesList, object :
            SetOnItemClickListener {
            override fun onItemClick(position: Int) {
                if (CommonUtility.getBooleanPreference("isDeviceAvailable", mContext)) {
                    if (CommonUtility.getBooleanPreference(Constant.cookingIsRunning, mContext)) {
                        CommonUtility.openDialogForCookingRunning(mContext)
                        return
                    }
                    CommonUtility.setStringPreference(
                        recipesList[position].quickRecepieTime.toString(),
                        "recipesTime",
                        this@QuickCookActivity
                    )
                    CommonUtility.setStringPreference(
                        recipesList[position].quickRecepieTemperature.toString(),
                        "recipesTemp",
                        this@QuickCookActivity
                    )
                    if (enableBluetooth()) {
                        startActivity(
                            Intent(
                                this@QuickCookActivity,
                                StartCookingSliderActivity::class.java
                            ).putExtra("id", "" + recipesList[position].recepieCategoryId)
                        )
                    }
                } else {
                    CommonUtility.openDialogForNotConnectedDevice(
                        "NO ZEGA DEVICE IS\nCURRENTLY\nCONNECTED TO THE APP.",
                        "MANAGE DEVICES",
                        ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
                        mContext
                    )
                }
            }
        })
        rvRecipesCategory.adapter = adapter
        Constant.service.getQuickCook().apply {
            enqueue(object : Callback<QuickCook> {
                override fun onFailure(call: Call<QuickCook>, t: Throwable) {
                    CommonUtility.hideProgressBar()
                }

                override fun onResponse(
                    call: Call<QuickCook>,
                    response: Response<QuickCook>
                ) {
                    CommonUtility.hideProgressBar()
                    recipesList += response.body()?.quickCook!!
                    adapter.notifyDataSetChanged()
                }

            })
        }

    }

    private fun enableBluetooth(): Boolean {
        if (CommonUtility.getBooleanPreference(
                Constant.isDigital,
                this@QuickCookActivity
            )
        ) {
            val mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
            return if (!mBluetoothAdapter!!.isEnabled) {
                val enableBTIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                startActivity(enableBTIntent)
                false
            } else {
                true
            }
        }
        return true
    }

//    private val broadcastReceiver = object : BroadcastReceiver() {
//        override fun onReceive(context: Context, intent: Intent) {
//            MainActivity().callMethodForServiceClass(mContext)
//        }
//    }
//
//    override fun onResume() {
//        super.onResume()
//        LocalBroadcastManager.getInstance(mContext).unregisterReceiver(broadcastReceiver)
//        LocalBroadcastManager.getInstance(mContext).registerReceiver(broadcastReceiver, IntentFilter(HomeButtonService().BROADCAST_ACTION))
//    }
//
//    override fun onPause() {
//        super.onPause()
//        LocalBroadcastManager.getInstance(mContext).unregisterReceiver(broadcastReceiver)
//    }
}
