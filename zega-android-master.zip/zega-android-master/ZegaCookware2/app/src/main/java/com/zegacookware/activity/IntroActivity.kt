package com.zegacookware.activity

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager.widget.ViewPager
import com.zegacookware.R
import com.zegacookware.adapter.IntroPagerAdapter
import com.zegacookware.network.Constant
import com.zegacookware.util.CommonUtility
import kotlinx.android.synthetic.main.activity_intro.*


class IntroActivity : AppCompatActivity() {

    private lateinit var dots: Array<TextView?>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_intro)

        if (CommonUtility.getBooleanPreference(Constant.isLoggedIn, this)) {
            startActivity(
                Intent(
                    this@IntroActivity,
                    MainActivity::class.java
                ).putExtra("isFromTimer", false)
            )
            finish()
            return
        }
        addBottomDots()
        updateBottomDots(0)
        viewpager.adapter = IntroPagerAdapter(this@IntroActivity)
//        indicator.setViewPager(viewpager)

        viewpager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {

            }

            override fun onPageSelected(position: Int) {
                if (position == 3) {
                    dotsLayout.visibility = View.GONE
                } else {
                    dotsLayout.visibility = View.VISIBLE
                }
                updateBottomDots(position)
            }

            override fun onPageScrollStateChanged(state: Int) {
            }

        })
    }

    private fun addBottomDots() {
        if (dotsLayout == null)
            return

        val dotSize = 4
        dotsLayout.removeAllViews()

        dots = arrayOfNulls<TextView>(dotSize)
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.setMargins(10, 10, 10, 10)
        for (i in dots.indices) {
            dots[i] = TextView(this)
            dots[i]?.height = 16
            dots[i]?.width = 16
            dots[i]?.layoutParams = params
            dots[i]?.setBackgroundResource(R.drawable.unselected_dot)
            dotsLayout.addView(dots[i])
        }
    }

    private fun updateBottomDots(curPosition: Int) {
        if (dots == null)
            return

        for (i in dots.indices) {
            if (curPosition == i) {
                dots[i]?.setBackgroundResource(R.drawable.selected_dot)
            } else {
                dots[i]?.setBackgroundResource(R.drawable.unselected_dot)
            }

        }
    }

}
