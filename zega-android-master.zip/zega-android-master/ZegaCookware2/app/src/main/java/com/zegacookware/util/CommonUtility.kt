package com.zegacookware.util

import android.animation.AnimatorSet
import android.animation.ValueAnimator
import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.location.LocationManager
import android.media.RingtoneManager
import android.net.ConnectivityManager
import android.os.Build
import android.preference.PreferenceManager
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.zegacookware.R
import com.zegacookware.activity.MainActivity
import com.zegacookware.activity.TimerActivity
import com.zegacookware.activity.bl.DigitalTimerActivity
import com.zegacookware.activity.manage_device.ManageDevicesActivity
import com.zegacookware.interfaces.ClickOnFavouritePopup
import com.zegacookware.interfaces.PopupWindowClick
import com.zegacookware.model.user.UserResult
import com.zegacookware.network.Constant
import com.zegacookware.service.DigitalTimerService
import com.zegacookware.util.blurBackground.BlurPopupWindowSignout
import com.zegacookware.util.blurBackground.BlurPopupWindowTemp
import com.zegacookware.util.blurBackground.TryAgainPopupWindow
import java.text.SimpleDateFormat
import java.util.*


object CommonUtility {
    /** Check if this device has a camera */
//    fun checkCameraHardware(context: Context): Boolean {
//        return context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA)
//    }

    fun setBooleanPreference(valueData: Boolean, key: String, context: Context) {
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        val editor = prefs.edit()
        editor.putBoolean(key, valueData)
        editor.commit()
    }

    fun getBooleanPreference(key: String, context: Context): Boolean {
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        return prefs.getBoolean(key, false)
    }


    fun setStringPreference(valueData: String, key: String, context: Context) {
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        val editor = prefs.edit()
        editor.putString(key, valueData)
        editor.apply()
    }

    fun getStringPreference(key: String, context: Context): String {
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        return prefs.getString(key, "")!!
    }

    fun showToast(mContext: Context, message: String) {
        Toast.makeText(
            mContext,
            message,
            Toast.LENGTH_SHORT
        ).show()
    }

    fun setUserData(userData: UserResult, key: String, context: Context) {
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        val editor = prefs.edit()
        val gson = Gson()
        val json = gson.toJson(userData)
        editor.putString(key, json)
        editor.apply()
    }

    //
    fun getUserData(key: String, context: Context): UserResult {
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        val gson = Gson()
        val json = prefs.getString(key, null)
        val type = object : TypeToken<UserResult>() {

        }.type
        return gson.fromJson<UserResult>(json, type)
    }

    fun isLocationEnabled(locationManager: LocationManager): Boolean {
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager!!.isProviderEnabled(
            LocationManager.NETWORK_PROVIDER
        )
    }

    @JvmStatic
    val EMAIL_REGEX = "^[A-Za-z](.*)([@]{1})(.{1,})(\\.)(.{1,})"

    fun isEmailValid(email: String): Boolean {
        return EMAIL_REGEX.toRegex().matches(email)
    }

    fun openDialog(msgString: String, buttonText: String, ids: Drawable, mContext: Context) {
        BlurPopupWindowTemp.Builder<BlurPopupWindowTemp>(
            mContext as Activity,
            msgString,
            buttonText,
            "",
            ids, object : ClickOnFavouritePopup {
                override fun onItemClick(position: Int, cusineType: String) {
                }
            }
        ).setContentView(R.layout.dialog_validation)
            .setGravity(Gravity.CENTER)
            .setScaleRatio(0.1f)
            .setBlurRadius(Constant.blurRadius)
            .build()
            .show()
    }

    fun openDialogForNotConnectedDevice(
        msgString: String,
        buttonText: String,
        ids: Drawable,
        mContext: Context
    ) {
        BlurPopupWindowTemp.Builder<BlurPopupWindowTemp>(
            mContext as Activity,
            msgString,
            buttonText,
            "",
            ids, object : ClickOnFavouritePopup {
                override fun onItemClick(position: Int, cusineType: String) {
                    mContext.startActivity(Intent(mContext, ManageDevicesActivity::class.java))
                }
            }
        ).setContentView(R.layout.dialog_no_devices_connected)
            .setGravity(Gravity.CENTER)
            .setScaleRatio(0.1f)
            .setBlurRadius(Constant.blurRadius)
            .build()
            .show()
    }

    fun openDialogForOutOfRangeDevice(
        msgString: String,
        buttonText: String,
        ids: Drawable,
        mContext: Context
    ) {
        TryAgainPopupWindow.Builder<TryAgainPopupWindow>(
            mContext as Activity,
            msgString,
            buttonText,
            "",
            ids, object : ClickOnFavouritePopup {
                override fun onItemClick(position: Int, cusineType: String) {
                    showProgressDialogTemp(mContext)
                    val mIntent = Intent(mContext, DigitalTimerService::class.java)
                    mContext.startService(mIntent)
                }
            }
        ).setContentView(R.layout.dialog_device_out_of_range)
            .setGravity(Gravity.CENTER)
            .setScaleRatio(0.1f)
            .setBlurRadius(Constant.blurRadius)
            .build()
            .show()
    }

    fun openDialogForCookingRunning(
        mContext: Context
    ) {
        BlurPopupWindowSignout.Builder<BlurPopupWindowSignout>(
            mContext as Activity,
            "RETURN",
            "Cancel",
            "A Recipe is already cooking. would you like to return to it?",
            "Cooking in progress",
            ContextCompat.getDrawable(mContext, R.drawable.ic_alert),
            object : PopupWindowClick {
                override fun onButton1Click() {
                    val isTemp1 = getBooleanPreference(
                        Constant.isShowTemperatureView,
                        mContext
                    )
                    LocalBroadcastManager.getInstance(mContext)
                        .sendBroadcast(Intent("AppIsBackground").putExtra("isBackground", true))

                    if (getBooleanPreference(Constant.isDigital, mContext)) {
                        val intent = Intent(
                            mContext,
                            DigitalTimerActivity::class.java
                        ).putExtra("isFromService", true)
                            .putExtra("isFromServiceForTimer", !isTemp1)
                        mContext.startActivity(intent)
                        ActivityCompat.finishAffinity(mContext as Activity)
                    } else {
                        val intent = Intent(
                            mContext,
                            TimerActivity::class.java
                        ).putExtra("isFromService", true)
                        mContext.startActivity(intent)
                    }

                }

                override fun onButton2Click() {

                }

            }
        ).setContentView(R.layout.dialog_logout)
            .setGravity(Gravity.CENTER)
            .setScaleRatio(0.1f)
            .setBlurRadius(Constant.blurRadius)
            .setDismissOnClickBack(false)
            .setDismissOnTouchBackground(false)
            .build()
            .show()
    }

    private fun openDialogForNoInternet(
        mContext: Context
    ) {
        BlurPopupWindowTemp.Builder<BlurPopupWindowTemp>(
            mContext as Activity,
            "THERE IS NO INTERNET CONNECTION",
            "TRY AGAIN",
            "",
            ContextCompat.getDrawable(mContext, R.drawable.ic_alert),
            object : ClickOnFavouritePopup {
                override fun onItemClick(position: Int, cusineType: String) {

                }
            }
        ).setContentView(R.layout.dialog_device_out_of_range)
            .setGravity(Gravity.CENTER)
            .setScaleRatio(0.1f)
            .setBlurRadius(Constant.blurRadius)
            .build()
            .show()
    }

    private var dialog: Dialog? = null
    fun showProgressDialog(mContext: Context) {
        dialog = Dialog(mContext)
        dialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog?.window?.setDimAmount(0.0f)
        dialog?.setContentView(R.layout.dialog_progress)
        dialog?.show()
    }

    fun showProgressDialogTemp(mContext: Context) {
        dialog = Dialog(mContext)
        dialog?.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog?.window?.setDimAmount(0.3f)
        dialog?.setContentView(R.layout.dialog_progress)
        dialog?.setCancelable(true)
        dialog?.show()
    }


    fun hideProgressBar() {
        if (dialog != null) {
            dialog?.dismiss()
        }
    }

    fun slideView(
        view: View,
        currentHeight: Int,
        newHeight: Int
    ) {

        var slideAnimator = ValueAnimator
            .ofInt(currentHeight, newHeight)
            .setDuration(100)

        /* We use an update listener which listens to each tick
         * and manually updates the height of the view  */
        slideAnimator.addUpdateListener {
            var value = it.animatedValue as Int
            view.layoutParams.height = value
            view.requestLayout()
        }

        /*  We use an animationSet to play the animation  */
        var animationSet = AnimatorSet()
        animationSet.interpolator = AccelerateDecelerateInterpolator()
        animationSet.play(slideAnimator);
        animationSet.start()
    }

    fun getUpdateTime(minutes: Int): String {
        val sdf = SimpleDateFormat("yyyy:MM:dd:HH:mm")
        var currentDateandTime = sdf.format(Date())
        var date = sdf.parse(currentDateandTime)
        val calendar = Calendar.getInstance()
        calendar.time = date
        calendar.add(Calendar.MINUTE, minutes)
        date = calendar.getTime()
        val sdf1 = SimpleDateFormat("HH:mm")
        currentDateandTime = sdf1.format(date)
        return currentDateandTime
    }

    fun sendNotification(title: String, message: String, mContext: Context) {

        val intent = Intent(mContext, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
        val pendingIntent = PendingIntent.getActivity(
            mContext, 0 /* Request code */, intent,
            PendingIntent.FLAG_UPDATE_CURRENT
        )

        val channelId = mContext.getString(R.string.default_notification_channel_id)
        val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val notificationBuilder = NotificationCompat.Builder(mContext, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(message)
            .setAutoCancel(true)
            .setSound(defaultSoundUri)
            .setContentIntent(pendingIntent)

        val notificationManager =
            mContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Since android Oreo notification channel is needed.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Zega",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            notificationManager.createNotificationChannel(channel)
        }

        notificationManager.notify(0 /* ID of notification */, notificationBuilder.build())
    }

    fun sendNotificationOutOfTheRange(title: String, message: String, mContext: Context) {
        val intent = Intent(mContext, DigitalTimerService::class.java)
//            .putExtra("isFromService", false)
//            .putExtra("isFromServiceForTimer", false)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        val pendingIntent = PendingIntent.getService(
            mContext, 0 /* Request code */, intent,
            PendingIntent.FLAG_UPDATE_CURRENT
        )

        val channelId = mContext.getString(R.string.default_notification_channel_id)
        val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val notificationBuilder = NotificationCompat.Builder(mContext, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(message)
            .setAutoCancel(true)
            .setSound(defaultSoundUri)
            .setContentIntent(pendingIntent)

        val notificationManager =
            mContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Since android Oreo notification channel is needed.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Zega",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            notificationManager.createNotificationChannel(channel)
        }

        notificationManager.notify(0 /* ID of notification */, notificationBuilder.build())
    }

    fun getDisplayContentHeight(activity: Activity): Int {
        val screenHeight = activity.resources.displayMetrics.heightPixels
        var statusBarHeight = 0
        val resource = activity.resources.getIdentifier("status_bar_height", "dimen", "android")
        if (resource > 0) {
            statusBarHeight = activity.resources.getDimensionPixelSize(resource)
        }
        return screenHeight - statusBarHeight
    }

    fun getConnectivityStatus(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork = cm.activeNetworkInfo
        return if (activeNetwork != null) {
            if (activeNetwork.isConnected) {
                true
            } else {
                openDialogForNoInternet(context)
                false
            }
        } else {
            openDialogForNoInternet(context)
            false
        }

    }


    @RequiresApi(Build.VERSION_CODES.M)
    fun scheduleJob(mContext: Context) {
//        val serviceComponent = ComponentName(mContext, TestJobService::class.java)
//        val builder =  JobInfo.Builder(0, serviceComponent)
//        builder.setMinimumLatency(1 * 10000); // wait at least
//        builder.setOverrideDeadline(3 * 10000); // maximum delay
//        //builder.setRequiredNetworkType(JobInfo.NETWORK_TYPE_UNMETERED); // require unmetered network
//        //builder.setRequiresDeviceIdle(true); // device should be idle
//        //builder.setRequiresCharging(false); // we don't care if the device is charging or not
//        val jobScheduler = mContext.getSystemService(JobScheduler::class.java);
//        jobScheduler.schedule(builder.build());
    }

}