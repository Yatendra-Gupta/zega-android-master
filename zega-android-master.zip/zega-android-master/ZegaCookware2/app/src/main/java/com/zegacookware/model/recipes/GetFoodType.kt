package com.zegacookware.model.recipes

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class GetFoodType {
    @SerializedName("type_result")
    @Expose
    var foodTypeResult: List<GetFoodTypeData>? = null
    @SerializedName("status")
    @Expose
    var status: Int? = null
}

class GetFoodTypeData {
    @SerializedName("food_type_id")
    @Expose
    var food_type_id: Int? = null
    @SerializedName("food_type_name")
    @Expose
    var food_type_name: String? = null
    @SerializedName("food_type_order")
    @Expose
    var food_type_order: Int? = null
}
