package com.zegacookware.model.user

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class UserInfo {
    @SerializedName("user_result")
    @Expose
    var userResult: UserResult? = null
    @SerializedName("devices_list")
    @Expose
    var devicesList: List<Any>? = null
    @SerializedName("status")
    @Expose
    var status: Int? = null
    @SerializedName("msg")
    @Expose
    var msg: String? = null
}
