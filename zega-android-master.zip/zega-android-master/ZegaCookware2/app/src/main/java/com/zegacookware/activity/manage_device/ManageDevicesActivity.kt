package com.zegacookware.activity.manage_device

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.zegacookware.R
import com.zegacookware.activity.BaseActivity
import com.zegacookware.adapter.DeviceListAdapter
import com.zegacookware.interfaces.PopupWindowClick
import com.zegacookware.interfaces.SetOnItemClickListener
import com.zegacookware.model.AddDeviceRequest
import com.zegacookware.model.UserDeviceList
import com.zegacookware.model.UserDevices
import com.zegacookware.model.recipes.recipesdetail.FavouriteResponse
import com.zegacookware.model.user.UserResult
import com.zegacookware.network.Constant
import com.zegacookware.util.CommonUtility
import com.zegacookware.util.blurBackground.PopupWindowRemoveDevice
import kotlinx.android.synthetic.main.activity_manage_devices.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ManageDevicesActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var userData: UserResult
    private lateinit var mContext: Context
    private var deviceList: ArrayList<UserDeviceList> = ArrayList()
    private lateinit var deviceListAdapter: DeviceListAdapter
    private lateinit var vibrator: Vibrator

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_devices)
        mContext = this
        userData = CommonUtility.getUserData(Constant.userInfo, mContext)
        vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
        btnAddNewDevices.setOnClickListener(this)
        ivBack.setOnClickListener(this)
        rvDevices.layoutManager = LinearLayoutManager(mContext) as RecyclerView.LayoutManager?
        rvDevices.setHasFixedSize(true)
        deviceListAdapter = DeviceListAdapter(
            mContext,
            deviceList,
            object : SetOnItemClickListener {
                override fun onItemClick(position: Int) {
                    openRemoveDeviceDialog(deviceList[position])
                }
            })
        rvDevices.adapter = deviceListAdapter
    }

    private fun getDevices() {
        CommonUtility.showProgressDialog(this@ManageDevicesActivity)
        Constant.service.getUserDevices(AddDeviceRequest(user_id = "" + userData.userId)).apply {
            enqueue(object : Callback<UserDevices> {
                override fun onFailure(call: Call<UserDevices>, t: Throwable) {
                    CommonUtility.hideProgressBar()
                }

                override fun onResponse(
                    call: Call<UserDevices>,
                    response: Response<UserDevices>
                ) {
                    CommonUtility.hideProgressBar()
                    deviceList.clear()
                    if (response.isSuccessful && response.body()?.status == 1) {
                        val diId = CommonUtility.getStringPreference(
                            "deviceId",
                            mContext
                        )
                        if (diId.isNullOrEmpty()) {
                            if (response.body()?.userDeviceList!![0].deviceName.equals(
                                    "digital",
                                    true
                                )
                            ) {
                                CommonUtility.setBooleanPreference(
                                    true,
                                    Constant.isDigital,
                                    mContext
                                )
                                CommonUtility.setStringPreference(
                                    response.body()?.userDeviceList!![0].macId!!,
                                    "deviceId",
                                    mContext
                                )
                            } else {
                                CommonUtility.setBooleanPreference(
                                    false,
                                    Constant.isDigital,
                                    mContext
                                )
                                CommonUtility.setStringPreference(
                                    response.body()?.userDeviceList!![0].deviceId!!,
                                    "deviceId",
                                    mContext
                                )
                            }
                        }
                        deviceList.addAll(response.body()?.userDeviceList!!)
                        deviceListAdapter.notifyDataSetChanged()
                        CommonUtility.setBooleanPreference(true, "isDeviceAvailable", mContext)
                    }
                }
            })
        }
    }

    private fun removeDevices(userDeviceList: UserDeviceList) {
        Constant.service.removeDevices(
            AddDeviceRequest(
                user_id = "" + userData.userId,
                user_device_id = "" + userDeviceList.userDeviceId!!
            )
        ).apply {
            enqueue(object : Callback<FavouriteResponse> {
                override fun onFailure(call: Call<FavouriteResponse>, t: Throwable) {

                }

                override fun onResponse(
                    call: Call<FavouriteResponse>,
                    response: Response<FavouriteResponse>
                ) {
                    if (response.isSuccessful && response.body()?.status == 1) {

//                        TempConnectHardware.disconnect()
//                        TempConnectHardware.close()
//                        stopService(Intent(mContext, TempConnectHardware::class.java))
                        BaseActivity.disconnect()
                        BaseActivity.close()

                        deviceList.remove(userDeviceList)
                        deviceListAdapter.notifyDataSetChanged()

                        if (deviceList[0].deviceName.equals("digital", true)) {
                            CommonUtility.setBooleanPreference(true, Constant.isDigital, mContext)
                            CommonUtility.setStringPreference(
                                deviceList[0].macId!!,
                                "deviceId",
                                mContext
                            )
                        } else {
                            CommonUtility.setBooleanPreference(false, Constant.isDigital, mContext)
                            CommonUtility.setStringPreference(
                                deviceList[0].deviceId!!,
                                "deviceId",
                                mContext
                            )
                        }

                    } else if (response.isSuccessful && response.body()?.status == 0) {
                        CommonUtility.setBooleanPreference(false, "isDeviceAvailable", mContext)
                        deviceList.clear()
                        deviceListAdapter.notifyDataSetChanged()
                    }
                }
            })
        }
    }

    override fun onClick(v: View?) {

        when (v?.id) {
            R.id.btnAddNewDevices -> {
                BaseActivity.disconnect()
                BaseActivity.close()
                startActivity(
                    Intent(
                        this,
                        DeviceSelectActivity::class.java
                    ).putExtra("isFromSignUp", false)
                )
            }
            R.id.ivBack -> {
                finish()
            }
        }
    }

    fun callVibration() {
        if (Build.VERSION.SDK_INT >= 26) {
            vibrator.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            vibrator.vibrate(200)
        }
    }

    override fun onResume() {
        super.onResume()
        getDevices()
    }


    private fun openRemoveDeviceDialog(userDeviceList: UserDeviceList) {
        PopupWindowRemoveDevice.Builder<PopupWindowRemoveDevice>(
            mContext as Activity,
            "YES",
            "NO",
            "WOULD YOU LIKE TO REMOVE '" + userData.name + "'S" + " ZEGA' FROM THE LIST?",
            ContextCompat.getDrawable(this, R.drawable.ic_alert)!!,
            object : PopupWindowClick {
                override fun onButton1Click() {
                    removeDevices(userDeviceList)
                }

                override fun onButton2Click() {
                }
            }
        ).setContentView(R.layout.dialog_remove_device)
            .setGravity(Gravity.CENTER)
            .setScaleRatio(0.1f)
            .setBlurRadius(Constant.blurRadius)
            .setDismissOnClickBack(true)
            .setDismissOnTouchBackground(true)
            .build()
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
    }

}
