package com.zegacookware.activity

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.drawable.Drawable
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.zegacookware.R
import com.zegacookware.activity.bl.DigitalTimerActivity
import com.zegacookware.interfaces.ClickOnFavouritePopup
import com.zegacookware.model.user.UserModel
import com.zegacookware.network.Constant
import com.zegacookware.service.DigitalTimerService
import com.zegacookware.util.CommonUtility
import com.zegacookware.util.blurBackground.BlurPopupWindowTemp
import com.zegacookware.util.blurBackground.CompleteCookingPopup


open class BaseActivity : AppCompatActivity() {

    private var mBluetoothDeviceAddress: String? = null
    private var isCallMethod: Boolean = false
    private var mp: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Thread.setDefaultUncaughtExceptionHandler(handleAppCrash)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        mContext = this

        if (!UserModel.isRegisterTheBroadcast) {
            Handler().postDelayed({
                if (!CommonUtility.getBooleanPreference(Constant.cookingIsRunning, mContext)) {
                    enableBluetooth()
                }
            }, 200)

            UserModel.isRegisterTheBroadcast = true
            LocalBroadcastManager.getInstance(this)
                .unregisterReceiver(broadcastReceiverTryAgain)
            LocalBroadcastManager.getInstance(this).registerReceiver(
                broadcastReceiverTryAgain, IntentFilter(
                    "TryAgain"
                )
            )
            LocalBroadcastManager.getInstance(this).unregisterReceiver(broadcastReceiverStopMp)
            LocalBroadcastManager.getInstance(this).registerReceiver(
                broadcastReceiverStopMp, IntentFilter(
                    "StopPlayer"
                )
            )

            LocalBroadcastManager.getInstance(this).unregisterReceiver(broadcastReceiver)
            LocalBroadcastManager.getInstance(this).registerReceiver(
                broadcastReceiver, IntentFilter(
                    "OpenCookingDialog"
                )
            )
        }
    }

    private val handleAppCrash = Thread.UncaughtExceptionHandler { thread, ex ->
        Log.e("error", ex.toString())
        //send email here
        CommonUtility.setBooleanPreference(
            false,
            Constant.cookingIsRunning,
            this@BaseActivity
        )
    }

    private val broadcastReceiverTryAgain = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
//            UserModel.isRegisterTheBroadcast = false
            openTryAgain()
        }
    }
    private val broadcastReceiverStopMp = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
//            UserModel.isRegisterTheBroadcast = false
            if (mp != null && mp!!.isPlaying) {
                isCallMethod = false
                mp?.stop()
            }
        }
    }

    fun openTryAgain() {
        CommonUtility.openDialogForOutOfRangeDevice(
            "THE CONNECTION TO YOUR DEVICE HAS BEEN LOST PLEASE ENSURE THAT YOU ARE WITHIN RANGE",
            "TRY AGAIN",
            ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
            mContext
        )
    }

    private val broadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
//            Log.d("B ============>>>>", "MainActivity")
//            UserModel.isRegisterTheBroadcast = false
            UserModel.isCallFromDevice = false
            callMethodForServiceClass(mContext)
        }
    }

    fun callMethodForServiceClass(mContext: Context) {
        if (!isCallMethod) {
            isCallMethod = true
            LocalBroadcastManager.getInstance(mContext)
                .sendBroadcast(Intent("AppIsBackground").putExtra("isBackground", true))

            mp = MediaPlayer.create(mContext, R.raw.alarm_clock)
            if (mp != null && !mp?.isPlaying!!) {
                try {
                    mp?.isLooping = true
                    mp?.start()
                } catch (e: Exception) {
                    mp?.release()
                }
            }
            if (CommonUtility.getBooleanPreference(
                    Constant.isDigital,
                    mContext
                ) && CommonUtility.getBooleanPreference(
                    Constant.isShowTemperatureView,
                    mContext
                )
            ) {
                openDialog(
                    "ZEGA HAS REACHED TEMPERATURE PLEASE\nREMOVE FROM HEAT",
                    "START SELF COOKING",
                    ContextCompat.getDrawable(
                        mContext,
                        R.drawable.ic_right
                    )!!,
                    mContext,
                    true
                )
            } else {
                CommonUtility.setBooleanPreference(false, Constant.cookingIsRunning, mContext)
                openDialog(
                    "COOKING COMPLETE",
                    "DONE",
                    ContextCompat.getDrawable(
                        mContext,
                        R.drawable.ic_right
                    )!!,
                    mContext,
                    false
                )
                CommonUtility.sendNotification(
                    "Zega",
                    "COOKING COMPLETE",
                    mContext
                )
            }
        }
    }

    fun openDialog(
        msgString: String,
        buttonText: String,
        ids: Drawable,
        mContext: Context,
        isTemp: Boolean
    ) {
        CompleteCookingPopup.Builder<CompleteCookingPopup>(
            mContext as Activity,
            msgString,
            buttonText,
            "",
            ids, object : ClickOnFavouritePopup {
                override fun onItemClick(position: Int, cusineType: String) {
                    UserModel.isCallFromDevice = true
                    isCallMethod = false
                    if (mp != null) {
                        mp?.stop()
                        mp?.release()
                    }
                    if (isTemp) {
                        CommonUtility.setBooleanPreference(
                            false,
                            Constant.isShowTemperatureView,
                            mContext
                        )
                        CommonUtility.setStringPreference("0", "count", mContext)
                        LocalBroadcastManager.getInstance(mContext).sendBroadcast(
                            Intent("isFromServiceForTimer11").putExtra(
                                "isFromServiceForTimer",
                                true
                            )
                        )
                        val intent = Intent(
                            mContext,
                            DigitalTimerActivity::class.java
                        ).putExtra("isFromService", true)
                            .putExtra("isFromServiceForTimer", true)
                        intent.flags =
                            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        mContext.startActivity(intent)
                    } else {
                        LocalBroadcastManager.getInstance(mContext).sendBroadcast(
                            Intent("isFromServiceForTimer11").putExtra(
                                "isFromServiceForTimer",
                                false
                            )
                        )
                    }
                }
            }
        ).setContentView(R.layout.dialog_validation)
            .setGravity(Gravity.CENTER)
            .setScaleRatio(0.1f)
            .setBlurRadius(Constant.blurRadius)
            .setDismissOnClickBack(false)
            .setDismissOnTouchBackground(false)
            .build()
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            Runtime.getRuntime().gc()
        } catch (e: Exception) {

        }
    }

    private fun enableBluetooth() {
        val mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        if (!mBluetoothAdapter!!.isEnabled) {
            val enableBTIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivity(enableBTIntent)
        } else {

        }
    }


    companion object {
        private var mBluetoothGatt: BluetoothGatt? = null
        private var mBluetoothDeviceAddress: String? = null
        private lateinit var mContext: Context
        fun disconnect() {
            if (mBluetoothGatt == null) {
                Log.w("", "BluetoothAdapter not initialized")
                return
            }
            mBluetoothGatt!!.disconnect()
        }

        fun close() {
            if (mBluetoothGatt == null) {
                return
            }
            mBluetoothGatt!!.close()
            mBluetoothGatt = null
        }

        fun connectHardware() {
            val mDeviceAddress = CommonUtility.getStringPreference(
                "deviceId",
                mContext
            )
            if (CommonUtility.getBooleanPreference(Constant.isDigital, mContext)) {
                connect(mDeviceAddress)
            }
        }

        private fun connect(address: String?): Boolean {
            val mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
            if (address == null) {
                Log.w("", "BluetoothAdapter not initialized or unspecified address.")
                return false
            }

            // Previously connected device.  Try to reconnect.
            if (mBluetoothDeviceAddress != null && address == mBluetoothDeviceAddress
                && mBluetoothGatt != null
            ) {
                Log.d("", "Trying to use an existing mBluetoothGatt for connection.")
                return mBluetoothGatt!!.connect()
            }

            val device = mBluetoothAdapter?.getRemoteDevice(address)
            if (device == null) {
                Log.w("", "Device not found.  Unable to connect.")
                Toast.makeText(mContext, "Device not fount. Unable to connect.", Toast.LENGTH_LONG)
                    .show()
                return false
            }
            // We want to directly connect to the device, so we are setting the autoConnect
            // parameter to false.
            mBluetoothGatt = device.connectGatt(mContext, false, mGattCallback)
            Log.d("", "Trying to create a new connection.")
            mBluetoothDeviceAddress = address
//        mConnectionState = STATE_CONNECTING
            return true
        }

        private val mGattCallback = object : BluetoothGattCallback() {
            override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            }

            override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
                if (status == BluetoothGatt.GATT_SUCCESS) {
                } else {
                    Log.d("", "onServicesDiscovered received: $status")
                }
            }

            override fun onCharacteristicRead(
                gatt: BluetoothGatt,
                characteristic: BluetoothGattCharacteristic,
                status: Int
            ) {
            }

            override fun onCharacteristicWrite(
                gatt: BluetoothGatt,
                characteristic: BluetoothGattCharacteristic,
                status: Int
            ) {
            }

            override fun onCharacteristicChanged(
                gatt: BluetoothGatt,
                characteristic: BluetoothGattCharacteristic
            ) {
            }

            override fun onReadRemoteRssi(gatt: BluetoothGatt, rssi: Int, status: Int) {

            }
        }

        fun openJobScheduler(mContext: Context) {
            Handler(Looper.getMainLooper()).postDelayed({
                if (CommonUtility.getBooleanPreference(
                        Constant.cookingIsRunning,
                        mContext
                    ) && UserModel.isHardwareOutOfRange
                ) {
                    reconnectService(mContext)

                    Handler(Looper.getMainLooper()).postDelayed({
                        if (UserModel.isHardwareOutOfRange) {
                            openJobScheduler(mContext)
                        }
                    }, 10000)

                    Log.e("Service ====>  ", "reconnect")
                } else if (CommonUtility.getBooleanPreference(
                        Constant.cookingIsRunning,
                        mContext
                    )
                ) {
                    openJobScheduler(mContext)
                    Log.e("Service ====>  ", "auto_reconnect")
                }
//                Log.e("OpenService","======>>>>")
            }, 15000)
        }

        private fun reconnectService(mContext: Context) {
            val mIntent = Intent(mContext, DigitalTimerService::class.java)
            mContext.startService(mIntent)
        }
    }
}