package com.zegacookware.activity

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.provider.Settings
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import androidx.viewpager.widget.ViewPager
import com.zegacookware.R
import com.zegacookware.activity.bl.DigitalTimerActivity
import com.zegacookware.adapter.StartCookingAnaloguePagerAdapter
import com.zegacookware.adapter.StartCookingPagerAdapter
import com.zegacookware.interfaces.PopupWindowClick
import com.zegacookware.network.Constant
import com.zegacookware.util.CommonUtility
import com.zegacookware.util.blurBackground.BlurPopupWindowSignout
import kotlinx.android.synthetic.main.activity_intro.dotsLayout
import kotlinx.android.synthetic.main.activity_intro.viewpager
import kotlinx.android.synthetic.main.activity_start_cooking.*


class StartCookingSliderActivity : BaseActivity() {

    private lateinit var dots: Array<TextView?>
    private var dotSize: Int = 0
    private lateinit var mContext: Context;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_start_cooking)
        mContext = this
        back.setOnClickListener { finish() }
        addBottomDots()
        updateBottomDots(0)
        if (CommonUtility.getBooleanPreference(
                Constant.isDigital,
                this@StartCookingSliderActivity
            )
        ) {
            viewpager.adapter =
                StartCookingPagerAdapter(
                    mContext,
                    intent.getStringExtra("id")
                )
        } else {
            viewpager.adapter =
                StartCookingAnaloguePagerAdapter(
                    mContext,
                    intent.getStringExtra("id")
                )
        }
        viewpager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {

            }

            override fun onPageSelected(position: Int) {
                updateBottomDots(position)
            }

            override fun onPageScrollStateChanged(state: Int) {
            }

        })
    }

    @RequiresApi(Build.VERSION_CODES.M)
    fun openPermissionDialog(mContext: Context) {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${mContext.packageName}")
        )
        (mContext as Activity).startActivityForResult(intent, 2080)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 2080) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

                if (Settings.canDrawOverlays(this)) {
                    Handler().postDelayed({
                        if (CommonUtility.getBooleanPreference(
                                Constant.isDigital,
                                this@StartCookingSliderActivity
                            )
                        ) {
                            val mIntent = Intent(
                                this@StartCookingSliderActivity,
                                DigitalTimerActivity::class.java
                            )
                            mIntent.putExtra("isFromService", false)
                                .putExtra("isFromServiceForTimer", false)
                            mIntent.flags =
                                Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                            startActivity(mIntent)
                            finishAffinity()
                        } else {
                            val mIntent = Intent(
                                mContext,
                                TimerActivity::class.java
                            )
                            mIntent.putExtra("isFromService", false)
                            mIntent.flags =
                                Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                            startActivity(mIntent)
                        }
                        finishAffinity()
                    }, 500)
                } else { //Permission is not available
                    Toast.makeText(
                        this@StartCookingSliderActivity,
                        "Permission is required for the browse the cooking progress",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    fun openDialogForAllowPermission(
        mContext: Context
    ) {
        BlurPopupWindowSignout.Builder<BlurPopupWindowSignout>(
            mContext as Activity,
            "Allow",
            "Cancel",
            "Please allow Zega to monitor your cooking whilst you’re away from the app.",
            "",
            ContextCompat.getDrawable(mContext, R.drawable.ic_right),
            object : PopupWindowClick {
                @RequiresApi(Build.VERSION_CODES.M)
                override fun onButton1Click() {
                    openPermissionDialog(mContext)
                }

                override fun onButton2Click() {

                }

            }
        ).setContentView(R.layout.dialog_logout)
            .setGravity(Gravity.CENTER)
            .setScaleRatio(0.1f)
            .setBlurRadius(Constant.blurRadius)
            .setDismissOnClickBack(false)
            .setDismissOnTouchBackground(false)
            .build()
            .show()
    }

    fun changePages(position: Int) {
        updateBottomDots(position)
        viewpager.currentItem = position
    }

    private fun addBottomDots() {
        if (dotsLayout == null)
            return

        dotSize = if (CommonUtility.getBooleanPreference(
                Constant.isDigital,
                this@StartCookingSliderActivity
            )
        ) {
            2
        } else {
            4
        }
        dotsLayout.removeAllViews()

        dots = arrayOfNulls<TextView>(dotSize)
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.setMargins(10, 10, 10, 10)
        for (i in dots.indices) {
            dots[i] = TextView(this)
            dots[i]?.height = 16
            dots[i]?.width = 16
            dots[i]?.layoutParams = params
            dots[i]?.setBackgroundResource(R.drawable.unselected_dot_gray)
            dotsLayout.addView(dots[i])
        }
    }

    private fun updateBottomDots(curPosition: Int) {
        if (dots == null)
            return

        for (i in dots.indices) {
            if (curPosition == i) {
                dots[i]?.setBackgroundResource(R.drawable.selected_dot_gray)
            } else {
                dots[i]?.setBackgroundResource(R.drawable.unselected_dot_gray)
            }

        }
    }

}
