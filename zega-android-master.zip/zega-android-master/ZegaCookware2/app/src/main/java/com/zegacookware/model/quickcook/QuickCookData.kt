package com.zegacookware.model.quickcook

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class QuickCookData {
    @SerializedName("recepie_category_name")
    @Expose
    var recepieCategoryName: String? = null
    @SerializedName("recepie_image")
    @Expose
    var recepieImage: String? = null
    @SerializedName("quick_id")
    @Expose
    var quickId: Int? = null
    @SerializedName("recepie_category_id")
    @Expose
    var recepieCategoryId: Int? = null
    @SerializedName("quick_recepie_time")
    @Expose
    var quickRecepieTime: String? = null
    @SerializedName("quick_recepie_temperature")
    @Expose
    var quickRecepieTemperature: String? = null
    @SerializedName("reorder_quick_cook")
    @Expose
    var reorderQuickCook: Int? = null
    @SerializedName("status")
    @Expose
    var status: String? = null
    @SerializedName("deleted")
    @Expose
    var deleted: String? = null
    @SerializedName("created_by")
    @Expose
    var createdBy: Int? = null
    @SerializedName("created_at")
    @Expose
    var createdAt: String? = null
    @SerializedName("updated_by")
    @Expose
    var updatedBy: Int? = null
    @SerializedName("updated_at")
    @Expose
    var updatedAt: String? = null
    @SerializedName("deleted_at")
    @Expose
    var deletedAt: Any? = null
}
