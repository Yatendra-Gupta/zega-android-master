package com.zegacookware.adapter

import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.appcompat.widget.AppCompatButton
import androidx.viewpager.widget.PagerAdapter
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.zegacookware.R
import com.zegacookware.activity.StartCookingSliderActivity
import com.zegacookware.activity.TimerActivity
import com.zegacookware.model.CookingSliderAnalogueModel

class StartCookingAnaloguePagerAdapter(var mContext: Context, var id: String) : PagerAdapter() {

    override fun instantiateItem(collection: ViewGroup, position: Int): Any {
        val modelObject = CookingSliderAnalogueModel.values()[position]
        val inflater = LayoutInflater.from(mContext)
        val layout = inflater.inflate(modelObject.layoutResId, collection, false) as ViewGroup
        val ivGif = layout.findViewById<ImageView>(R.id.ivGif)
        val btnStartCooking1 = layout.findViewById<AppCompatButton>(R.id.btnStartCooking1)
        when {
            modelObject.layoutResId == R.layout.layout_start_cooking1 -> {
                Glide.with(mContext).asGif().load(
                    R.raw.add_ingredients
                ).apply(
                    RequestOptions.diskCacheStrategyOf(
                        DiskCacheStrategy.NONE
                    )
                ).into(ivGif)
                val btnForward = layout.findViewById<ImageView>(R.id.btnForward1)
                btnForward.setOnClickListener {
                    (mContext as StartCookingSliderActivity).changePages(
                        1
                    )
                }
            }
            modelObject.layoutResId == R.layout.layout_start_cooking2 -> {
                Glide.with(mContext).asGif().load(
                    R.raw.turn_on_stove
                ).apply(
                    RequestOptions.diskCacheStrategyOf(
                        DiskCacheStrategy.NONE
                    )
                ).into(ivGif)
                val btnForward = layout.findViewById<ImageView>(R.id.btnForward2)
                val btnBack2 = layout.findViewById<ImageView>(R.id.btnBack2)

                btnForward.visibility = View.VISIBLE
                btnStartCooking1.visibility = View.INVISIBLE
                btnForward.setOnClickListener {
                    (mContext as StartCookingSliderActivity).changePages(
                        2
                    )
                }
                btnBack2.setOnClickListener {
                    (mContext as StartCookingSliderActivity).changePages(
                        0
                    )
                }
            }
            modelObject.layoutResId == R.layout.layout_start_cooking3 -> {
                Glide.with(mContext).asGif().load(
                    R.raw.analogue_heat_up
                ).apply(
                    RequestOptions.diskCacheStrategyOf(
                        DiskCacheStrategy.NONE
                    )
                ).into(ivGif)
                val btnForward = layout.findViewById<ImageView>(R.id.btnForward3)
                val btnBack3 = layout.findViewById<ImageView>(R.id.btnBack3)
                btnBack3.setOnClickListener {
                    (mContext as StartCookingSliderActivity).changePages(
                        1
                    )
                }
                btnForward.setOnClickListener {
                    (mContext as StartCookingSliderActivity).changePages(
                        3
                    )
                }
            }
            modelObject.layoutResId == R.layout.layout_start_cooking4 -> {
                Glide.with(mContext).asGif().load(R.raw.remove_pan_from_heat).apply(
                    RequestOptions.diskCacheStrategyOf(
                        DiskCacheStrategy.NONE
                    )
                ).into(ivGif)
                val btnBack4 = layout.findViewById<ImageView>(R.id.btnBack4)

                btnBack4.setOnClickListener {
                    (mContext as StartCookingSliderActivity).changePages(
                        2
                    )
                }
                btnStartCooking1.setOnClickListener {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (Settings.canDrawOverlays(mContext)) {
                            val mIntent = Intent(
                                mContext,
                                TimerActivity::class.java
                            )
                            mIntent.putExtra("isFromService", false)
                            mIntent.flags =
                                Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                            mContext.startActivity(mIntent)
                        } else {
                            StartCookingSliderActivity().openDialogForAllowPermission(mContext)
                        }
                    } else {
                        val mIntent = Intent(
                            mContext,
                            TimerActivity::class.java
                        )
                        mIntent.putExtra("isFromService", false)
                        mIntent.flags =
                            Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                        mContext.startActivity(mIntent)
                    }
                }
            }
        }
        collection.addView(layout)

        return layout
    }

    override fun destroyItem(collection: ViewGroup, position: Int, view: Any) {
        collection.removeView(view as View)
    }

    override fun getCount(): Int {
        return CookingSliderAnalogueModel.values().size
    }

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return view === `object`
    }

//    override fun getPageTitle(position: Int): CharSequence {
//        val customPagerEnum = IntroSliderModel.values()[position]
//        return mContext.getString(customPagerEnum.titleResId)
//    }
}