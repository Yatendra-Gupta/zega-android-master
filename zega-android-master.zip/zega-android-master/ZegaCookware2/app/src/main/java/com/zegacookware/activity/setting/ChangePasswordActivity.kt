package com.zegacookware.activity.setting

import android.app.Activity
import android.content.Context
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.view.Gravity
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.zegacookware.interfaces.ClickOnFavouritePopup
import com.zegacookware.util.CommonUtility
import com.zegacookware.R
import com.zegacookware.model.recipes.recipesdetail.FavouriteResponse
import com.zegacookware.model.user.ChangePasswordRequest
import com.zegacookware.model.user.UserResult
import com.zegacookware.network.Constant
import com.zegacookware.util.blurBackground.BlurPopupWindowTemp
import kotlinx.android.synthetic.main.activity_change_password.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ChangePasswordActivity : AppCompatActivity() {

    private lateinit var userData: UserResult
    private lateinit var mContext: Context

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_password)

        mContext = this@ChangePasswordActivity
        userData = CommonUtility.getUserData(Constant.userInfo, this@ChangePasswordActivity)

        ivBack.setOnClickListener { finish() }



        btnChange.setOnClickListener {

            if (etOldPassword.text.toString().isEmpty()) {
                CommonUtility.openDialog(
                    "PLEASE ENTER YOUR OLD PASSWORD",
                    "OK",
                    ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
                    mContext
                )
                return@setOnClickListener
            }
//            if (etOldPassword.text.toString().length < 8) {
//                CommonUtility.openDialog(
//                    "PLEASE ENTER ATLEAST 8 CHARACTER PASSWORD",
//                    "OK",
//                    ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
//                    mContext
//                )
//                return@setOnClickListener
//            }
            if (etNewPassword.text.toString().isEmpty()) {
                CommonUtility.openDialog(
                    "PLEASE ENTER PASSWORD",
                    "OK",
                    ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
                    mContext
                )
                return@setOnClickListener
            }
            if (etNewPassword.text.toString().length < 8) {
                CommonUtility.openDialog(
                    "PLEASE ENTER ATLEAST 8 CHARACTER PASSWORD",
                    "OK",
                    ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
                    mContext
                )
                return@setOnClickListener
            }

            if (etConfirmPassword.text.toString().isEmpty()) {
                CommonUtility.openDialog(
                    "PLEASE ENTER PASSWORD AGAIN TO CONFIRM",
                    "OK",
                    ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
                    mContext
                )
                return@setOnClickListener
            }
            if (!etNewPassword.text.toString().equals(etConfirmPassword.text.toString(), false)) {

                etNewPassword.setText("")
                etConfirmPassword.setText("")

                CommonUtility.openDialog(
                    "PASSWORDS DO NOT MATCH, PLEASE RE-ENTER",
                    "OK",
                    ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
                    mContext
                )
                return@setOnClickListener
            }

            Constant.service.changePassword(
                ChangePasswordRequest(
                    old_pass = etOldPassword.text.toString().trim(),
                    new_pass = etNewPassword.text.toString().trim(),
                    user_id = "" + userData.userId
                )
            ).apply {
                enqueue(object : Callback<FavouriteResponse> {
                    override fun onFailure(call: Call<FavouriteResponse>, t: Throwable) {
                    }

                    override fun onResponse(
                        call: Call<FavouriteResponse>,
                        response: Response<FavouriteResponse>
                    ) {
                        if (response.isSuccessful && response.body()?.status == 1) {

                            CommonUtility.setStringPreference(
                                etNewPassword.text.toString(),
                                "password",
                                this@ChangePasswordActivity
                            )

                            openDialog(
                                response.body()?.msg!!,
                                "Done",
                                ContextCompat.getDrawable(mContext, R.drawable.ic_right)!!,
                                this@ChangePasswordActivity
                            )
                        } else if (response.isSuccessful && response.body()?.status == 0) {
                            CommonUtility.openDialog(
                                response.body()?.msg!!,
                                "OK",
                                ContextCompat.getDrawable(mContext, R.drawable.ic_alert)!!,
                                mContext
                            )
                        }
                    }
                })
            }
        }



        btnShowPass.setOnClickListener {
            if (ContextCompat.getDrawable(
                    mContext,
                    R.drawable.eye_show
                )!!.constantState == btnShowPass.drawable.constantState
            ) {
                etNewPassword.transformationMethod = PasswordTransformationMethod.getInstance()
                btnShowPass.setImageDrawable(
                    ContextCompat.getDrawable(
                        mContext,
                        R.drawable.eye_hide
                    )
                )
            } else {
                etNewPassword.transformationMethod = HideReturnsTransformationMethod.getInstance()
                btnShowPass.setImageDrawable(
                    ContextCompat.getDrawable(
                        mContext,
                        R.drawable.eye_show
                    )
                )
            }
            etNewPassword.placeCursorToEnd()
        }
        btnShowOldPass.setOnClickListener {
            if (ContextCompat.getDrawable(
                    mContext,
                    R.drawable.eye_show
                )!!.constantState == btnShowOldPass.drawable.constantState
            ) {
                etOldPassword.transformationMethod = PasswordTransformationMethod.getInstance()
                btnShowOldPass.setImageDrawable(
                    ContextCompat.getDrawable(
                        mContext,
                        R.drawable.eye_hide
                    )
                )
            } else {
                etOldPassword.transformationMethod = HideReturnsTransformationMethod.getInstance()
                btnShowOldPass.setImageDrawable(
                    ContextCompat.getDrawable(
                        mContext,
                        R.drawable.eye_show
                    )
                )
            }
            etOldPassword.placeCursorToEnd()
        }
        btnShowConfPass.setOnClickListener {
            if (ContextCompat.getDrawable(
                    mContext,
                    R.drawable.eye_show
                )!!.constantState == btnShowConfPass.drawable.constantState
            ) {
                etConfirmPassword.transformationMethod = PasswordTransformationMethod.getInstance()
                btnShowConfPass.setImageDrawable(
                    ContextCompat.getDrawable(
                        mContext,
                        R.drawable.eye_hide
                    )
                )
            } else {
                etConfirmPassword.transformationMethod =
                    HideReturnsTransformationMethod.getInstance()
                btnShowConfPass.setImageDrawable(
                    ContextCompat.getDrawable(
                        mContext,
                        R.drawable.eye_show
                    )
                )
            }
            etConfirmPassword.placeCursorToEnd()
        }

//        etConfirmPassword.setOnClickListener {
//            if (ContextCompat.getDrawable(
//                    mContext,
//                    R.drawable.eye_hide
//                )!!.constantState == btnShowConfPass.drawable.constantState
//            ) {
//                etConfirmPassword.setText("")
//            }
//        }
//        etOldPassword.setOnClickListener {
//            if (ContextCompat.getDrawable(
//                    mContext,
//                    R.drawable.eye_hide
//                )!!.constantState == btnShowOldPass.drawable.constantState
//            ) {
//                etOldPassword.setText("")
//            }
//        }
//        etNewPassword.setOnClickListener {
//            if (ContextCompat.getDrawable(
//                    mContext,
//                    R.drawable.eye_hide
//                )!!.constantState == btnShowPass.drawable.constantState
//            ) {
//                etNewPassword.setText("")
//            }
//        }
    }

    private fun EditText.placeCursorToEnd() {
        this.setSelection(this.text.length)
    }

    fun openDialog(msgString: String, buttonText: String, ids: Drawable, mContext: Context) {
        BlurPopupWindowTemp.Builder<BlurPopupWindowTemp>(
            mContext as Activity,
            msgString,
            buttonText,
            "",
            ids, object : ClickOnFavouritePopup {
                override fun onItemClick(position: Int, cusineType: String) {
                    finish()
                }
            }
        ).setContentView(R.layout.dialog_validation)
            .setGravity(Gravity.CENTER)
            .setScaleRatio(0.1f)
            .setBlurRadius(Constant.blurRadius)
            .setDismissOnTouchBackground(false)
            .setDismissOnClickBack(false)
            .build()
            .show()
    }

}
