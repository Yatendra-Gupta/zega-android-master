package com.zegacookware.activity

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.trading212.diverserecycleradapter.layoutmanager.DiverseLinearLayoutManager
import com.zegacookware.R
import com.zegacookware.fragment.PopupWindowFilter
import com.zegacookware.interfaces.ClickOnFavouritePopup
import com.zegacookware.model.recipes.*
import com.zegacookware.model.user.UserResult
import com.zegacookware.network.Constant
import com.zegacookware.util.CommonUtility
import com.zegacookware.widget.item.ItemType
import com.zegacookware.widget.stickyheader.StickyHeader
import com.zegacookware.widget.stickyheader.StickyHeaderDecoration
import kotlinx.android.synthetic.main.activity_show_all.*
import kotlinx.android.synthetic.main.item_recipes_title.view.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class ShowAllRecipesActivity : BaseActivity(),
    View.OnClickListener {

    private val items: ArrayList<RecyclerItem> = ArrayList()
    private lateinit var userData: UserResult
    private lateinit var adapter: RecipesRecyclerAdapter
    private lateinit var mContext: Context
    private val allRecipesList: ArrayList<TitleResult> = ArrayList()
    private val allRecipesListTemp: ArrayList<TitleResult> = ArrayList()

    private val getFoodTypeLst: ArrayList<GetFoodTypeData> = ArrayList()
    private var isSticky: Boolean = true
    private var isNotShowListIcon: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_all)
        mContext = this

        userData = CommonUtility.getUserData(Constant.userInfo, this@ShowAllRecipesActivity)
        rvRecipesTitle.layoutManager = DiverseLinearLayoutManager(this)
        rvRecipesTitle.setHasFixedSize(true)
        adapter = RecipesRecyclerAdapter(mContext, false)
        getFoodTypeList()
        ivBack.setOnClickListener { finish() }
        btnFilter.setOnClickListener(this)
        btnGridList.setOnClickListener(this)
        if (intent.getBooleanExtra("isFromFilter", false)) {
            callFilterMethod()
        } else {
            getAllRecipesList()
        }
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btnFilter -> {
                if (getFoodTypeLst.isNotEmpty()) {
                    openDialog(mContext)
                }
            }
            R.id.btnGridList -> {
                if (!isNotShowListIcon) {
                    if (allRecipesList.isNotEmpty()) {
                        isNotShowListIcon = true
                        btnGridList.setImageDrawable(
                            ContextCompat.getDrawable(
                                mContext,
                                R.drawable.ic_grid_icon
                            )
                        )
                        setStickyLis(false)
                        isSticky = false
                    }
                } else {
                    if (allRecipesList.isNotEmpty()) {
                        isNotShowListIcon = false
                        btnGridList.setImageDrawable(
                            ContextCompat.getDrawable(
                                mContext,
                                R.drawable.ic_list_recipes
                            )
                        )
                        setStickyLis(true)
                        isSticky = true
                    }
                }
            }
        }

    }

    private fun setStickyLis(isShowGrid: Boolean) {
        items.clear()
        for (i in 0 until allRecipesList.size) {
            items.add(
                RecyclerItem(
                    title = allRecipesList[i].recepieCategoryName!!,
                    isSticky = true
                )
            )
            val recipesRecyclerItems =
                allRecipesList[i].recepieTitle!!.map { RecyclerItem("", false, it) }
            items.addAll(recipesRecyclerItems)
        }

        adapter.items = items
        adapter.isGrid = isShowGrid
        rvRecipesTitle.adapter = adapter
        rvRecipesTitle.setHasFixedSize(true)
        rvRecipesTitle.addItemDecoration(StickyHeaderDecoration())
        adapter.notifyDataSetChanged()
    }

    data class RecyclerItem(
        val title: String,
        val isSticky: Boolean = false,
        val recipesTitle: RecepieTitle? = null
    )

    class RecipesRecyclerAdapter(val mContext: Context, private val isShowGrid: Boolean) :
        RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        var isGrid: Boolean = true
        var items: List<RecyclerItem> = listOf()
        var view: View? = null
        override fun getItemCount(): Int = items.size

        override fun getItemViewType(position: Int) =
            if (items[position].isSticky) {
                STICKY_ITEM_TYPE
            } else {
                TEXT_ITEM_TYPE
            }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val isStickyItem = viewType == STICKY_ITEM_TYPE

            val layoutInflater = LayoutInflater.from(parent.context)

            return if (isStickyItem) {
                StickyViewHolder(layoutInflater.inflate(R.layout.item_sticky_text, parent, false))
            } else {
                TextViewHolder(layoutInflater.inflate(R.layout.item_recipes_title, parent, false))
            }
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            if (holder is TextViewHolder) {
                if (items[position].isSticky) {
                    holder.textView.text = items[position].title
                    holder.itemView.isClickable = false
                } else {
                    holder.itemView.isClickable = true
                    if (isGrid) {
                        holder.itemView.lytWithText.visibility = View.GONE
                        holder.itemView.lytWithImage.visibility = View.VISIBLE
                        holder.itemView.divider.visibility = View.GONE
                    } else {
                        holder.itemView.lytWithText.visibility = View.VISIBLE
                        holder.itemView.lytWithImage.visibility = View.GONE
                        holder.itemView.divider.visibility = View.VISIBLE
                    }
                    holder.itemView.tvRecipesImage.text = items[position].recipesTitle?.recepieTitle
                    Glide.with(mContext)
                        .load(Constant.recipesImageBaseUrl + items[position].recipesTitle?.recepieImage)
                        .centerCrop()
                        .into(holder.itemView.ivRecipes1)

                    holder.itemView.tvRecipesTitle.text = items[position].recipesTitle?.recepieTitle

                    if (position == items.size - 1) {
                        holder.itemView.divider.visibility = View.GONE
                    }

                    holder.itemView.setOnClickListener {
                        mContext.startActivity(
                            Intent(mContext, RecipesDetailsActivity::class.java)
                                .putExtra(
                                    "id",
                                    items[position].recipesTitle?.recepieId
                                )
                        )
                    }
                    if (position != items.size - 1 && items[position + 1].isSticky) {
                        holder.itemView.divider.visibility = View.GONE
                    }

                }

            }
        }

        inner class StickyViewHolder(itemView: View) : TextViewHolder(itemView), StickyHeader {
            override val stickyId: String
                get() = items[adapterPosition].title
        }

        open inner class TextViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val textView: TextView = itemView.findViewById(R.id.tvRecipesTitle)
        }

        companion object {
            val STICKY_ITEM_TYPE = ItemType.STICKY.ordinal

            val TEXT_ITEM_TYPE = ItemType.SIMPLE_TEXT.ordinal
        }
    }


    private fun getAllRecipesList() {
        CommonUtility.showProgressDialog(mContext)
        Constant.service.getRecipeTitleWithCategoryMethod().apply {
            enqueue(object : Callback<AllRecipes> {
                override fun onFailure(call: Call<AllRecipes>, t: Throwable) {
                    CommonUtility.hideProgressBar()
                }

                override fun onResponse(
                    call: Call<AllRecipes>,
                    response: Response<AllRecipes>
                ) {
                    CommonUtility.hideProgressBar()
                    if (response.isSuccessful && response.body()?.status == 1) {
                        allRecipesListTemp.clear()
                        allRecipesList += response.body()?.titleResult!!
                        allRecipesListTemp.addAll(allRecipesList)
                        setStickyLis(true)
                    }
                }

            })
        }
    }

    private fun getFoodTypeList() {
        Constant.service.getFoodType().apply {
            enqueue(object : Callback<GetFoodType> {
                override fun onFailure(call: Call<GetFoodType>, t: Throwable) {

                }

                override fun onResponse(
                    call: Call<GetFoodType>,
                    response: Response<GetFoodType>
                ) {
                    if (response.isSuccessful && response.body()?.status == 1) {
                        getFoodTypeLst += response.body()?.foodTypeResult!!
                    }
                }

            })
        }
    }

    private fun openDialog(mContext: Context) {
        PopupWindowFilter.Builder<PopupWindowFilter>(
            mContext as Activity, getFoodTypeLst, object :
                ClickOnFavouritePopup {
                override fun onItemClick(position: Int, cusineType: String) {
                    if (cusineType.equals("close", true)) {
                        allRecipesList.clear()
                        allRecipesList.addAll(allRecipesListTemp)

                        if (allRecipesList.isEmpty()) {
                            tvNoRecipeFound.visibility = View.VISIBLE
                            rvRecipesTitle.visibility = View.GONE
                        } else {
                            setStickyLis(true)
                            tvNoRecipeFound.visibility = View.GONE
                            rvRecipesTitle.visibility = View.VISIBLE
                        }

                    } else {
                        callFilterMethod()
                    }
                }
            }
        ).setContentView(R.layout.dialog_favorite)
            .setGravity(Gravity.BOTTOM)
            .setScaleRatio(0.1f)
            .setBlurRadius(Constant.blurRadius)
            .setDismissOnClickBack(false)
            .setDismissOnTouchBackground(false)
            .build()
            .show()
    }

    fun callFilterMethod() {
        CommonUtility.showProgressDialog(mContext)
        Constant.service.filterMethod(
            FilterRequest(
                my_favourite = RecipesActivity.myFavourite,
                food_type = RecipesActivity.foodType.joinToString(","),
                cusine_type = RecipesActivity.cusineList.joinToString(","),
                user_id = "" + userData.userId,
                filter_type = "all"
            )
        ).apply {
            enqueue(object : Callback<AllRecipes> {
                override fun onFailure(call: Call<AllRecipes>, t: Throwable) {
                    CommonUtility.hideProgressBar()
                }

                override fun onResponse(
                    call: Call<AllRecipes>,
                    response: Response<AllRecipes>
                ) {
                    CommonUtility.hideProgressBar()
                    allRecipesList.clear()
                    if (response.isSuccessful && response.body()?.status == 1) {
                        allRecipesList += response.body()?.titleResult!!.filter { it.recepieTitle!!.isNotEmpty() }
                        setStickyLis(isSticky)
                    }

                    if (allRecipesList.isEmpty()) {
                        tvNoRecipeFound.visibility = View.VISIBLE
                        rvRecipesTitle.visibility = View.GONE
                    } else {
                        tvNoRecipeFound.visibility = View.GONE
                        rvRecipesTitle.visibility = View.VISIBLE
                    }
                }

            })
        }
    }
}
