package com.zegacookware.model.recipes

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class SearchRecipes {
    @SerializedName("recepie_result")
    @Expose
    var recipesResult: List<RecipesResult>? = null
    @SerializedName("status")
    @Expose
    var status: Int? = null

}
