package com.zegacookware.model.user

import android.bluetooth.BluetoothGattCharacteristic
import android.content.Context
import com.zegacookware.network.Constant
import com.zegacookware.util.CommonUtility
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

object UserModel {

    var isRegisterTheBroadcast: Boolean = false
    //    var isShowFirstTime: Boolean = true

    @JvmStatic
    var isCallFromDevice: Boolean = true

    var mBluetoothGattChar: BluetoothGattCharacteristic? = null
    var isFromAnalogue: Boolean = false
    var isFromConnectScreen: Boolean = false
    var token: String = ""
    var lat: String = ""
    var lng: String = ""
    var userInfo: UserResult = UserResult()

    @JvmStatic
    var isHardwareOutOfRange: Boolean = false

    fun getUserProfile(mContext: Context) {
        val userData = CommonUtility.getUserData(Constant.userInfo, mContext)
        Constant.service.getUserInfo(ChangePasswordRequest(user_id = "" + userData.userId)).apply {
            enqueue(object : Callback<UpdateUserInfo> {
                override fun onFailure(call: Call<UpdateUserInfo>, t: Throwable) {

                }

                override fun onResponse(
                    call: Call<UpdateUserInfo>,
                    response: Response<UpdateUserInfo>
                ) {
                    if (response.isSuccessful && response.body()?.status == 1) {
                        CommonUtility.setUserData(
                            response.body()?.userResult!!,
                            Constant.userInfo,
                            mContext
                        )
                    }
                }

            })
        }
    }

}
